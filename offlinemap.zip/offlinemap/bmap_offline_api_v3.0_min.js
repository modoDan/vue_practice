window.TILE_VERSION = {
  ditu: {
    normal: {
      version: '088',
      updateDate: '20181205',
    },
    satellite: {
      version: '009',
      updateDate: '20181205',
    },
    normalTraffic: {
      version: '081',
      updateDate: '20181205',
    },
    satelliteTraffic: {
      version: '083',
      updateDate: '20181205',
    },
    mapJS: {
      version: '104',
      updateDate: '20181205',
    },
    satelliteStreet: {
      version: '083',
      updateDate: '20181205',
    },
    panoClick: {
      version: '1033',
      updateDate: '20181128',
    },
    panoUdt: {
      version: '20181128',
      updateDate: '20181128',
    },
    panoSwfAPI: {
      version: '20150123',
      updateDate: '20150123',
    },
    panoSwfPlace: {
      version: '20141112',
      updateDate: '20141112',
    },
    earthVector: {
      version: '001',
      updateDate: '20181205',
    },
  },
  webapp: {
    high_normal: {
      version: '001',
      updateDate: '20181205',
    },
    lower_normal: {
      version: '002',
      updateDate: '20181205',
    },
  },
  api_for_mobile: {
    vector: {
      version: '002',
      updateDate: '20181205',
    },
    vectorIcon: {
      version: '002',
      updateDate: '20181205',
    },
  },
};
window.BMAP_AUTHENTIC_KEY = '';
(function () {
  function aa(a) {
    throw a;
  }
  const l = void 0;
  const p = !0;
  const q = null;
  const t = !1;
  function u() {
    return function () {};
  }
  function ba(a) {
    return function (b) {
      this[a] = b;
    };
  }
  function x(a) {
    return function () {
      return this[a];
    };
  }
  function da(a) {
    return function () {
      return a;
    };
  }
  let ea; const
    fa = [];
  function ga(a) {
    return function () {
      return fa[a].apply(this, arguments);
    };
  }
  function ha(a, b) {
    return fa[a] = b;
  }
  let ia; var
    A = ia = A || {
      version: '1.3.4',
    };
  A.ca = '$BAIDU$';
  window[A.ca] = window[A.ca] || {};
  A.object = A.object || {};
  A.extend = A.object.extend = function (a, b) {
    for (const c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
    return a;
  };
  A.U = A.U || {};
  A.U.ea = function (a) {
    return typeof a === 'string' || a instanceof String ? document.getElementById(a) : a && a.nodeName && (a.nodeType == 1 || a.nodeType == 9) ? a : q;
  };
  A.ea = A.Ec = A.U.ea;
  A.U.$ = function (a) {
    a = A.U.ea(a);
    if (a === q) return a;
    a.style.display = 'none';
    return a;
  };
  A.$ = A.U.$;
  A.lang = A.lang || {};
  A.lang.wg = function (a) {
    return Object.prototype.toString.call(a) == '[object String]';
  };
  A.wg = A.lang.wg;
  A.lang.TD = function (a) {
    if (Object.prototype.toString.call(a) === '[object Object]') {
      for (const b in a) return t;
      return p;
    }
    return t;
  };
  A.TD = A.lang.TD;
  A.U.Mj = function (a) {
    return A.lang.wg(a) ? document.getElementById(a) : a;
  };
  A.Mj = A.U.Mj;
  A.U.getElementsByClassName = function (a, b) {
    let c;
    if (a.getElementsByClassName) c = a.getElementsByClassName(b);
    else {
      var e = a;
      e == q && (e = document);
      c = [];
      var e = e.getElementsByTagName('*'); const f = e.length; const g = RegExp(`(^|\\s)${b}(\\s|$)`); let i; let
        k;
      for (k = i = 0; i < f; i++) {
        g.test(e[i].className) && (c[k] = e[i],
        k++);
      }
    }
    return c;
  };
  A.getElementsByClassName = A.U.getElementsByClassName;
  A.U.contains = function (a, b) {
    const c = A.U.Mj;
    var a = c(a);
    var b = c(b);
    return a.contains ? a != b && a.contains(b) : !!(a.compareDocumentPosition(b) & 16);
  };
  A.fa = A.fa || {};
  /msie (\d+\.\d)/i.test(navigator.userAgent) && (A.fa.na = A.na = document.documentMode || +RegExp.$1);
  const ja = {
    cellpadding: 'cellPadding',
    cellspacing: 'cellSpacing',
    colspan: 'colSpan',
    rowspan: 'rowSpan',
    valign: 'vAlign',
    usemap: 'useMap',
    frameborder: 'frameBorder',
  };
  A.fa.na < 8 ? (ja.for = 'htmlFor',
  ja.class = 'className') : (ja.htmlFor = 'for',
  ja.className = 'class');
  A.U.pG = ja;
  A.U.RE = function (a, b, c) {
    a = A.U.ea(a);
    if (a === q) return a;
    if (b == 'style') a.style.cssText = c;
    else {
      b = A.U.pG[b] || b;
      a.setAttribute(b, c);
    }
    return a;
  };
  A.RE = A.U.RE;
  A.U.SE = function (a, b) {
    a = A.U.ea(a);
    if (a === q) return a;
    for (const c in b) A.U.RE(a, c, b[c]);
    return a;
  };
  A.SE = A.U.SE;
  A.Rk = A.Rk || {};
  (function () {
    const a = RegExp('(^[\\s\\t\\xa0\\u3000]+)|([\\u3000\\xa0\\s\\t]+$)', 'g');
    A.Rk.trim = function (b) {
      return (`${b}`).replace(a, '');
    };
  }());
  A.trim = A.Rk.trim;
  A.Rk.Ko = function (a, b) {
    var a = `${a}`;
    let c = Array.prototype.slice.call(arguments, 1);
    const e = Object.prototype.toString;
    if (c.length) {
      c = c.length == 1 ? b !== q && /\[object Array\]|\[object Object\]/.test(e.call(b)) ? b : c : c;
      return a.replace(/#\{(.+?)\}/g, (a, b) => {
        let i = c[b];
        e.call(i) == '[object Function]' && (i = i(b));
        return typeof i === 'undefined' ? '' : i;
      });
    }
    return a;
  };
  A.Ko = A.Rk.Ko;
  A.U.qc = function (a, b) {
    a = A.U.ea(a);
    if (a === q) return a;
    for (var c = a.className.split(/\s+/), e = b.split(/\s+/), f, g = e.length, i, k = 0; k < g; ++k) {
      i = 0;
      for (f = c.length; i < f; ++i) {
        if (c[i] == e[k]) {
          c.splice(i, 1);
          break;
        }
      }
    }
    a.className = c.join(' ');
    return a;
  };
  A.qc = A.U.qc;
  A.U.qx = function (a, b, c) {
    a = A.U.ea(a);
    if (a === q) return a;
    let e;
    if (a.insertAdjacentHTML) a.insertAdjacentHTML(b, c);
    else {
      e = a.ownerDocument.createRange();
      b = b.toUpperCase();
      if (b == 'AFTERBEGIN' || b == 'BEFOREEND') {
        e.selectNodeContents(a);
        e.collapse(b == 'AFTERBEGIN');
      } else {
        b = b == 'BEFOREBEGIN';
        e[b ? 'setStartBefore' : 'setEndAfter'](a);
        e.collapse(b);
      }
      e.insertNode(e.createContextualFragment(c));
    }
    return a;
  };
  A.qx = A.U.qx;
  A.U.show = function (a) {
    a = A.U.ea(a);
    if (a === q) return a;
    a.style.display = '';
    return a;
  };
  A.show = A.U.show;
  A.U.jD = function (a) {
    a = A.U.ea(a);
    return a === q ? a : a.nodeType == 9 ? a : a.ownerDocument || a.document;
  };
  A.U.hb = function (a, b) {
    a = A.U.ea(a);
    if (a === q) return a;
    for (var c = b.split(/\s+/), e = a.className, f = ` ${e} `, g = 0, i = c.length; g < i; g++) f.indexOf(` ${c[g]} `) < 0 && (e += (` ${c[g]}`));
    a.className = e;
    return a;
  };
  A.hb = A.U.hb;
  A.U.jB = A.U.jB || {};
  A.U.Jl = A.U.Jl || [];
  A.U.Jl.filter = function (a, b, c) {
    for (var e = 0, f = A.U.Jl, g; g = f[e]; e++) if (g = g[c]) b = g(a, b);
    return b;
  };
  A.Rk.hO = function (a) {
    return a.indexOf('-') < 0 && a.indexOf('_') < 0 ? a : a.replace(/[-_][^-_]/g, a => a.charAt(1).toUpperCase());
  };
  A.U.b0 = function (a) {
    A.U.Hs(a, 'expand') ? A.U.qc(a, 'expand') : A.U.hb(a, 'expand');
  };
  A.U.Hs = function (a) {
    if (arguments.length <= 0 || typeof a === 'function') return this;
    if (this.size() <= 0) return t;
    var a = a.replace(/^\s+/g, '').replace(/\s+$/g, '').replace(/\s+/g, ' '); const b = a.split(' '); let
      c;
    A.forEach(this, (a) => {
      for (var a = a.className, f = 0; f < b.length; f++) {
        if (!~(` ${a} `).indexOf(` ${b[f]} `)) {
          c = t;
          return;
        }
      }
      c !== t && (c = p);
    });
    return c;
  };
  A.U.vg = function (a, b) {
    const c = A.U;
    var a = c.ea(a);
    if (a === q) return a;
    var b = A.Rk.hO(b);
    var e = a.style[b];
    if (!e) {
      var f = c.jB[b];
      var e = a.currentStyle || (A.fa.na ? a.style : getComputedStyle(a, q));
      var e = f && f.get ? f.get(a, e) : e[f || b];
    }
    if (f = c.Jl) e = f.filter(b, e, 'get');
    return e;
  };
  A.vg = A.U.vg;
  /opera\/(\d+\.\d)/i.test(navigator.userAgent) && (A.fa.opera = +RegExp.$1);
  A.fa.WL = /webkit/i.test(navigator.userAgent);
  A.fa.wY = /gecko/i.test(navigator.userAgent) && !/like gecko/i.test(navigator.userAgent);
  A.fa.$D = document.compatMode == 'CSS1Compat';
  A.U.la = function (a) {
    a = A.U.ea(a);
    if (a === q) return a;
    let b = A.U.jD(a);
    const c = A.fa;
    let e = A.U.vg;
    c.wY > 0 && b.getBoxObjectFor && e(a, 'position');
    const f = {
      left: 0,
      top: 0,
    }; let
      g;
    if (a == (c.na && !c.$D ? b.body : b.documentElement)) return f;
    if (a.getBoundingClientRect) {
      a = a.getBoundingClientRect();
      f.left = Math.floor(a.left) + Math.max(b.documentElement.scrollLeft, b.body.scrollLeft);
      f.top = Math.floor(a.top) + Math.max(b.documentElement.scrollTop, b.body.scrollTop);
      f.left -= b.documentElement.clientLeft;
      f.top -= b.documentElement.clientTop;
      a = b.body;
      b = parseInt(e(a, 'borderLeftWidth'));
      e = parseInt(e(a, 'borderTopWidth'));
      if (c.na && !c.$D) {
        f.left -= (isNaN(b) ? 2 : b);
        f.top -= (isNaN(e) ? 2 : e);
      }
    } else {
      g = a;
      do {
        f.left += g.offsetLeft;
        f.top += g.offsetTop;
        if (c.WL > 0 && e(g, 'position') == 'fixed') {
          f.left += b.body.scrollLeft;
          f.top += b.body.scrollTop;
          break;
        }
        g = g.offsetParent;
      } while (g && g != a);if (c.opera > 0 || c.WL > 0 && e(a, 'position') == 'absolute') f.top -= b.body.offsetTop;
      for (g = a.offsetParent; g && g != b.body;) {
        f.left -= g.scrollLeft;
        if (!c.opera || g.tagName != 'TR') f.top -= g.scrollTop;
        g = g.offsetParent;
      }
    }
    return f;
  };
  /firefox\/(\d+\.\d)/i.test(navigator.userAgent) && (A.fa.Re = +RegExp.$1);
  /BIDUBrowser/i.test(navigator.userAgent) && (A.fa.g2 = p);
  const ka = navigator.userAgent;
  /(\d+\.\d)?(?:\.\d)?\s+safari\/?(\d+\.\d+)?/i.test(ka) && !/chrome/i.test(ka) && (A.fa.ay = +(RegExp.$1 || RegExp.$2));
  /chrome\/(\d+\.\d)/i.test(navigator.userAgent) && (A.fa.mw = +RegExp.$1);
  A.jc = A.jc || {};
  A.jc.Mb = function (a, b) {
    let c; let e; const
      f = a.length;
    if (typeof b === 'function') {
      for (e = 0; e < f; e++) {
        c = a[e];
        c = b.call(a, c, e);
        if (c === t) break;
      }
    }
    return a;
  };
  A.Mb = A.jc.Mb;
  A.lang.ca = function () {
    return `TANGRAM__${(window[A.ca]._counter++).toString(36)}`;
  };
  window[A.ca]._counter = window[A.ca]._counter || 1;
  window[A.ca]._instances = window[A.ca]._instances || {};
  A.lang.Rs = function (a) {
    return Object.prototype.toString.call(a) == '[object Function]';
  };
  A.lang.Ha = function (a) {
    this.ca = a || A.lang.ca();
    window[A.ca]._instances[this.ca] = this;
  };
  window[A.ca]._instances = window[A.ca]._instances || {};
  A.lang.Ha.prototype.Yh = ga(0);
  A.lang.Ha.prototype.toString = function () {
    return `[object ${this.iQ || 'Object'}]`;
  };
  A.lang.ku = function (a, b) {
    this.type = a;
    this.returnValue = p;
    this.target = b || q;
    this.currentTarget = q;
  };
  A.lang.Ha.prototype.addEventListener = function (a, b, c) {
    if (A.lang.Rs(b)) {
      !b.bl && (b.bl = {});
      !this.Ci && (this.Ci = {});
      const e = this.Ci; let
        f;
      if (typeof c === 'string' && c) {
        /[^\w\-]/.test(c) && aa(`nonstandard key:${c}`);
        f = b.hx = c;
      }
      a.indexOf('on') != 0 && (a = `on${a}`);
      typeof e[a] !== 'object' && (e[a] = {});
      typeof b.bl[a] !== 'object' && (b.bl[a] = {});
      f = f || A.lang.ca();
      b.bl[a].hx = f;
      e[a][f] = b;
    }
  };
  A.lang.Ha.prototype.removeEventListener = function (a, b) {
    a.indexOf('on') != 0 && (a = `on${a}`);
    if (A.lang.Rs(b)) {
      if (!b.bl || !b.bl[a]) return;
      b = b.bl[a].hx;
    } else if (!A.lang.wg(b)) return;
    !this.Ci && (this.Ci = {});
    const c = this.Ci;
    c[a] && c[a][b] && delete c[a][b];
  };
  A.lang.Ha.prototype.dispatchEvent = function (a, b) {
    A.lang.wg(a) && (a = new A.lang.ku(a));
    !this.Ci && (this.Ci = {});
    var b = b || {}; let
      c;
    for (c in b) a[c] = b[c];
    const e = this.Ci;
    let f = a.type;
    a.target = a.target || this;
    a.currentTarget = this;
    f.indexOf('on') != 0 && (f = `on${f}`);
    A.lang.Rs(this[f]) && this[f].apply(this, arguments);
    if (typeof e[f] === 'object') for (c in e[f]) e[f][c].apply(this, arguments);
    return a.returnValue;
  };
  A.lang.xa = function (a, b, c) {
    let e; let f; const
      g = a.prototype;
    f = new Function();
    f.prototype = b.prototype;
    f = a.prototype = new f();
    for (e in g) f[e] = g[e];
    a.prototype.constructor = a;
    a.P_ = b.prototype;
    if (typeof c === 'string') f.iQ = c;
  };
  A.xa = A.lang.xa;
  A.lang.Nc = function (a) {
    return window[A.ca]._instances[a] || q;
  };
  A.platform = A.platform || {};
  A.platform.PL = /macintosh/i.test(navigator.userAgent);
  A.platform.o4 = /MicroMessenger/i.test(navigator.userAgent);
  A.platform.XL = /windows/i.test(navigator.userAgent);
  A.platform.FY = /x11/i.test(navigator.userAgent);
  A.platform.pj = /android/i.test(navigator.userAgent);
  /android (\d+(\.\d)?)/i.test(navigator.userAgent) && (A.platform.EB = A.EB = RegExp.$1);
  A.platform.yY = /ipad/i.test(navigator.userAgent);
  A.platform.WD = /iphone/i.test(navigator.userAgent);
  function la(a, b) {
    a.domEvent = b = window.event || b;
    a.clientX = b.clientX || b.pageX;
    a.clientY = b.clientY || b.pageY;
    a.offsetX = b.offsetX || b.layerX;
    a.offsetY = b.offsetY || b.layerY;
    a.screenX = b.screenX;
    a.screenY = b.screenY;
    a.ctrlKey = b.ctrlKey || b.metaKey;
    a.shiftKey = b.shiftKey;
    a.altKey = b.altKey;
    if (b.touches) {
      a.touches = [];
      for (var c = 0; c < b.touches.length; c++) {
        a.touches.push({
          clientX: b.touches[c].clientX,
          clientY: b.touches[c].clientY,
          screenX: b.touches[c].screenX,
          screenY: b.touches[c].screenY,
          pageX: b.touches[c].pageX,
          pageY: b.touches[c].pageY,
          target: b.touches[c].target,
          identifier: b.touches[c].identifier,
        });
      }
    }
    if (b.changedTouches) {
      a.changedTouches = [];
      for (c = 0; c < b.changedTouches.length; c++) {
        a.changedTouches.push({
          clientX: b.changedTouches[c].clientX,
          clientY: b.changedTouches[c].clientY,
          screenX: b.changedTouches[c].screenX,
          screenY: b.changedTouches[c].screenY,
          pageX: b.changedTouches[c].pageX,
          pageY: b.changedTouches[c].pageY,
          target: b.changedTouches[c].target,
          identifier: b.changedTouches[c].identifier,
        });
      }
    }
    if (b.targetTouches) {
      a.targetTouches = [];
      for (c = 0; c < b.targetTouches.length; c++) {
        a.targetTouches.push({
          clientX: b.targetTouches[c].clientX,
          clientY: b.targetTouches[c].clientY,
          screenX: b.targetTouches[c].screenX,
          screenY: b.targetTouches[c].screenY,
          pageX: b.targetTouches[c].pageX,
          pageY: b.targetTouches[c].pageY,
          target: b.targetTouches[c].target,
          identifier: b.targetTouches[c].identifier,
        });
      }
    }
    a.rotation = b.rotation;
    a.scale = b.scale;
    return a;
  }
  A.lang.Dw = function (a) {
    const b = window[A.ca];
    b.mS && delete b.mS[a];
  };
  A.event = {};
  A.V = A.event.V = function (a, b, c) {
    if (!(a = A.ea(a))) return a;
    b = b.replace(/^on/, '');
    a.addEventListener ? a.addEventListener(b, c, t) : a.attachEvent && a.attachEvent(`on${b}`, c);
    return a;
  };
  A.cd = A.event.cd = function (a, b, c) {
    if (!(a = A.ea(a))) return a;
    b = b.replace(/^on/, '');
    a.removeEventListener ? a.removeEventListener(b, c, t) : a.detachEvent && a.detachEvent(`on${b}`, c);
    return a;
  };
  A.U.Hs = function (a, b) {
    if (!a || !a.className || typeof a.className !== 'string') return t;
    let c = -1;
    try {
      c = a.className == b || a.className.search(RegExp(`(\\s|^)${b}(\\s|$)`));
    } catch (e) {
      return t;
    }
    return c > -1;
  };
  A.BK = (function () {
    function a(a) {
      document.addEventListener && (this.element = a,
      this.EK = this.Ak ? 'touchstart' : 'mousedown',
      this.RC = this.Ak ? 'touchmove' : 'mousemove',
      this.QC = this.Ak ? 'touchend' : 'mouseup',
      this.oh = t,
      this.Rt = this.Qt = 0,
      this.element.addEventListener(this.EK, this, t),
      ia.V(this.element, 'mousedown', u()),
      this.handleEvent(q));
    }
    a.prototype = {
      Ak: 'ontouchstart' in window || 'createTouch' in document,
      start(a) {
        ma(a);
        this.oh = t;
        this.Qt = this.Ak ? a.touches[0].clientX : a.clientX;
        this.Rt = this.Ak ? a.touches[0].clientY : a.clientY;
        this.element.addEventListener(this.RC, this, t);
        this.element.addEventListener(this.QC, this, t);
      },
      move(a) {
        na(a);
        const c = this.Ak ? a.touches[0].clientY : a.clientY;
        if (Math.abs((this.Ak ? a.touches[0].clientX : a.clientX) - this.Qt) > 10 || Math.abs(c - this.Rt) > 10) this.oh = p;
      },
      end(a) {
        na(a);
        this.oh || (a = document.createEvent('Event'),
        a.initEvent('tap', t, p),
        this.element.dispatchEvent(a));
        this.element.removeEventListener(this.RC, this, t);
        this.element.removeEventListener(this.QC, this, t);
      },
      handleEvent(a) {
        if (a) {
          switch (a.type) {
            case this.EK:
              this.start(a);
              break;
            case this.RC:
              this.move(a);
              break;
            case this.QC:
              this.end(a);
          }
        }
      },
    };
    return function (b) {
      return new a(b);
    };
  }());
  let D = window.BMap || {};
  D.version = '3.0';
  D.X1 = Math.random() < 0.34;
  D.version.indexOf('#') >= 0 && (D.version = '3.0');
  D.hr = [];
  D.Ze = function (a) {
    this.hr.push(a);
  };
  D.Wq = [];
  D.Gk = function (a) {
    this.Wq.push(a);
  };
  D.zU = D.apiLoad || u();
  D.C0 = D.verify || function () {
    D.version && D.version >= 1.5 && oa(`${D.nd}?qt=verify&ak=${pa}`, (a) => {
      if (a && a.error !== 0) {
        if (typeof map !== 'undefined') {
          map.Ra().innerHTML = '';
          map.Ci = {};
        }
        D = q;
        let b = '\u767e\u5ea6\u672a\u6388\u6743\u4f7f\u7528\u5730\u56feAPI\uff0c\u53ef\u80fd\u662f\u56e0\u4e3a\u60a8\u63d0\u4f9b\u7684\u5bc6\u94a5\u4e0d\u662f\u6709\u6548\u7684\u767e\u5ea6LBS\u5f00\u653e\u5e73\u53f0\u5bc6\u94a5\uff0c\u6216\u6b64\u5bc6\u94a5\u672a\u5bf9\u672c\u5e94\u7528\u7684\u767e\u5ea6\u5730\u56feJavaScriptAPI\u6388\u6743\u3002\u60a8\u53ef\u4ee5\u8bbf\u95ee\u5982\u4e0b\u7f51\u5740\u4e86\u89e3\u5982\u4f55\u83b7\u53d6\u6709\u6548\u7684\u5bc6\u94a5\uff1ahttp://lbsyun.baidu.com/apiconsole/key#\u3002';
        switch (a.error) {
          case 101:
            b = '\u5f00\u53d1\u8005\u7981\u7528\u4e86\u8be5ak\u7684jsapi\u670d\u52a1\u6743\u9650\u3002\u60a8\u53ef\u4ee5\u8bbf\u95ee\u5982\u4e0b\u7f51\u5740\u4e86\u89e3\u5982\u4f55\u83b7\u53d6\u6709\u6548\u7684\u5bc6\u94a5\uff1ahttp://lbsyun.baidu.com/apiconsole/key#\u3002';
            break;
          case 102:
            b = '\u5f00\u53d1\u8005Referer\u4e0d\u6b63\u786e\u3002\u60a8\u53ef\u4ee5\u8bbf\u95ee\u5982\u4e0b\u7f51\u5740\u4e86\u89e3\u5982\u4f55\u83b7\u53d6\u6709\u6548\u7684\u5bc6\u94a5\uff1ahttp://lbsyun.baidu.com/apiconsole/key#\u3002';
        }
        alert(b);
      }
    });
  };
  var pa = window.BMAP_AUTHENTIC_KEY;
  window.BMAP_AUTHENTIC_KEY = q;
  const qa = window.BMap_loadScriptTime;
  const ra = (new Date()).getTime();
  let ua = q;
  let va = p;
  const wa = 5042;
  const xa = 5002;
  const ya = 5003;
  const za = 'load_mapclick';
  const Ba = 5038;
  const Ca = 5041;
  const Da = 5047;
  const Ea = 5036;
  const Fa = 5039;
  const Ha = 5037;
  const Ia = 5040;
  const Ja = 5011;
  const Ka = 7E3;
  const La = 0;
  function Ma(a, b) {
    if (a = A.ea(a)) {
      const c = this;
      A.lang.Ha.call(c);
      b = b || {};
      c.M = {
        RB: 200,
        pc: p,
        Iw: t,
        GC: p,
        Fo: p,
        Ho: b.enableWheelZoom || t,
        zK: p,
        IC: p,
        Go: p,
        is: p,
        NC: p,
        Do: b.enable3DBuilding || t,
        Ic: 25,
        P0: 240,
        mU: 450,
        wc: H.wc,
        Gd: H.Gd,
        Ss: !!b.Ss,
        fc: Math.round(b.minZoom) || 1,
        mc: Math.round(b.maxZoom) || 19,
        Sa: b.mapType || Na,
        o5: t,
        wK: b.drawer || La,
        Hw: p,
        Gw: 500,
        rW: b.enableHighResolution !== t,
        fm: b.enableMapClick !== t,
        devicePixelRatio: b.devicePixelRatio || window.devicePixelRatio || 1,
        AF: 99,
        xe: b.mapStyle || q,
        MY: b.logoControl === t ? t : p,
        GU: [],
        j2: b.beforeClickIcon || q,
        sg: t,
        ok: t,
        yo: t,
        uE: p,
        CC: b.enableBizAuthLogo === t ? t : p,
        Ia: b.coordsType || 5,
        T5: b.touchZoomCenter || 0,
        KC: b.enablePinchDragging === t ? t : p,
      };
      c.M.xe && (this.jY(c.M.xe.controls),
      this.LL(c.M.xe.geotableId));
      c.M.xe && c.M.xe.styleId && c.J3(c.M.xe.styleId);
      c.M.UB = {
        dark: {
          backColor: '#2D2D2D',
          textColor: '#bfbfbf',
          iconUrl: 'dicons',
        },
        normal: {
          backColor: '#F3F1EC',
          textColor: '#c61b1b',
          iconUrl: 'icons',
        },
        light: {
          backColor: '#EBF8FC',
          textColor: '#017fb4',
          iconUrl: 'licons',
        },
      };
      b.enableAutoResize && (c.M.is = b.enableAutoResize);
      b.enableStreetEntrance === t && (c.M.NC = b.enableStreetEntrance);
      b.enableDeepZoom === t && (c.M.zK = b.enableDeepZoom);
      let e = c.M.GU;
      if (I()) {
        for (var f = 0, g = e.length; f < g; f++) {
          if (A.fa[e[f]]) {
            c.M.devicePixelRatio = 1;
            break;
          }
        }
      }
      e = navigator.userAgent.toLowerCase().indexOf('android') > -1;
      f = navigator.userAgent.toLowerCase().indexOf('mqqbrowser') > -1;
      if (navigator.userAgent.toLowerCase().indexOf('UCBrowser') > -1 || e && f) c.M.AF = 99;
      c.ab = a;
      c.cB(a);
      a.unselectable = 'on';
      a.innerHTML = '';
      a.appendChild(c.za());
      b.size && this.Be(b.size);
      e = c.xb();
      c.width = e.width;
      c.height = e.height;
      c.offsetX = 0;
      c.offsetY = 0;
      c.platform = a.firstChild;
      c.ye = c.platform.firstChild;
      c.ye.style.width = `${c.width}px`;
      c.ye.style.height = `${c.height}px`;
      c.Xd = {};
      c.be = new J(0, 0);
      c.Tb = new J(0, 0);
      c.Xa = 3;
      c.xc = 0;
      c.eC = q;
      c.dC = q;
      c.Lb = '';
      c.nw = '';
      c.Gh = {};
      c.Gh.custom = {};
      c.Ei = {};
      c.Ya = 0;
      b.useWebGL === t && Oa(t);
      c.W = new Pa(a, {
        Se: 'api',
        rS: p,
      });
      c.W.$();
      c.W.XE(c);
      b = b || {};
      e = c.Sa = c.M.Sa;
      c.Bc = e.jj();
      e && e.$E(c.M.Ia);
      e === Qa && Ra(xa);
      e === Sa && Ra(ya);
      e = c.M;
      e.AO = Math.round(b.minZoom);
      e.zO = Math.round(b.maxZoom);
      c.Du();
      c.aa = {
        Jc: t,
        kc: 0,
        Xs: 0,
        bM: 0,
        s4: 0,
        JB: t,
        GE: -1,
        re: [],
      };
      c.platform.style.cursor = c.M.wc;
      for (f = 0; f < D.hr.length; f++) D.hr[f](c);
      c.aa.GE = f;
      c.ga();
      Ta.load('map', () => {
        c.mb();
      });
      c.M.fm && (setTimeout(() => {
        Ra(za);
      }, 1E3),
      Ta.load('mapclick', () => {
        window.MPC_Mgr = window.MPC_Mgr || {};
        window.MPC_Mgr[c.ca] = new Ua(c);
      }, p));
      Wa() && Ta.load('oppc', () => {
        c.su();
      });
      I() && Ta.load('opmb', () => {
        c.su();
      });
      a = q;
      c.qB = [];
    }
  }
  A.lang.xa(Ma, A.lang.Ha, 'Map');
  A.extend(Ma.prototype, {
    za() {
      const a = L('div');
      var b = a.style;
      b.overflow = 'visible';
      b.position = 'absolute';
      b.zIndex = '0';
      b.top = b.left = '0px';
      var b = L('div', {
        class: 'BMap_mask',
      });
      const c = b.style;
      c.position = 'absolute';
      c.top = c.left = '0px';
      c.zIndex = '9';
      c.overflow = 'hidden';
      c.WebkitUserSelect = 'none';
      a.appendChild(b);
      return a;
    },
    cB(a) {
      const b = a.style;
      b.overflow = 'hidden';
      Xa(a).position !== 'absolute' && (b.position = 'relative',
      b.zIndex = 0);
      b.backgroundColor = '#F3F1EC';
      b.color = '#000';
      b.textAlign = 'left';
    },
    ga() {
      const a = this;
      a.eo = function () {
        const b = a.xb();
        if (a.width !== b.width || a.height !== b.height) {
          let c = new N(a.width, a.height);
          const e = new P('onbeforeresize');
          e.size = c;
          a.dispatchEvent(e);
          a.fk((b.width - a.width) / 2, (b.height - a.height) / 2);
          a.ye.style.width = `${a.width = b.width}px`;
          a.ye.style.height = `${a.height = b.height}px`;
          c = new P('onresize');
          c.size = b;
          a.dispatchEvent(c);
        }
      };
      a.M.is && (a.aa.Tl = setInterval(a.eo, 80));
    },
    fk(a, b, c, e) {
      const f = this.wa().Xb(this.ja());
      const g = this.Bc;
      let i = p;
      if (c && (c instanceof Q || c instanceof J)) c = Ya(c, this.M.Ia);
      c && Q.VD(c) && (this.be = new J(c.lng, c.lat),
      i = t);
      if (c = c && e ? g.ii(c, this.Lb) : this.Tb) {
        if (this.Tb = new J(c.lng + a * f, c.lat - b * f),
        (a = g.nh(this.Tb, this.Lb)) && i) this.be = a;
      }
    },
    Ig(a, b) {
      if (Za(a) && (this.Du(),
      this.dispatchEvent(new P('onzoomstart')),
      a = this.En(a).zoom,
      a !== this.Xa)) {
        this.xc = this.Xa;
        this.Xa = a;
        let c;
        b ? c = b : this.ih() && (c = this.ih().la());
        c && (c = this.Qn(Ya(c, this.M.Ia), this.xc),
        this.fk(this.width / 2 - c.x, this.height / 2 - c.y, this.kg(c, this.xc), p));
        this.dispatchEvent(new P('onzoomstartcode'));
      }
    },
    Qc(a) {
      this.Ig(a);
    },
    HF(a) {
      this.Ig(this.Xa + 1, a);
    },
    IF(a) {
      this.Ig(this.Xa - 1, a);
    },
    qi(a) {
      if (a instanceof Q || a instanceof J) {
        a = Ya(a, this.M.Ia),
        this.Tb = this.Bc.ii(a, this.Lb),
        this.be = Q.VD(a) ? new J(a.lng, a.lat) : this.Bc.nh(this.Tb, this.Lb);
      }
    },
    Cg(a, b) {
      a = Math.round(a) || 0;
      b = Math.round(b) || 0;
      this.fk(-a, -b);
    },
    Fr(a) {
      a && $a(a.Ge) && (a.Ge(this),
      this.dispatchEvent(new P('onaddcontrol', a)));
    },
    lN(a) {
      a && $a(a.remove) && (a.remove(),
      this.dispatchEvent(new P('onremovecontrol', a)));
    },
    jo(a) {
      a && $a(a.ya) && (a.ya(this),
      this.dispatchEvent(new P('onaddcontextmenu', a)));
    },
    mp(a) {
      a && $a(a.remove) && (this.dispatchEvent(new P('onremovecontextmenu', a)),
      a.remove());
    },
    Pa(a) {
      a && $a(a.Ge) && (a.Ge(this),
      this.dispatchEvent(new P('onaddoverlay', a)));
    },
    Ob(a) {
      a && $a(a.remove) && (a.remove(),
      this.dispatchEvent(new P('onremoveoverlay', a)));
    },
    SJ() {
      this.dispatchEvent(new P('onclearoverlays'));
    },
    Ne(a) {
      a && this.dispatchEvent(new P('onaddtilelayer', a));
    },
    Yf(a) {
      a && this.dispatchEvent(new P('onremovetilelayer', a));
    },
    Gg(a) {
      if (this.Sa !== a) {
        this.M.PY && this.m_(a);
        let b = new P('onsetmaptype');
        b.f5 = this.Sa;
        this.Sa = this.M.Sa = a;
        this.Bc = this.Sa.jj();
        this.fk(0, 0, this.Ou(), p);
        this.Du();
        const c = this.En(this.ja()).zoom;
        this.Ig(c);
        this.dispatchEvent(b);
        b = new P('onmaptypechange');
        b.Xa = c;
        b.Sa = a;
        this.dispatchEvent(b);
        a.$E(this.M.Ia);
        (a === ab || a === Sa) && Ra(ya);
      }
    },
    m_(a) {
      a === ab || a === Sa ? (this.fy(p),
      this.EN(t),
      this.M.sg = t,
      this.M.ok = t) : (this.fy(t),
      this.EN(p),
      this.M.sg = p,
      this.M.ok = p);
    },
    tf(a) {
      const b = this;
      if (a instanceof Q || a instanceof J) {
        b.qi(a, {
          noAnimation: p,
        });
      } else if (bb(a)) {
        if (b.Sa === Qa) {
          const c = H.NB[a];
          c && (pt = c.o,
          b.tf(pt));
        } else {
          const e = this.tH();
          e.Ft((c) => {
            e.nm() === 0 && e.Ma.result.type === 2 && (c = c.xk(0).point,
            c = new J(c.lng, c.lat),
            c = cb(c, b.M.Ia),
            b.tf(c),
            Qa.sk(a) && b.UE(a));
          });
          e.search(a, {
            log: 'center',
          });
        }
      }
    },
    od(a, b) {
      Object.prototype.toString.call(b) !== '[object Undefined]' && (b = parseInt(b));
      D.aq('cus.fire', 'time', {
        z_loadscripttime: ra - qa,
      });
      const c = this;
      if (bb(a)) {
        if (c.Sa === Qa) {
          var e = H.NB[a];
          e && (pt = e.o,
          c.od(pt, b));
        } else {
          const f = c.tH();
          f.Ft((e) => {
            if (f.nm() === 0 && (f.Ma.result.type === 2 || f.Ma.result.type === 11)) {
              var g = e.xk(0).point;
              var e = b || db.Nw(f.Ma.content.level, c);
              var g = new J(g.lng, g.lat);
              c.od(g, e);
              Qa.sk(a) && c.UE(a);
            }
          });
          f.search(a, {
            log: 'center',
          });
        }
      } else if ((a instanceof Q || a instanceof J) && b) {
        b = c.En(b).zoom;
        c.xc = c.Xa || b;
        c.Xa = b;
        e = c.be;
        a = Ya(a, this.M.Ia);
        c.be = new J(a.lng, a.lat);
        c.Tb = c.Bc.ii(c.be, c.Lb);
        c.eC = c.eC || c.Xa;
        c.dC = c.dC || c.be;
        let g = new P('onload');
        const i = new P('onloadcode');
        g.point = new J(a.lng, a.lat);
        g.pixel = c.Qn(c.be, c.Xa);
        g.zoom = b;
        c.loaded || (c.loaded = p,
        c.dispatchEvent(g),
        ua || (ua = eb()));
        c.dispatchEvent(i);
        g = new P('onmoveend');
        g.yz = 'centerAndZoom';
        e.Sb(c.be) || c.dispatchEvent(g);
        c.dispatchEvent(new P('onmoveend'));
        c.xc !== c.Xa && (e = new P('onzoomend'),
        e.yz = 'centerAndZoom',
        c.dispatchEvent(e));
        c.M.Do && c.Do();
      }
    },
    tH() {
      this.aa.nM || (this.aa.nM = new fb(1));
      return this.aa.nM;
    },
    reset() {
      this.od(this.dC, this.eC, p);
    },
    enableDragging() {
      this.M.pc = p;
    },
    disableDragging() {
      this.M.pc = t;
    },
    enableInertialDragging() {
      this.M.Hw = p;
    },
    disableInertialDragging() {
      this.M.Hw = t;
    },
    enableScrollWheelZoom() {
      this.M.Ho = p;
    },
    disableScrollWheelZoom() {
      this.M.Ho = t;
    },
    enableContinuousZoom() {
      this.M.Fo = p;
    },
    disableContinuousZoom() {
      this.M.Fo = t;
    },
    enableDoubleClickZoom() {
      this.M.GC = p;
    },
    disableDoubleClickZoom() {
      this.M.GC = t;
    },
    enableKeyboard() {
      this.M.Iw = p;
    },
    disableKeyboard() {
      this.M.Iw = t;
    },
    enablePinchToZoom() {
      this.M.Go = p;
    },
    disablePinchToZoom() {
      this.M.Go = t;
    },
    enableAutoResize() {
      this.M.is = p;
      this.eo();
      this.aa.Tl || (this.aa.Tl = setInterval(this.eo, 80));
    },
    disableAutoResize() {
      this.M.is = t;
      this.aa.Tl && (clearInterval(this.aa.Tl),
      this.aa.Tl = q);
    },
    enableBizAuthLogo() {
      this.M.CC = p;
      this.qo && this.qo.show();
    },
    disableBizAuthLogo() {
      this.M.CC = t;
      this.qo && this.qo.$();
    },
    enableMapClick() {
      this.M.fm = p;
      const a = this;
      window.MPC_Mgr && window.MPC_Mgr[a.ca] ? window.MPC_Mgr[a.ca].open() : (setTimeout(() => {
        Ra(za);
      }, 1E3),
      Ta.load('mapclick', () => {
        window.MPC_Mgr = window.MPC_Mgr || {};
        window.MPC_Mgr[a.ca] = new Ua(a);
      }, p));
    },
    disableMapClick() {
      window.MPC_Mgr && window.MPC_Mgr[this.ca] && window.MPC_Mgr[this.ca].close();
      this.M.fm = t;
    },
    Do() {
      this.M.Do = p;
      this.nn || (this.nn = new BuildingLayer({
        S2: p,
      }),
      this.Ne(this.nn));
    },
    SV() {
      this.M.Do = t;
      this.nn && (this.Yf(this.nn),
      this.nn = q,
      delete this.nn);
    },
    xb() {
      return this.Wr && this.Wr instanceof N ? new N(this.Wr.width, this.Wr.height) : new N(this.ab.clientWidth, this.ab.clientHeight);
    },
    Be(a) {
      a && a instanceof N ? (this.Wr = a,
      this.ab.style.width = `${a.width}px`,
      this.ab.style.height = `${a.height}px`) : this.Wr = q;
    },
    Nb() {
      return cb(this.be, this.M.Ia);
    },
    Ou: x('be'),
    ja: x('Xa'),
    fV() {
      this.eo();
    },
    En(a) {
      const b = this.M.fc;
      const c = this.M.mc;
      let e = t;
      var a = Math.round(a);
      a < b && (e = p,
      a = b);
      a > c && (e = p,
      a = c);
      return {
        zoom: a,
        SC: e,
      };
    },
    Ra: x('ab'),
    yc(a, b) {
      a = Ya(a, this.M.Ia);
      b = b || this.ja();
      return this.Bc.yc(a, b, this.Tb, this.xb(), this.Lb);
    },
    Qn(a, b) {
      b = b || this.ja();
      return this.Bc.yc(a, b, this.Tb, this.xb(), this.Lb);
    },
    kg(a, b) {
      b = b || this.ja();
      return this.Bc.Zb(a, b, this.Tb, this.xb(), this.Lb);
    },
    Zb(a, b) {
      return cb(this.kg(a, b), this.M.Ia);
    },
    Ye(a, b) {
      if (a) {
        var a = Ya(a, this.M.Ia);
        const c = this.Qn(new J(a.lng, a.lat), b);
        c.x -= this.offsetX;
        c.y -= this.offsetY;
        return c;
      }
    },
    SY(a, b) {
      b = b || this.ja();
      return this.Bc.TY(a, b, this.Tb, this.xb(), this.Lb);
    },
    RY(a, b) {
      if (a) {
        const c = this.SY(new J(a.lng, a.lat), b);
        c.x -= this.offsetX;
        c.y -= this.offsetY;
        return c;
      }
    },
    XM(a, b) {
      if (a) {
        const c = new R(a.x, a.y);
        c.x += this.offsetX;
        c.y += this.offsetY;
        return this.Zb(c, b);
      }
    },
    TS(a, b) {
      if (a) {
        const c = new R(a.x, a.y);
        c.x += this.offsetX;
        c.y += this.offsetY;
        return this.kg(c, b);
      }
    },
    pointToPixelFor3D(a, b) {
      const c = map.Lb;
      this.Sa === Qa && c && gb.YJ(a, this, b);
    },
    W4(a, b) {
      const c = map.Lb;
      this.Sa === Qa && c && gb.XJ(a, this, b);
    },
    X4(a, b) {
      const c = this;
      const e = map.Lb;
      c.Sa === Qa && e && gb.YJ(a, c, (a) => {
        a.x -= c.offsetX;
        a.y -= c.offsetY;
        b && b(a);
      });
    },
    U4(a, b) {
      const c = map.Lb;
      this.Sa === Qa && c && (a.x += this.offsetX,
      a.y += this.offsetY,
      gb.XJ(a, this, b));
    },
    te(a) {
      if (!this.ux()) return new hb();
      var b = a || {};
      var a = b.margins || [0, 0, 0, 0];
      const c = b.zoom || q;
      var b = this.Zb({
        x: a[3],
        y: this.height - a[2],
      }, c);
      var a = this.Zb({
        x: this.width - a[1],
        y: a[0],
      }, c);
      return new hb(b, a);
    },
    ux() {
      return !!this.loaded;
    },
    vR(a, b) {
      for (var c = this.wa(), e = b.margins || [10, 10, 10, 10], f = b.zoomFactor || 0, g = e[1] + e[3], e = e[0] + e[2], i = c.mf(), k = c = c.Te(); k >= i; k--) {
        const m = this.wa().Xb(k);
        if (a.sF().lng / m < this.width - g && a.sF().lat / m < this.height - e) break;
      }
      k += f;
      k < i && (k = i);
      k > c && (k = c);
      return k;
    },
    Gs(a, b) {
      let c = {
        center: this.Nb(),
        zoom: this.ja(),
      };
      if (!a || !(a instanceof hb) && a.length === 0 || a instanceof hb && a.rj()) return c;
      let e = [];
      a instanceof hb ? (e.push(a.Qf()),
      e.push(a.Ve())) : e = a.slice(0);
      for (var b = b || {}, f = [], g = 0, i = e.length; g < i; g++) {
        const k = Ya(e[g], this.M.Ia);
        f.push(this.Bc.ii(k, this.Lb));
      }
      e = new hb();
      for (g = f.length - 1; g >= 0; g--) e.extend(f[g]);
      if (e.rj()) return c;
      c = e.Nb();
      f = this.vR(e, b);
      b.margins && (e = b.margins,
      g = (e[1] - e[3]) / 2,
      e = (e[0] - e[2]) / 2,
      i = this.wa().Xb(f),
      b.offset && (g = b.offset.width,
      e = b.offset.height),
      c.lng += i * g,
      c.lat += i * e);
      c = this.Bc.nh(c, this.Lb);
      return {
        center: cb(new J(c.lng, c.lat), this.M.Ia),
        zoom: f,
      };
    },
    vh(a, b) {
      let c;
      c = a && a.center ? a : this.Gs(a, b);
      var b = b || {};
      const e = b.delay || 200;
      if (c.zoom === this.Xa && b.enableAnimation !== t) {
        const f = this;
        setTimeout(() => {
          f.qi(c.center, {
            duration: 210,
          });
        }, e);
      } else this.od(c.center, c.zoom);
    },
    Rf: x('Xd'),
    ih() {
      return this.aa.sb && this.aa.sb.bb() ? this.aa.sb : q;
    },
    getDistance(a, b) {
      if (a && b) {
        if (a.Sb(b)) return 0;
        var c = this.M ? this.M.Ia : 5;
        var a = Ya(a, c);
        var b = Ya(b, c);
        var c = 0;
        var c = T.uk(a, b);
        if (c === q || c === l) c = 0;
        return c;
      }
    },
    Zw() {
      const a = [];
      let b = this.Ba;
      const c = this.De;
      if (b) for (var e in b) b[e] instanceof ib && a.push(b[e]);
      if (c) {
        e = 0;
        for (b = c.length; e < b; e++) a.push(c[e]);
      }
      return a;
    },
    wa() {
      this.Sa.$E(this.M.Ia);
      return this.Sa;
    },
    LX: x('Dd'),
    su() {
      for (var a = this.aa.GE; a < D.hr.length; a++) D.hr[a](this);
      this.aa.GE = a;
    },
    UE(a) {
      this.Lb = Qa.sk(a);
      this.nw = Qa.TK(this.Lb);
      this.Sa === Qa && this.Bc instanceof jb && (this.Bc.$i = this.Lb);
    },
    setDefaultCursor(a) {
      this.M.wc = a;
      this.platform && (this.platform.style.cursor = this.M.wc);
    },
    getDefaultCursor() {
      return this.M.wc;
    },
    setDraggingCursor(a) {
      this.M.Gd = a;
    },
    getDraggingCursor() {
      return this.M.Gd;
    },
    mx() {
      return this.M.rW && this.M.devicePixelRatio >= 1.5;
    },
    wB(a, b) {
      b ? this.Gh[b] || (this.Gh[b] = {}) : b = 'custom';
      a.tag = b;
      a instanceof kb && (this.Gh[b][a.ca] = a,
      a.ya(this));
      const c = this;
      Ta.load('hotspot', () => {
        c.su();
      }, p);
    },
    KZ(a, b) {
      b || (b = 'custom');
      this.Gh[b][a.ca] && delete this.Gh[b][a.ca];
    },
    qw(a) {
      a || (a = 'custom');
      this.Gh[a] = {};
    },
    Du() {
      const a = this.Sa.mf();
      const b = this.Sa.Te();
      const c = this.M;
      c.fc = c.AO || a;
      c.mc = c.zO || b;
      c.fc < a && (c.fc = a);
      c.mc > b && (c.mc = b);
    },
    setMinZoom(a) {
      a = Math.round(a);
      a > this.M.mc && (a = this.M.mc);
      this.M.AO = a;
      this.aJ();
    },
    setMaxZoom(a) {
      a = Math.round(a);
      a < this.M.fc && (a = this.M.fc);
      this.M.zO = a;
      this.aJ();
    },
    aJ() {
      this.Du();
      const a = this.M;
      this.Xa < a.fc ? this.Qc(a.fc) : this.Xa > a.mc && this.Qc(a.mc);
      const b = new P('onzoomspanchange');
      b.fc = a.fc;
      b.mc = a.mc;
      this.dispatchEvent(b);
    },
    L3: x('qB'),
    getKey() {
      return pa;
    },
    o_(a) {
      function b(a) {
        c.L_ = a;
        const b = `${D.nd}custom/v2/mapstyle`;
        var g = `version=4&ak=${pa}&`;
        var g = `${g}is_all=true&is_new=1&` + `styles=${encodeURIComponent(c.lF(a, f))}`;
        lb(b, g, window[`${e}cb`]);
      }
      var c = this;
      var e = this.ca;
      D.aq('cus.fire', 'count', 'z_setmapstylev2count');
      this.fy(t);
      this.M.PY = p;
      window.MPC_Mgr && window.MPC_Mgr[c.ca] && window.MPC_Mgr[c.ca].close();
      c.M.fm = t;
      this.addEventListener('hidecopyright', () => {
        c.kk.$();
        c.M.yo = !!a.customEditor;
        c.M.yo === t && c.TE(new N(1, 1));
      });
      c.kk && c.kk.$();
      this.M.yo = !!a.customEditor;
      this.M.D5 = !!a.sharing;
      this.M.j5 = !!a.preview;
      this.M.yo === t && this.TE(new N(1, 1));
      Ta.load('hotspot', () => {
        c.su();
      }, p);
      window[`${e}zoomRegion`] = {};
      window.o6 = [];
      window[`${e}zoomStyleBody`] = [];
      window[`${e}zoomFrontStyle`] = {};
      var f = this.ja();
      A.extend({}, a);
      window[`${e}cb`] = function (a) {
        a = JSON.parse(a);
        a.status === 0 && (a.data.style.length === 3 ? (window[`${e}_bmap_baseFs`] = a.data.style,
        window[`${e}StyleBody`] = a.data.style[2]) : window[`${e}StyleBody`] = a.data.style,
        c.vO(),
        c.qY());
      };
      if (a.styleId) {
        let g = 'jsapi';
        a.sharing ? g = 'sharing' : a.preview && (g = 'preview');
        this.jX(a.styleId, g, b);
      } else b(a.styleJson);
      window.iconSetInfo_high || oa(`${D.url.proto + D.url.domain.TILE_ONLINE_URLS[0]}/sty/icons_na2x.js?udt=20190108&v=001&from=jsapi`);
    },
    jX(a, b, c) {
      const e = this;
      const f = this.ca;
      const g = (1E5 * Math.random()).toFixed(0);
      window[`${f}_cbk_si_phpui${g}`] = function (a) {
        let b = [];
        a.result && (a.result.error === 0 && a.content && a.content.status === 0) && (b = e.Px(a.content.data.json));
        c && c(b);
      };
      window[`${f}_cbk_si_api${g}`] = function (a) {
        let b = [];
        a.status === 0 && (b = a.info ? e.Px(a.info.json) : e.Px(a.data.json));
        c && c(b);
      };
      let i = '/apiconsole/custommap/';
      switch (b) {
        case 'jsapi':
          i = `${D.nd}?qt=custom_map&v=3.0`;
          i += `&style_id=${a}&type=publish&ak=${pa}`;
          i += `&callback=${f}_cbk_si_phpui${g}`;
          break;
        case 'sharing':
          i = `${i}getSharingJson` + `?styleid=${a}&type=edit` + `&ck=${f}_cbk_si_api${g}`;
          break;
        case 'preview':
          i = `${i}getJson` + `?styleid=${a}&type=edit` + `&ck=${f}_cbk_si_api${g}`;
      }
      oa(i);
    },
    MV() {
      Array.prototype.map || (Array.prototype.map = function (a, b) {
        let c; let e; let
          f;
        this == q && aa(new TypeError(' this is null or not defined'));
        const g = Object(this);
        const i = g.length >>> 0;
        Object.prototype.toString.call(a) != '[object Function]' && aa(new TypeError(`${a} is not a function`));
        b && (c = b);
        e = Array(i);
        for (f = 0; f < i;) {
          var k;
          f in g && (k = g[f],
          k = a.call(c, k, f, g),
          e[f] = k);
          f++;
        }
        return e;
      }
      );
    },
    Px(a) {
      if (a === q || a === '') return [];
      this.MV();
      const b = {
        t: 'featureType',
        e: 'elementType',
        v: 'visibility',
        c: 'color',
        l: 'lightness',
        s: 'saturation',
        w: 'weight',
        z: 'level',
        h: 'hue',
        f: 'fontsize',
        zri: 'curZoomRegionId',
        zr: 'curZoomRegion',
      };
      const c = {
        all: 'all',
        g: 'geometry',
        'g.f': 'geometry.fill',
        'g.s': 'geometry.stroke',
        l: 'labels',
        'l.t.f': 'labels.text.fill',
        'l.t.s': 'labels.text.stroke',
        'l.t': 'labels.text',
        'l.i': 'labels.icon',
        'g.tf': 'geometry.fill',
      };
      return a.split(',').map((a) => {
        var a = a.split('|').map((a) => {
          const e = b[a.split(':')[0]];
          var a = c[a.split(':')[1]] ? c[a.split(':')[1]] : a.split(':')[1];
          switch (a) {
            case 'poi':
              a = 'poilabel';
              break;
            case 'districtlabel':
              a = 'districtlabel';
          }
          const f = {};
          f[e] = a;
          return f;
        });
        const f = a[0];
        let g = 1;
        a[1].elementType && (g = 2,
        A.extend(f, a[1]));
        for (var i = {}; g < a.length; g++) A.extend(i, a[g]);
        return A.extend(f, {
          stylers: i,
        });
      });
    },
    QX() {
      return this.$e.gg;
    },
    y3(a, b) {
      const c = this;
      const e = this.ca;
      const f = (1E5 * Math.random()).toFixed(0);
      window[`${e}_cbk${f}`] = function (b) {
        b = JSON.parse(b);
        b = b.data.style.length === 3 ? b.data.style[2] : b.data.style;
        c.r0(b, a);
        c.vO(a);
        b = new P(`onzoomfeatureload${a}`);
        c.dispatchEvent(b);
        delete window[`${e}_cbk${f}`];
      };
      const g = `${D.nd}custom/v2/mapstyle`;
      var i = `ak=${pa}&`;
      var i = `${i}is_all=true&is_new=1&`;
      b.styleJson ? i += `styles=${encodeURIComponent(this.lF(b.styleJson, parseInt(a, 10)))}` : b.styleId && (i += `styles=${encodeURIComponent(c.lF(c.L_, parseInt(a, 10)))}`);
      lb(g, i, window[`${e}_cbk${f}`]);
    },
    TE(a, b) {
      const c = new P('oncopyrightoffsetchange', {
        kE: a,
        AV: b,
      });
      this.M.bK = b;
      this.dispatchEvent(c);
    },
    Bt(a) {
      let b = this;
      window.MPC_Mgr && window.MPC_Mgr[b.ca] && window.MPC_Mgr[b.ca].close();
      b.M.fm = t;
      D.aq('cus.fire', 'count', 'z_setmapstylecount');
      if (a) {
        b = this;
        a.styleJson && (a.styleStr = b.M_(a.styleJson));
        I() && A.fa.ay ? setTimeout(() => {
          b.M.xe = a;
          b.dispatchEvent(new P('onsetcustomstyles', a));
        }, 50) : (this.M.xe = a,
        this.dispatchEvent(new P('onsetcustomstyles', a)),
        this.LL(b.M.xe.geotableId));
        let c = {
          style: a.style,
        };
        a.features && a.features.length > 0 && (c.features = p);
        a.styleJson && a.styleJson.length > 0 && (c.styleJson = p);
        Ra(5050, c);
        a.style && (c = b.M.UB[a.style] ? b.M.UB[a.style].backColor : b.M.UB.normal.backColor) && (this.Ra().style.backgroundColor = c);
      }
    },
    jY(a) {
      this.controls || (this.controls = {
        navigationControl: new mb(),
        scaleControl: new nb(),
        overviewMapControl: new ob(),
        mapTypeControl: new pb(),
      });
      const b = this; let
        c;
      for (c in this.controls) b.lN(b.controls[c]);
      a = a || [];
      A.jc.Mb(a, (a) => {
        b.Fr(b.controls[a]);
      });
    },
    LL(a) {
      a ? this.Ur && this.Ur.Bf === a || (this.Yf(this.Ur),
      this.Ur = new qb({
        geotableId: a,
      }),
      this.Ne(this.Ur)) : this.Yf(this.Ur);
    },
    Od() {
      const a = this.ja() >= this.M.AF && this.wa() === Na && this.ja() <= 18;
      let b = t;
      try {
        document.createElement('canvas').getContext('2d'),
        b = p;
      } catch (c) {
        b = t;
      }
      return a && b;
    },
    getCurrentCity() {
      return {
        name: this.bh,
        code: this.Ir,
      };
    },
    Cs() {
      this.W.Jn();
      return this.W;
    },
    nY(a) {
      Na.setMaxZoom(a.maxZoom || 19);
      const b = new P('oninitindoorlayer');
      b.We = a;
      this.dispatchEvent(b);
      this.M.sg = t;
    },
    qY(a) {
      if (this.M.sg) {
        var b = new P('onupdatestyles');
        this.dispatchEvent(b);
      } else {
        b = new P('oninitindoorlayer'),
        b.We = a,
        this.dispatchEvent(b),
        this.M.sg = p,
        this.M.ok = p;
      }
    },
    fy(a) {
      this.M.uE = a;
      this.$e.Ib || (this.$e.Ib = this.$e.tj[0].Ib);
      this.$e.Ib.parentElement.style.display = a ? 'block' : 'none';
    },
    EN(a) {
      this.$e.gg.style.display = a ? 'block' : 'none';
    },
    setPanorama(a) {
      this.W = a;
      this.W.XE(this);
    },
    lF(a, b) {
      for (var c = this.ca, e = {
          featureType: 't',
          elementType: 'e',
          visibility: 'v',
          color: 'c',
          lightness: 'l',
          saturation: 's',
          weight: 'w',
          level: 'z',
          hue: 'h',
          fontsize: 'f',
        }, f = {
          all: 'all',
          geometry: 'g',
          'geometry.fill': 'g.f',
          'geometry.stroke': 'g.s',
          labels: 'l',
          'labels.text.fill': 'l.t.f',
          'labels.text.stroke': 'l.t.s',
          'labels.text': 'l.t',
          'labels.icon': 'l.i',
          'geometry.topfill': 'g.f',
        }, g = [], i = this.Sa.mf(); i <= this.Sa.Te(); i++) window[`${c}zoomFrontStyle`][i] = {};
      window[`${c}zoomFrontStyle`].main = {};
      for (var i = 0, k; k = a[i]; i++) {
        if (!this.zY(k)) {
          b = this.dX(k, b);
          if ((k.featureType === 'land' || k.featureType === 'all' || k.featureType === 'background') && typeof k.elementType === 'string' && (k.elementType === 'geometry' || k.elementType === 'geometry.fill' || k.elementType === 'all') && k.stylers) {
            k.stylers.color && (window[`${c}zoomFrontStyle`][b].bmapLandColor = k.stylers.color),
            k.stylers.visibility && k.stylers.visibility === 'off' && (window[`${c}zoomFrontStyle`][b].bmapLandColor = '#00000000');
          }
          k.featureType === 'railway' && (typeof k.elementType === 'string' && k.stylers) && (k.stylers.color && (k.elementType === 'geometry' && (window[`${c}zoomFrontStyle`][b].bmapRailwayFillColor = k.stylers.color,
          window[`${c}zoomFrontStyle`][b].bmapRailwayStrokeColor = k.stylers.color),
          k.elementType === 'geometry.fill' && (window[`${c}zoomFrontStyle`][b].bmapRailwayFillColor = k.stylers.color),
          k.elementType === 'geometry.stroke' && (window[`${c}zoomFrontStyle`][b].bmapRailwayStrokeColor = k.stylers.color)),
          k.stylers.visibility && (window[`${c}zoomFrontStyle`][b].bmapRailwayVisibility = k.stylers.visibility));
          k.featureType === 'roadarrow' && (k.elementType === 'labels.icon' && k.stylers) && (window[`${c}zoomFrontStyle`][b].bmapRoadarrowVisibility = k.stylers.visibility);
          const m = {};
          A.extend(m, k);
          k = m.stylers;
          delete m.stylers;
          A.extend(m, k);
          k = [];
          for (const n in e) {
            if (m[n] && !this.vY(n)) {
              if (n === 'elementType') k.push(`${e[n]}:${f[m[n]]}`);
              else {
                switch (m[n]) {
                  case 'poilabel':
                    m[n] = 'poi';
                    break;
                  case 'districtlabel':
                    m[n] = 'label';
                }
                k.push(`${e[n]}:${m[n]}`);
              }
            }
          }
          k.length > 2 && g.push(k.join('|'));
        }
      }
      return g.join(',');
    },
    M_(a) {
      for (var b = {
          featureType: 't',
          elementType: 'e',
          visibility: 'v',
          color: 'c',
          lightness: 'l',
          saturation: 's',
          weight: 'w',
          zoom: 'z',
          hue: 'h',
        }, c = {
          all: 'all',
          geometry: 'g',
          'geometry.fill': 'g.f',
          'geometry.stroke': 'g.s',
          labels: 'l',
          'labels.text.fill': 'l.t.f',
          'labels.text.stroke': 'l.t.s',
          'lables.text': 'l.t',
          'labels.icon': 'l.i',
        }, e = [], f = 0, g; g = a[f]; f++) {
        var i = g.stylers;
        delete g.stylers;
        A.extend(g, i);
        var i = []; var
          k;
        for (k in b) {
          if (g[k]) {
            if (k === 'elementType') i.push(`${b[k]}:${c[g[k]]}`);
            else {
              switch (g[k]) {
                case 'poilabel':
                  g[k] = 'poi';
                  break;
                case 'districtlabel':
                  g[k] = 'label';
              }
              i.push(`${b[k]}:${g[k]}`);
            }
          }
        }
        i.length > 2 && e.push(i.join('|'));
      }
      return e.join(',');
    },
    dX(a) {
      a = a.stylers.level;
      return a === l ? 'main' : parseInt(a, 10);
    },
    zY(a) {
      const b = {};
      A.extend(b, a.stylers);
      delete b.curZoomRegionId;
      delete b.curZoomRegion;
      delete b.level;
      return A.TD(b) ? p : t;
    },
    k4(a, b) {
      const c = a.stylers.level;
      return c === l ? p : c === `${b}` ? p : t;
    },
    vY(a) {
      return {
        curZoomRegionId: p,
        curZoomRegion: p,
      }[a] ? p : t;
    },
    M3(a, b) {
      const c = a.stylers.level;
      const e = {};
      A.extend(e, b);
      c !== l && (e[parseInt(c, 10)] = p);
      return e;
    },
    r0(a, b) {
      const c = this.ca;
      window[`${c}zoomStyleBody`][b] = a;
      if (!window[`${c}zoomRegion`][b]) for (let e = this.Sa.mf(), f = this.Sa.Te(); e <= f; e++) window[`${c}zoomRegion`][e] || (window[`${c}zoomStyleBody`][e] = a);
    },
    vO() {
      const a = this.ca;
      if (window[`${a}zoomFrontStyle`].main.bmapRoadarrowVisibility) for (var b = this.Sa.mf(); b <= this.Sa.Te(); b++) window[`${a}zoomFrontStyle`][b].bmapRoadarrowVisibility || (window[`${a}zoomFrontStyle`][b].bmapRoadarrowVisibility = window[`${a}zoomFrontStyle`].main.bmapRoadarrowVisibility);
      if (window[`${a}zoomFrontStyle`].main.bmapLandColor) for (b = this.Sa.mf(); b <= this.Sa.Te(); b++) window[`${a}zoomFrontStyle`][b].bmapLandColor || (window[`${a}zoomFrontStyle`][b].bmapLandColor = window[`${a}zoomFrontStyle`].main.bmapLandColor);
      if (window[`${a}zoomFrontStyle`].main.bmapRailwayFillColor) for (b = this.Sa.mf(); b <= this.Sa.Te(); b++) window[`${a}zoomFrontStyle`][b].bmapRailwayFillColor || (window[`${a}zoomFrontStyle`][b].bmapRailwayFillColor = window[`${a}zoomFrontStyle`].main.bmapRailwayFillColor);
      if (window[`${a}zoomFrontStyle`].main.bmapRailwayStrokeColor) for (b = this.Sa.mf(); b <= this.Sa.Te(); b++) window[`${a}zoomFrontStyle`][b].bmapRailwayStrokeColor || (window[`${a}zoomFrontStyle`][b].bmapRailwayStrokeColor = window[`${a}zoomFrontStyle`].main.bmapRailwayStrokeColor);
      if (window[`${a}zoomFrontStyle`].main.bmapRailwayVisibility) for (b = this.Sa.mf(); b <= this.Sa.Te(); b++) window[`${a}zoomFrontStyle`][b].bmapRailwayVisibility || (window[`${a}zoomFrontStyle`][b].bmapRailwayVisibility = window[`${a}zoomFrontStyle`].main.bmapRailwayVisibility);
    },
    m2(a, b) {
      const c = {};
      A.extend(c, a);
      if (c[b]) {
        for (let e = this.Sa.mf(), f = this.Sa.Te(); e <= f; e++) {
          if (!c[e]) {
            c[e] = p;
            break;
          }
        }
        delete c[b];
      }
      return c;
    },
    i4(a) {
      return a.Qs || a.uid === '0' ? t : p;
    },
    jV() {
      delete this.Ei.AZ;
    },
    r2() {
      this.Ei = {};
    },
    io(a, b, c) {
      if (!this.M.yo) return t;
      a = a || `sp${this.aa.G5++}`;
      if (b && b.length !== 0) {
        return c = c || {},
        this.Ei[a] = this.Ei[a] || {
          polygon: [],
          polyline: [],
        },
        this.Ei = this.Ei || {},
        this.Ei[a][c.type].push({
          gF: b,
          Vb: c.Vb,
          type: c.type,
          style: c.style,
        }),
        a;
      }
    },
    EF(a) {
      return rb / Math.pow(2, 18 - a);
    },
  });
  var rb = 4.007545274461451E7;
  function Ra(a, b) {
    if (a) {
      var b = b || {}; let c = ''; let
        e;
      for (e in b) c = `${c}&${e}=${encodeURIComponent(b[e])}`;
      const f = function (a) {
        a && (sb = p,
        setTimeout(() => {
          // tb.src = D.nd + "images/blank.gif?" + a.src // 修改
          tb.src = `${D.oa}images/blank.gif?${a.src}`;
        }, 50));
      };
      const g = function () {
        const a = ub.shift();
        a && f(a);
      };
      e = (1E8 * Math.random()).toFixed(0);
      sb ? ub.push({
        src: `product=jsapi&sub_product=jsapi&v=${D.version}&sub_product_v=${D.version}&t=${e}&code=${a}&da_src=${a}${c}`,
      }) : f({
        src: `product=jsapi&sub_product=jsapi&v=${D.version}&sub_product_v=${D.version}&t=${e}&code=${a}&da_src=${a}${c}`,
      });
      vb || (A.V(tb, 'load', () => {
        sb = t;
        g();
      }),
      A.V(tb, 'error', () => {
        sb = t;
        g();
      }),
      vb = p);
    }
  }
  let sb; let vb; var ub = []; var
    tb = new Image();
  Ra(5E3, {
    device_pixel_ratio: window.devicePixelRatio,
    platform: navigator.platform,
  });
  D.FL = {
    TILE_BASE_URLS: ['gss0.bdstatic.com/5bwHcj7lABFU8t_jkk_Z1zRvfdw6buu', 'gss0.bdstatic.com/5bwHcj7lABFV8t_jkk_Z1zRvfdw6buu', 'gss0.bdstatic.com/5bwHcj7lABFS8t_jkk_Z1zRvfdw6buu', 'gss0.bdstatic.com/5bwHcj7lABFT8t_jkk_Z1zRvfdw6buu', 'gss0.bdstatic.com/5bwHcj7lABFY8t_jkk_Z1zRvfdw6buu'],
    TILE_ONLINE_URLS: ['maponline0.bdimg.com', 'maponline1.bdimg.com', 'maponline2.bdimg.com', 'maponline3.bdimg.com'],
    TIlE_PERSPECT_URLS: ['gss0.bdstatic.com/-OR1cTe9KgQFm2e88IuM_a', 'gss0.bdstatic.com/-ON1cTe9KgQFm2e88IuM_a', 'gss0.bdstatic.com/-OZ1cTe9KgQFm2e88IuM_a', 'gss0.bdstatic.com/-OV1cTe9KgQFm2e88IuM_a'],
    geolocControl: 'gsp0.baidu.com/8LkJsjOpB1gCo2Kml5_Y_D3',
    TILES_YUN_HOST: ['gsp0.baidu.com/-eR1bSahKgkFkRGko9WTAnF6hhy', 'gsp0.baidu.com/-eN1bSahKgkFkRGko9WTAnF6hhy', 'gsp0.baidu.com/-eZ1bSahKgkFkRGko9WTAnF6hhy', 'gsp0.baidu.com/-eV1bSahKgkFkRGko9WTAnF6hhy'],
    traffic: 'gsp0.baidu.com/7_AZsjOpB1gCo2Kml5_Y_DAcsMJiwa',
    iw_pano: 'gss0.bdstatic.com/5LUZemba_QUU8t7mm9GUKT-xh_',
    message: 'gsp0.baidu.com/7vo0bSba2gU2pMbgoY3K',
    baidumap: 'gsp0.baidu.com/80MWsjip0QIZ8tyhnq',
    wuxian: 'gsp0.baidu.com/6a1OdTeaKgQFm2e88IuM_a',
    pano: ['gss0.bdstatic.com/5LUZemba_QUU8t7mm9GUKT-xh_', 'gss0.bdstatic.com/5LUZemfa_QUU8t7mm9GUKT-xh_', 'gss0.bdstatic.com/5LUZemja_QUU8t7mm9GUKT-xh_'],
    main_domain_nocdn: {
      baidu: 'gsp0.baidu.com/9_Q4sjOpB1gCo2Kml5_Y_D3',
      other: 'api.map.baidu.com',
    },
    main_domain_cdn: {
      baidu: ['gss0.bdstatic.com/9_Q4vHSd2RZ3otebn9fN2DJv', 'gss0.baidu.com/9_Q4vXSd2RZ3otebn9fN2DJv', 'gss0.bdstatic.com/9_Q4vnSd2RZ3otebn9fN2DJv'],
      other: ['api.map.baidu.com'],
      webmap: ['gss0.baidu.com/6b1IcTe9R1gBo1vgoIiO_jowehsv'],
    },
    map_click: 'gsp0.baidu.com/80MWbzKh2wt3n2qy8IqW0jdnxx1xbK',
    vector_traffic: 'gss0.bdstatic.com/8aZ1cTe9KgQIm2_p8IuM_a',
  };
  D.aY = {
    TILE_BASE_URLS: ['shangetu0.map.bdimg.com', 'shangetu1.map.bdimg.com', 'shangetu2.map.bdimg.com', 'shangetu3.map.bdimg.com', 'shangetu4.map.bdimg.com'],
    TILE_ONLINE_URLS: ['maponline0.bdimg.com', 'maponline1.bdimg.com', 'maponline2.bdimg.com', 'maponline3.bdimg.com'],
    TIlE_PERSPECT_URLS: ['d0.map.baidu.com', 'd1.map.baidu.com', 'd2.map.baidu.com', 'd3.map.baidu.com'],
    geolocControl: 'loc.map.baidu.com',
    TILES_YUN_HOST: ['g0.api.map.baidu.com', 'g1.api.map.baidu.com', 'g2.api.map.baidu.com', 'g3.api.map.baidu.com'],
    traffic: 'its.map.baidu.com:8002',
    iw_pano: 'mapsv0.bdimg.com',
    message: 'j.map.baidu.com',
    baidumap: 'map.baidu.com',
    wuxian: 'wuxian.baidu.com',
    pano: ['mapsv0.bdimg.com', 'mapsv1.bdimg.com'],
    main_domain_nocdn: {
      baidu: 'api.map.baidu.com',
    },
    main_domain_cdn: {
      baidu: ['api0.map.bdimg.com', 'api1.map.bdimg.com', 'api2.map.bdimg.com'],
      webmap: ['webmap0.map.bdimg.com'],
    },
    map_click: 'mapclick.map.baidu.com',
    vector_traffic: 'or.map.bdimg.com',
  };
  D.s0 = {
    0: {
      proto: 'http://',
      domain: D.aY,
    },
    1: {
      proto: 'https://',
      domain: D.FL,
    },
    2: {
      proto: 'https://',
      domain: D.FL,
    },
  };
  window.BMAP_PROTOCOL && window.BMAP_PROTOCOL === 'https' && (window.HOST_TYPE = 2);
  D.$t = window.HOST_TYPE || '0';
  D.url = D.s0[D.$t];
  D.fp = `${D.url.proto + D.url.domain.baidumap}/`;
  D.nd = `${D.url.proto + (D.$t == '2' ? D.url.domain.main_domain_nocdn.other : D.url.domain.main_domain_nocdn.baidu)}/`;
  // D.oa = D.url.proto + ("2" == D.$t ? D.url.domain.main_domain_cdn.other[0] : D.url.domain.main_domain_nocdn.baidu) + "/";
  D.oa = bmapcfg.home; // 修改，本地工具资源引用(离线路径)
  D.Yi = `${D.url.proto + D.url.domain.main_domain_cdn.webmap[0]}/`;
  D.di = function (a, b) {
    let c; let e; var
      b = b || '';
    switch (a) {
      case 'main_domain_nocdn':
        c = D.nd + b;
        break;
      case 'main_domain_cdn':
        c = D.oa + b;
        break;
      default:
        e = D.url.domain[a],
        Object.prototype.toString.call(e) == '[object Array]' ? (c = [],
        A.jc.Mb(e, (a, e) => {
          c[e] = `${D.url.proto + a}/${b}`;
        })) : c = `${D.url.proto + D.url.domain[a]}/${b}`;
    }
    return c;
  };
  function wb(a) {
    const b = {
      duration: 1E3,
      Ic: 30,
      Ao: 0,
      ac: xb.jM,
      it: u(),
    };
    this.ag = [];
    if (a) for (const c in a) b[c] = a[c];
    this.m = b;
    if (Za(b.Ao)) {
      const e = this;
      setTimeout(() => {
        e.start();
      }, b.Ao);
    } else b.Ao != yb && this.start();
  }
  var yb = 'INFINITE';
  wb.prototype.start = function () {
    this.uu = eb();
    this.xz = this.uu + this.m.duration;
    zb(this);
  };
  wb.prototype.add = function (a) {
    this.ag.push(a);
  };
  function zb(a) {
    let b = eb();
    b >= a.xz ? ($a(a.m.za) && a.m.za(a.m.ac(1)),
    $a(a.m.finish) && a.m.finish(),
    a.ag.length > 0 && (b = a.ag[0],
    b.ag = [].concat(a.ag.slice(1)),
    b.start())) : (a.by = a.m.ac((b - a.uu) / a.m.duration),
    $a(a.m.za) && a.m.za(a.by),
    a.mF || (a.Ar = setTimeout(() => {
      zb(a);
    }, 1E3 / a.m.Ic)));
  }
  wb.prototype.stop = function (a) {
    this.mF = p;
    for (let b = 0; b < this.ag.length; b++) {
      this.ag[b].stop(),
      this.ag[b] = q;
    }
    this.ag.length = 0;
    this.Ar && (clearTimeout(this.Ar),
    this.Ar = q);
    this.m.it(this.by);
    a && (this.xz = this.uu,
    zb(this));
  };
  wb.prototype.cancel = ga(1);
  var xb = {
    jM(a) {
      return a;
    },
    reverse(a) {
      return 1 - a;
    },
    AC(a) {
      return a * a;
    },
    yC(a) {
      return Math.pow(a, 3);
    },
    gs(a) {
      return -(a * (a - 2));
    },
    xK(a) {
      return Math.pow(a - 1, 3) + 1;
    },
    zC(a) {
      return a < 0.5 ? 2 * a * a : -2 * (a - 2) * a - 1;
    },
    I2(a) {
      return a < 0.5 ? 4 * Math.pow(a, 3) : 4 * Math.pow(a - 1, 3) + 1;
    },
    J2(a) {
      return (1 - Math.cos(Math.PI * a)) / 2;
    },
  };
  xb['ease-in'] = xb.AC;
  xb['ease-out'] = xb.gs;
  var H = {
    LF: 34,
    MF: 21,
    NF: new N(21, 32),
    QO: new N(10, 32),
    PO: new N(24, 36),
    OO: new N(12, 36),
    JF: new N(13, 1),
    sa: `${D.oa}images/`,
    c4: 'http://api0.map.bdimg.com/images/',
    KF: `${D.oa}images/markers_new.png`,
    MO: 24,
    NO: 73,
    NB: {
      北京: {
        Sx: 'bj',
        o: new J(116.403874, 39.914889),
      },
      上海: {
        Sx: 'sh',
        o: new J(121.487899, 31.249162),
      },
      深圳: {
        Sx: 'sz',
        o: new J(114.025974, 22.546054),
      },
      广州: {
        Sx: 'gz',
        o: new J(113.30765, 23.120049),
      },
    },
    fontFamily: 'arial,sans-serif',
  };
  A.fa.Re ? (A.extend(H, {
    jK: `url(${H.sa}ruler.cur),crosshair`,
    wc: '-moz-grab',
    Gd: '-moz-grabbing',
  }),
  A.platform.XL && (H.fontFamily = 'arial,simsun,sans-serif')) : A.fa.mw || A.fa.ay ? A.extend(H, {
    jK: `url(${H.sa}ruler.cur) 2 6,crosshair`,
    wc: `url(${H.sa}openhand.cur) 8 8,default`,
    Gd: `url(${H.sa}closedhand.cur) 8 8,move`,
  }) : A.extend(H, {
    jK: `url(${H.sa}ruler.cur),crosshair`,
    wc: `url(${H.sa}openhand.cur),default`,
    Gd: `url(${H.sa}closedhand.cur),move`,
  });
  function Ab(a, b) {
    const c = a.style;
    c.left = `${b[0]}px`;
    c.top = `${b[1]}px`;
  }
  function Bb(a) {
    A.fa.na > 0 ? a.unselectable = 'on' : a.style.MozUserSelect = 'none';
  }
  function Cb(a) {
    return a && a.parentNode && a.parentNode.nodeType !== 11;
  }
  function Db(a, b) {
    A.U.qx(a, 'beforeEnd', b);
    return a.lastChild;
  }
  function Eb(a) {
    for (var b = {
      left: 0,
      top: 0,
    }; a && a.offsetParent;) {
      b.left += a.offsetLeft,
      b.top += a.offsetTop,
      a = a.offsetParent;
    }
    return b;
  }
  function ma(a) {
    a = window.event || a;
    a.stopPropagation ? a.stopPropagation() : a.cancelBubble = p;
  }
  function Fb(a) {
    a = window.event || a;
    a.preventDefault ? a.preventDefault() : a.returnValue = t;
    return t;
  }
  function na(a) {
    ma(a);
    return Fb(a);
  }
  function Gb() {
    const a = document.documentElement;
    const b = document.body;
    return a && (a.scrollTop || a.scrollLeft) ? [a.scrollTop, a.scrollLeft] : b ? [b.scrollTop, b.scrollLeft] : [0, 0];
  }
  function Hb(a, b) {
    if (a && b) return Math.round(Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2)));
  }
  function Ib(a, b) {
    const c = []; var b = b || function (a) {
      return a;
    };
    let e;
    for (e in a) c.push(`${e}=${b(a[e])}`);
    return c.join('&');
  }
  function L(a, b, c) {
    let e = document.createElement(a);
    c && (e = document.createElementNS(c, a));
    return A.U.SE(e, b || {});
  }
  function Xa(a) {
    if (a.currentStyle) return a.currentStyle;
    if (a.ownerDocument && a.ownerDocument.defaultView) return a.ownerDocument.defaultView.getComputedStyle(a, q);
  }
  function $a(a) {
    return typeof a === 'function';
  }
  function Za(a) {
    return typeof a === 'number';
  }
  function bb(a) {
    return typeof a === 'string';
  }
  function Jb(a) {
    return typeof a !== 'undefined';
  }
  function Kb(a) {
    return typeof a === 'object';
  }
  const Lb = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  function Mb(a) {
    for (var b = '', c = 0; c < a.length; c++) {
      var e = a.charCodeAt(c) << 1;
      var f = e = e.toString(2);
      e.length < 8 && (f = `00000000${e}`,
      f = f.substr(e.length, 8));
      b += f;
    }
    a = 5 - b.length % 5;
    e = [];
    for (c = 0; c < a; c++) e[c] = '0';
    b = e.join('') + b;
    f = [];
    for (c = 0; c < b.length / 5; c++) {
      e = b.substr(5 * c, 5),
      f.push(String.fromCharCode(parseInt(e, 2) + 50));
    }
    return f.join('') + a.toString();
  }
  function Nb(a) {
    let b = '';
    let c;
    let e;
    let f = '';
    let g;
    let i = '';
    let k = 0;
    g = /[^A-Za-z0-9\+\/\=]/g;
    if (!a || g.exec(a)) return a;
    a = a.replace(/[^A-Za-z0-9\+\/\=]/g, '');
    do {
      c = Lb.indexOf(a.charAt(k++)),
      e = Lb.indexOf(a.charAt(k++)),
      g = Lb.indexOf(a.charAt(k++)),
      i = Lb.indexOf(a.charAt(k++)),
      c = c << 2 | e >> 4,
      e = (e & 15) << 4 | g >> 2,
      f = (g & 3) << 6 | i,
      b += String.fromCharCode(c),
      g != 64 && (b += String.fromCharCode(e)),
      i != 64 && (b += String.fromCharCode(f));
    }
    while (k < a.length);return b;
  }
  var P = A.lang.ku;
  function I() {
    return !(!A.platform.WD && !A.platform.yY && !A.platform.pj);
  }
  function Wa() {
    return !(!A.platform.XL && !A.platform.PL && !A.platform.FY);
  }
  function eb() {
    return (new Date()).getTime();
  }
  function Ob() {
    const a = document.body.appendChild(L('div'));
    a.innerHTML = '<v:shape id="vml_tester1" adj="1" />';
    let b = a.firstChild;
    if (!b.style) return t;
    b.style.behavior = 'url(#default#VML)';
    b = b ? typeof b.adj === 'object' : p;
    a.parentNode.removeChild(a);
    return b;
  }
  function Pb() {
    return !!document.implementation.hasFeature('http://www.w3.org/TR/SVG11/feature#Shape', '1.1');
  }
  function Qb() {
    return !!L('canvas').getContext;
  }
  function U(a) {
    return a * Math.PI / 180;
  }
  D.LY = (function () {
    let a = p;
    let b = p;
    let c = p;
    let e = p;
    let f = 0;
    let g = 0;
    let i = 0;
    let k = 0;
    return {
      tQ() {
        f += 1;
        a && (a = t,
        setTimeout(() => {
          Ra(5054, {
            pic: f,
          });
          a = p;
          f = 0;
        }, 1E4));
      },
      j1() {
        g += 1;
        b && (b = t,
        setTimeout(() => {
          Ra(5055, {
            move: g,
          });
          b = p;
          g = 0;
        }, 1E4));
      },
      l1() {
        i += 1;
        c && (c = t,
        setTimeout(() => {
          Ra(5056, {
            zoom: i,
          });
          c = p;
          i = 0;
        }, 1E4));
      },
      k1(a) {
        k += a;
        e && (e = t,
        setTimeout(() => {
          Ra(5057, {
            tile: k,
          });
          e = p;
          k = 0;
        }, 5E3));
      },
    };
  }());
  D.Rp = {
    aG: '#83a1ff',
    Tp: '#808080',
  };
  function Rb(a, b, c) {
    b.nE || (b.nE = [],
    b.handle = {});
    b.nE.push({
      filter: c,
      ns: a,
    });
    b.addEventListener || (b.addEventListener = function (a, c) {
      b.attachEvent(`on${a}`, c);
    }
    );
    b.handle.click || (b.addEventListener('click', (a) => {
      for (var c = a.target || a.srcElement; c != b;) {
        Sb(b.nE, (b, i) => {
          RegExp(i.filter).test(c.getAttribute('filter')) && i.ns.call(c, a, c.getAttribute('filter'));
        });
        c = c.parentNode;
      }
    }, t),
    b.handle.click = p);
  }
  function Sb(a, b) {
    for (let c = 0, e = a.length; c < e; c++) b(c, a[c]);
  }
  void (function (a, b, c) {
    void (function (a, b, c) {
      function i(a) {
        if (!a.zo) {
          for (var c = p, e = [], g = a.NZ, k = 0; g && k < g.length; k++) {
            let m = g[k];
            const n = ca[m] = ca[m] || {};
            if (n.zo || n == a) e.push(n.Nc);
            else {
              c = t;
              if (!n.NV && (m = (Aa.get('alias') || {})[m] || `${m}.js`,
              !K[m])) {
                K[m] = p;
                const o = b.createElement('script');
                const s = b.getElementsByTagName('script')[0];
                o.async = p;
                o.src = m;
                s.parentNode.insertBefore(o, s);
              }
              n.zy = n.zy || {};
              n.zy[a.name] = a;
            }
          }
          if (c) {
            a.zo = p;
            a.eK && (a.Nc = a.eK.apply(a, e));
            for (const v in a.zy) i(a.zy[v]);
          }
        }
      }
      function k(a) {
        return (a || new Date()) - E;
      }
      function m(a, b, c) {
        if (a) {
          typeof a === 'string' && (c = b,
          b = a,
          a = O);
          try {
            a == O ? (M[b] = M[b] || [],
            M[b].unshift(c)) : a.addEventListener ? a.addEventListener(b, c, t) : a.attachEvent && a.attachEvent(`on${b}`, c);
          } catch (e) {}
        }
      }
      function n(a, b, c) {
        if (a) {
          typeof a === 'string' && (c = b,
          b = a,
          a = O);
          try {
            if (a == O) {
              const e = M[b];
              if (e) for (let f = e.length; f--;) e[f] === c && e.splice(f, 1);
            } else a.removeEventListener ? a.removeEventListener(b, c, t) : a.detachEvent && a.detachEvent(`on${b}`, c);
          } catch (g) {}
        }
      }
      function o(a) {
        const b = M[a];
        let c = 0;
        if (b) {
          for (var e = [], f = arguments, g = 1; g < f.length; g++) e.push(f[g]);
          for (g = b.length; g--;) b[g].apply(this, e) && c++;
          return c;
        }
      }
      function s(a, b) {
        if (a && b) {
          let c = new Image(1, 1); const e = []; const f = `img_${+new Date()}`; let
            g;
          for (g in b) b[g] && e.push(`${g}=${encodeURIComponent(b[g])}`);
          O[f] = c;
          c.onload = c.onerror = function () {
            O[f] = c = c.onload = c.onerror = q;
            delete O[f];
          };
          c.src = `${a}?${e.join('&')}`;
        }
      }
      function v() {
        const a = arguments;
        var b = a[0];
        if (this.dK || /^(on|un|set|get|create)$/.test(b)) {
          for (var b = y.prototype[b], c = [], e = 1, f = a.length; e < f; e++) c.push(a[e]);
          typeof b === 'function' && b.apply(this, c);
        } else this.BJ.push(a);
      }
      function w(a, b) {
        const c = {}; let
          e;
        for (e in a) a.hasOwnProperty(e) && (c[e] = a[e]);
        for (e in b) b.hasOwnProperty(e) && (c[e] = b[e]);
        return c;
      }
      function y(a) {
        this.name = a;
        this.ks = {
          protocolParameter: {
            postUrl: q,
            protocolParameter: q,
          },
        };
        this.BJ = [];
        this.alog = O;
      }
      function z(a) {
        a = a || 'default';
        if (a == '*') {
          var a = []; var
            b;
          for (b in S) a.push(S[b]);
          return a;
        }
        (b = S[a]) || (b = S[a] = new y(a));
        return b;
      }
      let B = c.alog;
      if (!B || !B.zo) {
        const C = b.all && a.attachEvent;
        var E = B && B.dE || +new Date();
        const F = a.v4 || (+new Date()).toString(36) + Math.random().toString(36).substr(2, 3);
        let G = 0;
        var K = {};
        var O = function (a) {
          const b = arguments; let c; let e; let f; let
            g;
          if (a == 'define' || a == 'require') {
            for (e = 1; e < b.length; e++) {
              switch (typeof b[e]) {
                case 'string':
                  c = b[e];
                  break;
                case 'object':
                  f = b[e];
                  break;
                case 'function':
                  g = b[e];
              }
            }
            a == 'require' && (c && !f && (f = [c]),
            c = q);
            c = !c ? `#${G++}` : c;
            e = ca[c] = ca[c] || {};
            e.zo || (e.name = c,
            e.NZ = f,
            e.eK = g,
            a == 'define' && (e.NV = p),
            i(e));
          } else {
            typeof a === 'function' ? a(O) : (`${a}`).replace(/^(?:([\w$_]+)\.)?(\w+)$/, (a, c, e) => {
              b[0] = e;
              v.apply(O.wF(c), b);
            });
          }
        };
        var M = {};
        var S = {};
        var ca = {
          a2: {
            name: 'alog',
            zo: p,
            Nc: O,
          },
        };
        y.prototype.start = y.prototype.create = function (a) {
          if (!this.dK) {
            typeof a === 'object' && this.set(a);
            this.dK = new Date();
            for (this.ls('create', this); a = this.BJ.shift();) v.apply(this, a);
          }
        };
        y.prototype.send = function (a, b) {
          let c = w({
            ts: k().toString(36),
            t: a,
            sid: F,
          }, this.ks);
          if (typeof b === 'object') c = w(c, b);
          else {
            var e = arguments;
            switch (a) {
              case 'pageview':
                e[1] && (c.page = e[1]);
                e[2] && (c.title = e[2]);
                break;
              case 'event':
                e[1] && (c.eventCategory = e[1]);
                e[2] && (c.eventAction = e[2]);
                e[3] && (c.eventLabel = e[3]);
                e[4] && (c.eventValue = e[4]);
                break;
              case 'timing':
                e[1] && (c.timingCategory = e[1]);
                e[2] && (c.timingVar = e[2]);
                e[3] && (c.timingValue = e[3]);
                e[4] && (c.timingLabel = e[4]);
                break;
              case 'exception':
                e[1] && (c.exDescription = e[1]);
                e[2] && (c.exFatal = e[2]);
                break;
              default:
                return;
            }
          }
          this.ls('send', c);
          let f;
          if (e = this.ks.protocolParameter) {
            const g = {};
            for (f in c) e[f] !== q && (g[e[f] || f] = c[f]);
            f = g;
          } else f = c;
          s(this.ks.postUrl, f);
        };
        y.prototype.set = function (a, b) {
          if (typeof a === 'string') {
            a == 'protocolParameter' && (b = w({
              postUrl: q,
              protocolParameter: q,
            }, b)),
            this.ks[a] = b;
          } else if (typeof a === 'object') for (const c in a) this.set(c, a[c]);
        };
        y.prototype.get = function (a, b) {
          const c = this.ks[a];
          typeof b === 'function' && b(c);
          return c;
        };
        y.prototype.ls = function (a, b) {
          return O.ls(`${this.name}.${a}`, b);
        };
        y.prototype.V = function (a, b) {
          O.V(`${this.name}.${a}`, b);
        };
        y.prototype.cd = function (a, b) {
          O.cd(`${this.name}.${a}`, b);
        };
        O.name = 'alog';
        O.Vb = F;
        O.zo = p;
        O.timestamp = k;
        O.cd = n;
        O.V = m;
        O.ls = o;
        O.wF = z;
        O('init');
        let Z = y.prototype;
        V(Z, {
          start: Z.start,
          create: Z.create,
          send: Z.send,
          set: Z.set,
          get: Z.get,
          on: Z.V,
          un: Z.cd,
          fire: Z.ls,
        });
        var Aa = z();
        Aa.set('protocolParameter', {
          Z1: q,
        });
        if (B) {
          Z = [].concat(B.zb || [], B.ut || []);
          B.zb = B.ut = q;
          for (const ta in O) O.hasOwnProperty(ta) && (B[ta] = O[ta]);
          O.zb = O.ut = {
            push(a) {
              O.apply(O, a);
            },
          };
          for (B = 0; B < Z.length; B++) O.apply(O, Z[B]);
        }
        c.alog = O;
        C && m(b, 'mouseup', (a) => {
          a = a.target || a.srcElement;
          a.nodeType == 1 && /^ajavascript:/i.test(a.tagName + a.href);
        });
        let Ga = t;
        a.onerror = function (a, b, e, f) {
          let i = p;
          !b && /^script error/i.test(a) && (Ga ? i = t : Ga = p);
          i && c.alog('exception.send', 'exception', {
            dt: a,
            cE: b,
            $s: e,
            Zl: f,
          });
          return t;
        };
        c.alog('exception.on', 'catch', (a) => {
          c.alog('exception.send', 'exception', {
            dt: a.dt,
            cE: a.path,
            $s: a.$s,
            method: a.method,
            IK: 'catch',
          });
        });
      }
    }(a, b, c));
    void (function (a, b, c) {
      let i = '18_3';
      I() && (i = '18_4');
      var k = 'http://static.tieba.baidu.com';
      a.location.protocol === 'https:' && (k = 'https://gsp0.baidu.com/5aAHeD3nKhI2p27j8IqW0jdnxx1xbK');
      const m = Math.random;
      var k = `${k}/tb/pms/img/st.gif`;
      var n = {
        th: '0.1',
      };
      const o = {
        th: '0.1',
      };
      const s = {
        th: '0.1',
      };
      const v = {
        th: '0',
      };
      if (n && n.th && m() < n.th) {
        var w = c.alog.wF('monkey'); let y; var n = a.screen; const
          z = b.referrer;
        w.set('ver', 5);
        w.set('pid', 241);
        n && w.set('px', `${n.width}*${n.height}`);
        w.set('ref', z);
        c.alog('monkey.on', 'create', () => {
          y = c.alog.timestamp;
          w.set('protocolParameter', {
            reports: q,
          });
        });
        c.alog('monkey.on', 'send', (a) => {
          a.t == 'pageview' && (a.cmd = 'open');
          a.now && (a.ts = y(a.now).toString(36),
          a.now = '');
        });
        c.alog('monkey.create', {
          page: i,
          pid: '241',
          p: '18',
          dv: 6,
          postUrl: k,
          reports: {
            refer: 1,
          },
        });
        c.alog('monkey.send', 'pageview', {
          now: +new Date(),
        });
      }
      if (o && o.th && m() < o.th) {
        let B = t;
        a.onerror = function (a, b, e, f) {
          let i = p;
          !b && /^script error/i.test(a) && (B ? i = t : B = p);
          i && c.alog('exception.send', 'exception', {
            dt: a,
            cE: b,
            $s: e,
            Zl: f,
          });
          return t;
        };
        c.alog('exception.on', 'catch', (a) => {
          c.alog('exception.send', 'exception', {
            dt: a.dt,
            cE: a.path,
            $s: a.$s,
            method: a.method,
            IK: 'catch',
          });
        });
        c.alog('exception.create', {
          postUrl: k,
          dv: 7,
          page: i,
          pid: '170',
          p: '18',
        });
      }
      s && (s.th && m() < s.th) && (c.alog('cus.on', 'time', (a) => {
        const b = {}; let e = t; let
          f;
        if (a.toString() === '[object Object]') {
          for (const i in a) {
            i == 'page' ? b.page = a[i] : (f = parseInt(a[i]),
            f > 0 && /^z_/.test(i) && (e = p,
            b[i] = f));
          }
          e && c.alog('cus.send', 'time', b);
        }
      }),
      c.alog('cus.on', 'count', (a) => {
        const b = {};
        let e = t;
        typeof a === 'string' && (a = [a]);
        if (a instanceof Array) {
          for (let f = 0; f < a.length; f++) {
            /^z_/.test(a[f]) ? (e = p,
            b[a[f]] = 1) : /^page:/.test(a[f]) && (b.page = a[f].substring(5));
          }
        }
        e && c.alog('cus.send', 'count', b);
      }),
      c.alog('cus.create', {
        dv: 3,
        postUrl: k,
        page: i,
        p: '18',
      }));
      if (v && v.th && m() < v.th) {
        const C = ['Moz', 'O', 'ms', 'Webkit'];
        const E = ['-webkit-', '-moz-', '-o-', '-ms-'];
        const F = function () {
          return typeof b.createElement !== 'function' ? b.createElement(arguments[0]) : b.createElement.apply(b, arguments);
        };
        const G = F('dpFeatureTest').style;
        const K = function (a) {
          return O(a, l, l);
        };
        var O = function (a, b, c) {
          const e = a.charAt(0).toUpperCase() + a.slice(1);
          let f = (`${a} ${C.join(`${e} `)}${e}`).split(' ');
          if (typeof b === 'string' || typeof b === 'undefined') return M(f, b);
          f = (`${a} ${C.join(`${e} `)}${e}`).split(' ');
          a: {
            var a = f; let
              g;
            for (g in a) {
              if (a[g] in b) {
                if (c === t) {
                  b = a[g];
                  break a;
                }
                g = b[a[g]];
                b = typeof g === 'function' ? fnBind(g, c || b) : g;
                break a;
              }
            }
            b = t;
          }
          return b;
        };
        var M = function (a, b) {
          let c; let e; let
            f;
          e = a.length;
          for (c = 0; c < e; c++) {
            f = a[c];
            ~(`${f}`).indexOf('-') && (f = S(f));
            if (G[f] !== l) return b == 'pfx' ? f : p;
          }
          return t;
        };
        var S = function (a) {
          return a.replace(/([a-z])-([a-z])/g, (a, b, c) => b + c.toUpperCase()).replace(/^-/, '');
        };
        const ca = function (a, b, c) {
          if (a.indexOf('@') === 0) return atRule(a);
          a.indexOf('-') != -1 && (a = S(a));
          return !b ? O(a, 'pfx') : O(a, b, c);
        };
        const Z = function () {
          const a = F('canvas');
          return !(!a.getContext || !a.getContext('2d'));
        };
        const Aa = function () {
          const a = F('div');
          return 'draggable' in a || 'ondragstart' in a && 'ondrop' in a;
        };
        const ta = function () {
          try {
            localStorage.setItem('localStorage', 'localStorage');
            localStorage.removeItem('localStorage');
            return p;
          } catch (a) {
            return t;
          }
        };
        const Ga = function () {
          return 'content' in b.createElement('template');
        };
        const sa = function () {
          return 'createShadowRoot' in b.createElement('a');
        };
        const Va = function () {
          return 'registerElement' in b;
        };
        const Fe = function () {
          return 'import' in b.createElement('link');
        };
        const Uc = function () {
          return 'getItems' in b;
        };
        const jj = function () {
          return 'EventSource' in window;
        };
        const Ge = function (a, b) {
          const c = new Image();
          c.onload = function () {
            b(a, c.width > 0 && c.height > 0);
          };
          c.onerror = function () {
            b(a, t);
          };
          c.src = `data:image/webp;base64,${{
            y4: 'UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA',
            x4: 'UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA==',
            alpha: 'UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAARBxAR/Q9ERP8DAABWUDggGAAAABQBAJ0BKgEAAQAAAP4AAA3AAP7mtQAAAA==',
            hk: 'UklGRlIAAABXRUJQVlA4WAoAAAASAAAAAAAAAAAAQU5JTQYAAAD/////AABBTk1GJgAAAAAAAAAAAAAAAAAAAGQAAABWUDhMDQAAAC8AAAAQBxAREYiI/gcA',
          }[a]}`;
        };
        const He = function (a, b) {
          return $b.$h[`WebP-${a}`] = b;
        };
        const kj = function () {
          return 'openDatabase' in a;
        };
        const lj = function () {
          return 'performance' in a && 'timing' in a.performance;
        };
        const mj = function () {
          return 'performance' in a && 'mark' in a.performance;
        };
        const nj = function () {
          return !(!Array.prototype || !Array.prototype.every || !Array.prototype.filter || !Array.prototype.forEach || !Array.prototype.indexOf || !Array.prototype.lastIndexOf || !Array.prototype.map || !Array.prototype.some || !Array.prototype.reduce || !Array.prototype.reduceRight || !Array.isArray);
        };
        const oj = function () {
          return 'Promise' in a && 'cast' in a.Up && 'resolve' in a.Up && 'reject' in a.Up && 'all' in a.Up && 'race' in a.Up && (function () {
            let b;
            new a.Up(((a) => {
              b = a;
            }));
            return typeof b === 'function';
          }());
        };
        const pj = function () {
          const b = !!a.X0;
          const c = a.XMLHttpRequest && 'withCredentials' in new XMLHttpRequest();
          return !!a.a1 && b && c;
        };
        const qj = function () {
          return 'geolocation' in navigator;
        };
        const rj = function () {
          const b = F('canvas');
          const c = 'probablySupportsContext' in b ? 'probablySupportsContext' : 'supportsContext';
          return c in b ? b[c]('webgl') || b[c]('experimental-webgl') : 'WebGLRenderingContext' in a;
        };
        const sj = function () {
          return !!b.createElementNS && !!b.createElementNS('http://www.w3.org/2000/svg', 'svg').x2;
        };
        const tj = function () {
          return !!a.h1;
        };
        const uj = function () {
          return 'WebSocket' in a && a.e1.T0 === 2;
        };
        const vj = function () {
          return !!b.createElement('video').canPlayType;
        };
        const wj = function () {
          return !!b.createElement('audio').canPlayType;
        };
        const xj = function () {
          return !!(a.history && 'pushState' in a.history);
        };
        const yj = function () {
          return !(!a.V0 || !a.W0);
        };
        const zj = function () {
          return 'postMessage' in window;
        };
        const Aj = function () {
          return !!a.webkitNotifications || 'Notification' in a && 'permission' in a.iP && 'requestPermission' in a.iP;
        };
        const Bj = function () {
          for (var b = ['webkit', 'moz', 'o', 'ms'], c = a.requestAnimationFrame, f = 0; f < b.length && !c; ++f) c = a[`${b[f]}RequestAnimationFrame`];
          return !!c;
        };
        const Cj = function () {
          return 'JSON' in a && 'parse' in JSON && 'stringify' in JSON;
        };
        const Dj = function () {
          return !(!ca('exitFullscreen', b, t) && !ca('cancelFullScreen', b, t));
        };
        const Ej = function () {
          return !!ca('Intl', a);
        };
        const Fj = function () {
          return K('flexBasis');
        };
        const Gj = function () {
          return !!K('perspective');
        };
        const Hj = function () {
          return K('shapeOutside');
        };
        const Ij = function () {
          const a = F('div');
          a.style.cssText = E.join('filter:blur(2px); ');
          return !!a.style.length && (b.documentMode === l || b.documentMode > 9);
        };
        const Jj = function () {
          return 'XMLHttpRequest' in a && 'withCredentials' in new XMLHttpRequest();
        };
        const Kj = function () {
          return F('progress').max !== l;
        };
        const Lj = function () {
          return F('meter').max !== l;
        };
        const Mj = function () {
          return 'sendBeacon' in navigator;
        };
        const Nj = function () {
          return K('borderRadius');
        };
        const Oj = function () {
          return K('boxShadow');
        };
        const Pj = function () {
          const a = F('div').style;
          a.cssText = E.join('opacity:.55;');
          return /^0.55$/.test(a.opacity);
        };
        const Qj = function () {
          return M(['textShadow'], l);
        };
        const Rj = function () {
          return K('animationName');
        };
        const Sj = function () {
          return K('transition');
        };
        const Tj = function () {
          return navigator.userAgent.indexOf('Android 2.') === -1 && K('transform');
        };
        var $b = {
          $h: {},
          ra(a, b, c) {
            this.$h[a] = b.apply(this, [].slice.call(arguments, 2));
          },
          Ed(a, b) {
            a.apply(this, [].slice.call(arguments, 1));
          },
          SZ() {
            this.ra('bdrs', Nj);
            this.ra('bxsd', Oj);
            this.ra('opat', Pj);
            this.ra('txsd', Qj);
            this.ra('anim', Rj);
            this.ra('trsi', Sj);
            this.ra('trfm', Tj);
            this.ra('flex', Fj);
            this.ra('3dtr', Gj);
            this.ra('shpe', Hj);
            this.ra('fltr', Ij);
            this.ra('cavs', Z);
            this.ra('dgdp', Aa);
            this.ra('locs', ta);
            this.ra('wctem', Ga);
            this.ra('wcsdd', sa);
            this.ra('wccse', Va);
            this.ra('wchti', Fe);
            this.Ed(Ge, 'lossy', He);
            this.Ed(Ge, 'lossless', He);
            this.Ed(Ge, 'alpha', He);
            this.Ed(Ge, 'animation', He);
            this.ra('wsql', kj);
            this.ra('natm', lj);
            this.ra('ustm', mj);
            this.ra('arra', nj);
            this.ra('prms', oj);
            this.ra('xhr2', pj);
            this.ra('wbgl', rj);
            this.ra('geol', qj);
            this.ra('svg', sj);
            this.ra('work', tj);
            this.ra('wbsk', uj);
            this.ra('vido', vj);
            this.ra('audo', wj);
            this.ra('hsty', xj);
            this.ra('file', yj);
            this.ra('psmg', zj);
            this.ra('wknf', Aj);
            this.ra('rqaf', Bj);
            this.ra('json', Cj);
            this.ra('flsc', Dj);
            this.ra('i18n', Ej);
            this.ra('cors', Jj);
            this.ra('prog', Kj);
            this.ra('metr', Lj);
            this.ra('becn', Mj);
            this.ra('mcrd', Uc);
            this.ra('esrc', jj);
          },
        };
        var w = c.alog.wF('feature');
        w.V('commit', () => {
          $b.SZ();
          var a = setInterval(() => {
            if ('WebP-lossy' in $b.$h && 'WebP-lossless' in $b.$h && 'WebP-alpha' in $b.$h && 'WebP-animation' in $b.$h) {
              for (const b in $b.$h) $b.$h[b] = $b.$h[b] ? 'y' : 'n';
              w.send('feature', $b.$h);
              clearInterval(a);
            }
          }, 500);
        });
        c.alog('feature.create', {
          G2: 4,
          b5: k,
          page: i,
          zb: '18',
        });
        c.alog('feature.fire', 'commit');
      }
    }(a, b, c));
  }(window, document, D));
  D.aq = D.alog || u();
  D.alog('cus.fire', 'count', 'z_loadscriptcount');
  location.protocol === 'https:' && D.alog('cus.fire', 'count', 'z_httpscount');
  function Tb(a) {
    let b = window.TILE_VERSION;
    let c = '20190410';
    b && b.ditu && (b = b.ditu,
    b[a] && b[a].updateDate && (c = b[a].updateDate));
    return c;
  }
  const Ub = [72.6892532, 0.1939743381, 136.1168614, 54.392257];
  const Vb = [72.69566833, 0.1999420909, 136.1232863, 54.39791217];
  const Wb = 158;
  const Xb = [98.795985, 122.960792, 107.867379, 118.093451, 119.139658, 128.035888, 79.948212, 99.029524, 119.923388, 122.094977, 127.918527, 130.94789, 106.50606, 108.076783, 119.8329, 126.382207, 111.803567, 119.324928, 100.749858, 102.227985, 99.860885, 100.788921, 97.529435, 98.841564, 99.100017, 99.90035, 122.917416, 123.774367, 123.728314, 125.507211, 123.736065, 124.767299, 125.488463, 126.410675, 125.484326, 126.07764, 130.830784, 133.620042, 127.912178, 128.668957, 128.658937, 129.638599, 132.894179, 134.119086, 117.379378, 119.244569, 116.086736, 117.431212, 114.420233, 116.137458, 116.492775, 119.605527, 110.579401, 111.86488, 74.468228, 80.001908, 82.867432, 91.353788, 85.721075, 98.976964, 127.664757, 129.546833, 129.476893, 130.22449, 133.730358, 134.745235, 134.381034, 135.1178, 130.868117, 131.34409, 115.513245, 117.544751, 115.779271, 116.748045, 108.536254, 110.614326, 121.365534, 124.626434, 126.165992, 127.347013, 91.281869, 95.611754, 79.879648, 82.945041, 76.413314, 78.345207, 78.275229, 80.002329, 83.956612, 85.734098, 85.510186, 89.356499, 97.997001, 98.948845, 106.653208, 108.610811, 111.400183, 111.824179, 111.592224, 111.817136, 116.00682, 117.024631, 116.258574, 116.689291, 119.436876, 119.922961, 120.659806, 121.395479, 120.349116, 120.676014, 124.59389, 125.787788, 126.221756, 126.788962, 95.572955, 102.046581, 95.583772, 96.165551, 95.564318, 97.806095, 91.30446, 93.356438, 93.330319, 94.698145, 89.349129, 90.548677, 82.268802, 82.892025, 78.335615, 80.032266, 76.625755, 78.361413, 73.498248, 74.490992, 74.846872, 76.488771, 91.563521, 94.878444, 88.768214, 89.244787, 83.247076, 83.974127, 82.29595, 83.256003, 81.885315, 83.26249, 80.760619, 81.472404, 86.470983, 88.276988, 102.207537, 104.234614, 112.164795, 116.833667, 108.965663, 113.032246, 111.166575, 117.983363];
  const Yb = [22.551183, 42.284787, 17.227969, 22.738314, 41.300981, 50.749638, 30.368087, 42.332701, 21.705055, 22.696452, 42.426047, 48.944674, 21.432184, 22.651387, 50.657409, 52.92296, 42.212192, 45.206905, 21.137031, 22.57186, 21.444502, 22.586566, 23.741571, 25.301472, 22.006806, 22.56637, 38.985114, 41.346531, 40.295617, 41.338581, 39.740021, 40.351012, 40.974644, 41.331562, 40.726852, 41.067192, 44.877158, 48.018285, 41.344597, 42.451798, 42.016305, 42.443235, 45.880906, 48.214001, 45.140027, 46.792775, 45.141083, 46.400433, 45.156418, 45.748281, 47.485889, 50.071879, 42.223667, 43.469487, 37.019867, 40.668675, 42.226823, 47.321605, 27.72944, 30.469853, 48.919002, 49.650614, 48.840188, 49.443166, 46.949801, 48.382798, 47.660603, 48.472692, 42.859946, 44.913298, 47.605896, 48.445914, 48.41698, 48.909667, 42.23507, 42.914193, 52.8281, 53.585952, 50.709311, 51.662219, 42.29968, 44.399225, 42.302746, 45.391958, 34.680866, 37.03377, 30.743515, 37.07228, 28.245649, 30.408935, 47.277693, 48.504255, 25.241528, 27.780726, 42.223363, 42.548418, 43.435888, 44.696952, 44.693193, 45.00187, 48.886267, 49.326755, 49.288642, 49.632304, 50.717486, 51.314369, 52.914204, 53.33964, 52.910094, 53.115926, 52.908382, 53.258095, 51.64533, 52.408305, 42.236825, 42.699126, 43.068466, 43.898632, 42.670403, 43.082219, 44.379045, 45.187742, 44.382336, 44.981379, 47.310362, 48.06019, 45.359099, 46.814439, 40.569751, 42.047741, 40.587956, 41.41263, 38.519192, 40.185033, 35.790476, 37.029005, 26.825605, 27.763896, 27.199658, 27.751649, 29.150192, 30.381073, 29.573886, 30.065162, 30.047775, 30.384089, 30.001277, 30.388525, 48.494118, 49.173841, 22.398528, 22.601198, 7.441114, 11.505968, 3.767491, 9.005209, 12.642067, 17.410886];
  const Zb = 95;
  const ac = [110.3961374, 105.0743788, 96.8991824, 95.61810411, 93.82412598, 91.3892353, 91.38931858, 89.08325955, 87.22469808, 86.26278402, 85.17353, 85.23741211, 82.86627441, 81.90481038, 79.59687147, 80.39829237, 79.93319363, 77.80279948, 75.2557704, 73.49357829, 73.1892532, 73.87758816, 74.4064738, 74.10215224, 75.46409695, 76.77739692, 78.28299615, 78.15499485, 78.37920654, 78.89145345, 79.69282199, 81.19938178, 81.80830295, 83.89093424, 85.94149523, 87.86447266, 89.03414958, 90.05918132, 91.10026937, 92.15733832, 93.74361735, 95.82597331, 97.95655545, 97.12363037, 98.2129739, 99.2068571, 101.6587874, 102.5239084, 102.2356106, 105.0249238, 106.0992342, 107.8617093, 111.6439372, 109.591869, 112.284586, 117.7961157, 118.9495128, 114.2076584, 118.693565, 123.1475225, 122.730705, 120.9361393, 123.4207441, 122.3787782, 122.1385425, 121.5904281, 121.1773763, 120.6805404, 120.2483355, 122.795807, 122.8759077, 121.3060262, 122.1392177, 123.7418799, 126.4177599, 128.5647409, 129.7194884, 131.2259136, 131.9950494, 133.6289931, 135.6168614, 131.3875545, 130.8743365, 128.6303223, 126.0997773, 124.4015375, 122.22161, 119.6586483, 119.7866827, 118.5685878, 116.5177976, 114.819101, 119.0812964, 116.453265, 111.7431171];
  const bc = [43.2190351, 42.38053385, 43.17417589, 44.42226915, 45.09863634, 45.56708116, 47.33599718, 48.68832709, 49.62448486, 48.9482175, 48.4800472, 47.33564399, 47.43948676, 46.03452067, 45.20221788, 43.34563043, 42.32965739, 41.39690972, 40.82972331, 39.95567654, 39.25892877, 38.36098768, 38.05441569, 37.16878445, 36.38899414, 35.36126817, 34.30953451, 32.58503879, 31.56975694, 30.77800266, 30.43559814, 29.7744892, 30.0931977, 28.71103299, 27.70739665, 27.5775472, 27.01096137, 27.77857883, 27.50707954, 26.50328315, 26.70387804, 27.95548557, 27.29428901, 23.64685493, 23.62310601, 21.67493381, 20.77751465, 21.32070991, 22.1824113, 22.31232964, 22.51316054, 16.80037679, 13.19749864, 0.6939743381, 1.541660428, 10.50208252, 15.58926975, 17.89090007, 19.94928467, 22.18490153, 25.37285292, 25.61456434, 30.62532552, 31.08099284, 31.89238173, 32.50092692, 32.80325765, 34.25546956, 35.15486138, 36.90170139, 37.8348272, 37.941604, 38.6480797, 38.96797201, 40.98146918, 41.25573296, 42.07218153, 42.49132813, 44.65259766, 44.69330702, 48.62286865, 48.09383952, 49.19628499, 50.03402317, 53.27678901, 53.62976345, 53.89420546, 52.98933322, 52.01872884, 50.23210259, 50.18807048, 47.49769857, 47.34362712, 46.50502143, 45.24770128];
  const cc = [98.7895, 122.954182, 107.860913, 118.087007, 119.133165, 128.029533, 79.941749, 99.023087, 119.916883, 122.08841, 127.912143, 130.941471, 106.499502, 108.070244, 119.826245, 126.375818, 111.797006, 119.318387, 100.743285, 102.221517, 99.854448, 100.782445, 97.522928, 98.835028, 99.093518, 99.893783, 122.910927, 123.767769, 123.721954, 125.50077, 123.729657, 124.760724, 125.481902, 126.404079, 125.477737, 126.071019, 130.824331, 133.613395, 127.905767, 128.662524, 128.652527, 129.6321, 132.887552, 134.11249, 117.37297, 119.237999, 116.080154, 117.424589, 114.413586, 116.130948, 116.486264, 119.598927, 110.5728, 111.858437, 74.465162, 79.995337, 82.860821, 91.347291, 85.716024, 98.970481, 127.658331, 129.540202, 129.470528, 130.21808, 133.723748, 134.738785, 134.374555, 135.111443, 130.861475, 131.337438, 115.506627, 117.538123, 115.772783, 116.741632, 108.529656, 110.60782, 121.358945, 124.619773, 126.159424, 127.340582, 91.275275, 95.605228, 79.874427, 82.938601, 76.413314, 78.338763, 78.275229, 79.995765, 83.956612, 85.727511, 85.503554, 89.349858, 97.990418, 98.942257, 106.646704, 108.604437, 111.393667, 111.817723, 111.585811, 111.810645, 116.000232, 117.018216, 116.252108, 116.682705, 119.430384, 119.916417, 120.653168, 121.38883, 120.342727, 120.669383, 124.587426, 125.781376, 126.215282, 126.782323, 95.566367, 102.040026, 95.577158, 96.159009, 95.557772, 97.799728, 91.298032, 93.350057, 93.323794, 94.691771, 89.342471, 90.542019, 82.264229, 82.885485, 78.335615, 80.025844, 76.623947, 78.355027, 73.495149, 74.484473, 74.846872, 76.482208, 91.560117, 94.871859, 88.761692, 89.23822, 83.240549, 83.967602, 82.292367, 83.2495, 81.878825, 83.256003, 80.75421, 81.465955, 86.465421, 88.270356, 102.201019, 104.228033, 112.158282, 116.827153, 108.965663, 113.025767, 111.166575, 117.97687];
  const dc = [22.545421, 42.279053, 17.226272, 22.731982, 41.294917, 50.743316, 30.361986, 42.326603, 21.699185, 22.690751, 42.419757, 48.938435, 21.426505, 22.64567, 50.651745, 52.916705, 42.20641, 45.201064, 21.131326, 22.565685, 21.438288, 22.580379, 23.735785, 25.295582, 22.001087, 22.560315, 38.979333, 41.340757, 40.28938, 41.332289, 39.734164, 40.344718, 40.968803, 41.325813, 40.721073, 41.061503, 44.871533, 48.012179, 41.338366, 42.445601, 42.010343, 42.436934, 45.875217, 48.208327, 45.134237, 46.786509, 45.135376, 46.394665, 45.150734, 45.742257, 47.480099, 50.065931, 42.217982, 43.46329, 37.014057, 40.662848, 42.221079, 47.315558, 27.723432, 30.46385, 48.913298, 49.644555, 48.83396, 49.436824, 46.944059, 48.376613, 47.654503, 48.466331, 42.854333, 44.907682, 47.600253, 48.440245, 48.410926, 48.903468, 42.229292, 42.908294, 52.822466, 53.58012, 50.703491, 51.656037, 42.29378, 44.393379, 42.296912, 45.385809, 34.679282, 37.027699, 30.740622, 37.066377, 28.241967, 30.403134, 47.271949, 48.49848, 25.235818, 27.774976, 42.217425, 42.542102, 43.429763, 44.691016, 44.687044, 44.995758, 48.880431, 49.320551, 49.282865, 49.626267, 50.711607, 51.308382, 52.908547, 53.333963, 52.904419, 53.109706, 52.902338, 53.251938, 51.639701, 52.402205, 42.231045, 42.693581, 43.062756, 43.892771, 42.664519, 43.075927, 44.372942, 45.1815, 44.376327, 44.975476, 47.304623, 48.054453, 45.353174, 46.808493, 40.563653, 42.041556, 40.582164, 41.4064, 38.51618, 40.179105, 35.789745, 37.023144, 26.825402, 27.757641, 27.193806, 27.745766, 29.144229, 30.375186, 29.567889, 30.059102, 30.041938, 30.378006, 29.995047, 30.382338, 48.48834, 49.169021, 22.392816, 22.595333, 7.439914, 11.500161, 3.766676, 9.000793, 12.640512, 17.406563];
  const ec = 3E3;
  const fc = 2.0E-5;
  const gc = 3.0E-6;
  const hc = 0.0174532925194;
  const ic = 0.0065;
  const jc = 0.0060;
  const kc = 4E4;
  const lc = 0;
  const mc = 3;
  const nc = 1.0E-10;
  const oc = 6370996.81;
  const pc = 1E8;
  function qc(a, b, c) {
    for (let e = Wb, f = 0; f < e; f += 2) if (a.lng >= b[f] && a.lng <= b[f + 1] && a.lat >= c[f] && a.lat <= c[f + 1]) return p;
    return t;
  }
  function rc(a) {
    var b = a.lng;
    const c = a.lat;
    var a = Math.sqrt(b * b + c * c) + Math.sin(c * ec * hc) * fc;
    var b = Math.atan2(c, b) + Math.cos(b * ec * hc) * gc;
    return {
      lng: a * Math.cos(b) + ic,
      lat: a * Math.sin(b) + jc,
    };
  }
  function sc(a) {
    let b = tc;
    let c = {};
    let e = a.lng;
    let f = a.lat;
    let g = 1;
    let i = a.lng;
    let k = a.lat;
    var m = e - g;
    let n = 0;
    var o = f + g;
    let s = 0;
    let v = e - g;
    let w = 0;
    let y = f - g;
    let z = 0;
    let B = e + g;
    let C = 0;
    let E = f - g;
    let F = 0;
    let G = e + g;
    let K = 0;
    let O = f + g;
    let M = 0;
    var o = m = 0;
    var o = uc(b, e, f);
    var m = o.lng;
    var o = o.lat;
    if (vc(m, o, i, k) <= 1.0E-6) {
      return c.lng = e,
      c.lat = f,
      c;
    }
    for (; ;) {
      m = e - g;
      o = f + g;
      v = e - g;
      y = f - g;
      B = e + g;
      E = f - g;
      G = e + g;
      O = f + g;
      e = uc(b, m, o);
      n = e.lng;
      s = e.lat;
      e = uc(b, v, y);
      w = e.lng;
      z = e.lat;
      e = uc(b, B, E);
      C = e.lng;
      F = e.lat;
      e = uc(b, G, O);
      K = e.lng;
      M = e.lat;
      e = vc(n, s, i, k);
      n = vc(w, z, i, k);
      w = vc(C, F, i, k);
      K = vc(K, M, i, k);
      if (e < 1.0E-6) {
        return c.lng = m,
        c.lat = o,
        c;
      }
      if (n < 1.0E-6) {
        return c.lng = v,
        c.lat = y,
        c;
      }
      if (w < 1.0E-6) {
        return c.lng = B,
        c.lat = E,
        c;
      }
      if (K < 1.0E-6) {
        return c.lng = G,
        c.lat = O,
        c;
      }
      C = 1 / e;
      n = 1 / n;
      w = 1 / w;
      K = 1 / K;
      e = (m * C + v * n + B * w + G * K) / (C + n + w + K);
      f = (o * C + y * n + E * w + O * K) / (C + n + w + K);
      o = uc(b, e, f);
      m = o.lng;
      o = o.lat;
      if (vc(m, o, i, k) <= 1.0E-6) {
        return c.lng = e,
        c.lat = f,
        c;
      }
      g *= 0.6;
      if (g < 1.0E-6) {
        a: {
          c = (a.lng + 0.03 - (a.lng - 0.03)) / 1.0E-4 + 0.5;
          g = (a.lat + 0.03 - (a.lat - 0.03)) / 1.0E-4 + 0.5;
          i = a.lng * pc;
          k = a.lat * pc;
          y = 1.0E-4 * pc;
          m = i - y;
          o = i + y;
          v = k - y;
          B = k + y;
          C = n = w = K = l;
          G = n = y = E = w = K = 0;
          b(a);
          C = l;
          for (O = 0; O <= c; O++) {
            for (e = 0; e <= g; e++) {
              if (C = b(l),
              K = l.lng * pc,
              w = l.lat * pc,
              n = C.lng * pc,
              C = C.lat * pc,
              !(n < m || C < v || n > o || C > B)) {
                K -= n;
                w -= C;
                n = Math.sqrt((i - n) * (i - n) + (k - C) * (k - C));
                if (n < 1) {
                  c = {};
                  c.lng = l.lng;
                  c.lat = l.lat;
                  break a;
                }
                E += 1 * K / n;
                y += 1 * w / n;
                G += 1 / n;
              }
            }
            E /= G * pc;
            y /= G * pc;
          }
          b = E * pc / pc;
          g = y * pc / pc;
          c = {};
          c.lng = a.lng + b;
          c.lat = a.lat + g;
        }
        return c;
      }
    }
  }
  function uc(a, b, c) {
    a = a({
      lng: b,
      lat: c,
    });
    b = {};
    b.lng = a.lng;
    b.lat = a.lat;
    return b;
  }
  function wc(a, b, c, e) {
    const f = arguments.length;
    this.yg = {};
    this.Fg = {};
    f !== 0 && f === 4 && this.normalize(a, b, c, e);
  }
  wc.prototype.contains = function (a) {
    return a.lng > this.yg.lng && a.lng < this.Fg.lng && a.lat > this.yg.lat && a.lat < this.Fg.lat ? mc : Math.abs(a.lng - this.yg.lng) < nc || Math.abs(a.lng - this.Fg.lng) < nc || Math.abs(a.lat - this.yg.lat) < nc || Math.abs(a.y - this.Fg.lat) > nc ? 2 : lc;
  };
  wc.prototype.normalize = function (a, b, c, e) {
    a > c ? (this.yg.lng = c,
    this.Fg.lng = a) : (this.yg.lng = a,
    this.Fg.lng = c);
    b > e ? (this.yg.lat = e,
    this.Fg.lat = b) : (this.yg.lat = b,
    this.Fg.lat = e);
  };
  function xc(a, b, c, e) {
    this.Nt = {
      lng: a,
      lat: b,
    };
    this.Jw = {
      lng: c,
      lat: e,
    };
    this.Dx = new wc(a, b, c, e);
  }
  function yc(a, b) {
    const c = a.lat * hc;
    const e = b.lat * hc;
    const f = c - e;
    const g = a.lng * hc - b.lng * hc;
    return 2 * Math.asin(Math.sqrt(Math.sin(f / 2) * Math.sin(f / 2) + Math.cos(c) * Math.cos(e) * Math.sin(g / 2) * Math.sin(g / 2))) * oc;
  }
  function vc(a, b, c, e) {
    return Math.sqrt((a - c) * (a - c) + (b - e) * (b - e));
  }
  function zc(a, b, c) {
    return (b.lng - a.lng) * (c.lat - a.lat) - (c.lng - a.lng) * (b.lat - a.lat);
  }
  function tc(a) {
    var b = {};
    if (a.lng < Ub[0] - 0.4 || a.lat < Ub[1] - 0.4 || a.lng > Ub[2] + 0.4 || a.lat > Ub[3] + 0.4) {
      return b.lng = a.lng,
      b.lat = a.lat,
      b;
    }
    if (qc(a, cc, dc)) return b = rc(a);
    for (var b = 0, c = kc, e = 0, f = new wc(), g = 0, e = 0; e < Zb; ++e) {
      bc[e] <= a.lat ? bc[(e + 1) % Zb] > a.lat && zc({
        lng: ac[e],
        lat: bc[e],
      }, {
        lng: ac[(e + 1) % Zb],
        lat: bc[(e + 1) % Zb],
      }, a) > 0 && ++g : bc[(e + 1) % Zb] <= a.lat && zc({
        lng: ac[e],
        lat: bc[e],
      }, {
        lng: ac[(e + 1) % Zb],
        lat: bc[(e + 1) % Zb],
      }, a) < 0 && --g;
    }
    if ((g === 0 ? lc : mc) === lc) {
      for (g = 0; g < Zb; ++g) {
        if (e = new xc(ac[g], bc[g], ac[(g + 1) % Zb], bc[(g + 1) % Zb]),
        f.yg.lng = e.Dx.yg.lng - 0.5,
        f.yg.lat = e.Dx.yg.lat - 0.5,
        f.Fg.lng = e.Dx.Fg.lng + 0.5,
        f.Fg.lat = e.Dx.Fg.lat + 0.5,
        f.contains(a) !== lc) {
          var i;
          let k = e.Nt.lng;
          let m = e.Nt.lat;
          let n = e.Jw.lng;
          let o = e.Jw.lat;
          i = o - m;
          let s = k - n;
          !(Math.abs(i - 0) > nc) && !(Math.abs(s - 0) > nc) ? i = e.Nt : (k = n * m - k * o,
          m = s * a.lng - i * a.lat,
          n = i * i - s * s,
          i = {
            lng: (s * m - i * k) / n,
            lat: -(i * m + s * k) / n,
          });
          s = 180;
          k = 90;
          m = -180;
          n = -90;
          n = e.Nt;
          o = e.Jw;
          s = n.lng < o.lng ? n.lng : o.lng;
          k = n.lat < o.lat ? n.lat : o.lat;
          m = n.lng < o.lng ? n.lng : o.lng;
          n = n.lat < o.lat ? n.lat : o.lat;
          i.lng <= m && i.lng >= s && i.lng <= n && i.lat >= k ? (e = a.lat * hc,
          s = a.lng * hc,
          k = i.lat * hc,
          i = i.lng * hc,
          m = Math.cos(e) * Math.cos(k),
          e = m * Math.cos(s) * Math.cos(i) + m * Math.sin(s) * Math.sin(i) + Math.sin(e) * Math.sin(k),
          e < -1 ? e = -1 : e > 1 && (e = 1),
          e = Math.acos(e) * oc) : (i = yc(a, e.Nt),
          e = yc(a, e.Jw),
          e = i < e ? i : e);
          e < c && (c = e);
        }
      }
      c < kc && (b = (kc - c) / kc);
    } else b = 1;
    c = rc(a);
    return b = {
      lng: a.lng + (c.lng - a.lng) * b,
      lat: a.lat + (c.lat - a.lat) * b,
    };
  }
  function Ac(a) {
    var b = {};
    if (a.lng < Vb[0] - 0.4 || a.lat < Vb[1] - 0.4 || a.lng > Vb[2] + 0.4 || a.lat > Vb[3] + 0.4) {
      return b.lng = a.lng,
      b.lat = a.lat,
      b;
    }
    if (qc(a, Xb, Yb)) {
      var b = a.lng - ic;
      var c = a.lat - jc;
      var a = Math.sqrt(b * b + c * c) - Math.sin(c * ec * hc) * fc;
      var b = Math.atan2(c, b) - Math.cos(b * ec * hc) * gc;
      return b = {
        lng: a * Math.cos(b),
        lat: a * Math.sin(b),
      };
    }
    c = tc(a);
    return a.lng === c.lng && a.lat === c.lng ? (b.lng = a.lng,
    b.lat = a.lat,
    b) : sc(a);
  }
  function Ya(a, b) {
    if (b === 3 && a instanceof Q) {
      const c = tc(a);
      return new J(c.lng, c.lat);
    }
    return a;
  }
  function cb(a, b) {
    if (b === 3 && a instanceof J) {
      const c = Ac(a);
      return new Q(c.lng, c.lat);
    }
    return b === 5 && a instanceof J ? new Q(a.lng, a.lat) : a;
  }
  function oa(a, b) {
    if (/^http/.test(a)) return; // 修改  屏蔽ak验证，若调用外部资源直接返回
    if (b) {
      const c = (1E5 * Math.random()).toFixed(0);
      D._rd[`_cbk${c}`] = function (a) {
        b && b(a);
        delete D._rd[`_cbk${c}`];
      };
      a += `&callback=BMap._rd._cbk${c}`;
    }
    let e = L('script', {
      type: 'text/javascript',
    });
    e.charset = 'utf-8';
    e.src = a;
    e.addEventListener ? e.addEventListener('load', (a) => {
      a = a.target;
      a.parentNode.removeChild(a);
    }, t) : e.attachEvent && e.attachEvent('onreadystatechange', () => {
      const a = window.event.srcElement;
      a && (a.readyState == 'loaded' || a.readyState == 'complete') && a.parentNode.removeChild(a);
    });
    setTimeout(() => {
      document.getElementsByTagName('head')[0].appendChild(e);
      e = q;
    }, 1);
  }
  const Bc = {
    map: '01arux',
    common: 'g1wth0',
    style: 'n4zjcm',
    tile: '4h5riy',
    groundoverlay: 'hanqlf',
    pointcollection: 'mzctia',
    marker: 'qq2pj0',
    symbol: 'xnfufp',
    canvablepath: 'bi2unv',
    vmlcontext: '3wsb1f',
    markeranimation: 'vbzta0',
    poly: 'bpulbb',
    draw: 'qhsgk3',
    drawbysvg: 'jdynmi',
    drawbyvml: 'yldn4m',
    drawbycanvas: 'ilnwax',
    infowindow: 'cu34p0',
    oppc: 'nwlvbl',
    opmb: 'lix5dg',
    menu: 'vhxxn0',
    control: 'j15uuh',
    navictrl: 'atju25',
    geoctrl: '2j1jki',
    copyrightctrl: '1ezsod',
    citylistcontrol: 'fjkpbq',
    scommon: 'dnbhjq',
    local: 'i0prg0',
    route: '4zemxy',
    othersearch: '3bi0vd',
    mapclick: 'di1qem',
    buslinesearch: 'g5wey4',
    hotspot: '5ak1wj',
    autocomplete: 'hg2dum',
    coordtrans: 'su4y5t',
    coordtransutils: '0kslnk',
    convertor: 'khwhiz',
    clayer: 'w3ptjt',
    pservice: 'xzax22',
    pcommon: 'wajq4y',
    panorama: 'am3won',
    panoramaflash: 'amklzb',
  };
  A.py = (function () {
    function a(a) {
      return e && !!c[`${b + a}_${Bc[a]}`];
    }
    var b = 'BMap_';
    var c = window.localStorage;
    var e = 'localStorage' in window && c !== q && c !== l;
    return {
      AY: e,
      set(a, g) {
        if (e) {
          for (var i = `${b + a}_`, k = c.length, m; k--;) {
            m = c.key(k),
            m.indexOf(i) > -1 && c.removeItem(m);
          }
          try {
            c.setItem(`${b + a}_${Bc[a]}`, g);
          } catch (n) {
            c.clear();
          }
        }
      },
      get(f) {
        return e && a(f) ? c.getItem(`${b + f}_${Bc[f]}`) : t;
      },
      PJ: a,
    };
  }());
  function Ta() {}
  A.object.extend(Ta, {
    Bj: {
      bG: -1,
      xP: 0,
      Np: 1,
    },
    WK() {
      let a = 'canvablepath';
      if (!I() || !Qb()) Pb() || (Ob() ? a = 'vmlcontext' : Qb());
      return {
        tile: ['style'],
        control: [],
        marker: ['symbol'],
        symbol: ['canvablepath', 'common'],
        canvablepath: a === 'canvablepath' ? [] : [a],
        vmlcontext: [],
        style: [],
        poly: ['marker', 'drawbycanvas', 'drawbysvg', 'drawbyvml'],
        drawbysvg: ['draw'],
        drawbyvml: ['draw'],
        drawbycanvas: ['draw'],
        infowindow: ['common', 'marker'],
        menu: [],
        oppc: [],
        opmb: [],
        scommon: [],
        local: ['scommon'],
        route: ['scommon'],
        othersearch: ['scommon'],
        autocomplete: ['scommon'],
        citylistcontrol: ['autocomplete'],
        mapclick: ['scommon'],
        buslinesearch: ['route'],
        hotspot: [],
        coordtransutils: ['coordtrans'],
        convertor: [],
        clayer: ['tile'],
        pservice: [],
        pcommon: ['style', 'pservice'],
        panorama: ['pcommon'],
        panoramaflash: ['pcommon'],
      };
    },
    e5: {},
    TF: {
      IP: `${D.oa}getmodules?v=3.0`,
      dU: 5E3,
    },
    gC: t,
    Qd: {
      tl: {},
      gn: [],
      Dv: [],
    },
    load(a, b, c) {
      const e = this.ob(a);
      if (e.Le == this.Bj.Np) c && b();
      else {
        if (e.Le == this.Bj.bG) {
          this.UJ(a);
          this.hN(a);
          const f = this;
          f.gC == t && (f.gC = p,
          setTimeout(() => {
            for (var a = [], b = 0, c = f.Qd.gn.length; b < c; b++) {
              const e = f.Qd.gn[b];
              let n = '';
              ia.py.PJ(e) ? n = ia.py.get(e) : (n = '',
              a.push(`${e}_${Bc[e]}`));
              f.Qd.Dv.push({
                zM: e,
                rE: n,
              });
            }
            f.gC = t;
            f.Qd.gn.length = 0;
            // 0 == a.length ? f.DK() : oa(f.TF.IP + "&mod=" + a.join(","))
            // 修改 加载本地模块文件，在 modules 目录下
            console.log(a); // 打印所需模块
            if (a.length > 0) {
						  for (i = 0; i < a.length; i++) {
                mf = `${bmapcfg.home}modules/${a[i]}.js`;
                oa(mf);
                console.log(`加载模块文件:${mf}`); // IE error
						  }
            } else {
						  f.DK();
            }
            // 就到这
          }, 1));
          e.Le = this.Bj.xP;
        }
        e.zu.push(b);
      }
    },
    UJ(a) {
      if (a && this.WK()[a]) {
        for (var a = this.WK()[a], b = 0; b < a.length; b++) {
          this.UJ(a[b]),
          this.Qd.tl[a[b]] || this.hN(a[b]);
        }
      }
    },
    hN(a) {
      for (let b = 0; b < this.Qd.gn.length; b++) if (this.Qd.gn[b] == a) return;
      this.Qd.gn.push(a);
    },
    RZ(a, b) {
      const c = this.ob(a);
      try {
        eval(b);
      } catch (e) {
        return;
      }
      c.Le = this.Bj.Np;
      for (let f = 0, g = c.zu.length; f < g; f++) c.zu[f]();
      c.zu.length = 0;
    },
    PJ(a, b) {
      const c = this;
      c.timeout = setTimeout(() => {
        c.Qd.tl[a].Le != c.Bj.Np ? (c.remove(a),
        c.load(a, b)) : clearTimeout(c.timeout);
      }, c.TF.dU);
    },
    ob(a) {
      this.Qd.tl[a] || (this.Qd.tl[a] = {},
      this.Qd.tl[a].Le = this.Bj.bG,
      this.Qd.tl[a].zu = []);
      return this.Qd.tl[a];
    },
    remove(a) {
      delete this.ob(a);
    },
    cV(a, b) {
      for (var c = this.Qd.Dv, e = p, f = 0, g = c.length; f < g; f++) c[f].rE == '' && (c[f].zM == a ? c[f].rE = b : e = t);
      e && this.DK();
    },
    DK() {
      for (let a = this.Qd.Dv, b = 0, c = a.length; b < c; b++) this.RZ(a[b].zM, a[b].rE);
      this.Qd.Dv.length = 0;
    },
  });
  function R(a, b) {
    this.x = a || 0;
    this.y = b || 0;
    this.x = this.x;
    this.y = this.y;
  }
  R.prototype.Sb = function (a) {
    return a && a.x == this.x && a.y == this.y;
  };
  function N(a, b) {
    this.width = a || 0;
    this.height = b || 0;
  }
  N.prototype.Sb = function (a) {
    return a && this.width == a.width && this.height == a.height;
  };
  function lb(a, b, c) {
    const e = new XMLHttpRequest();
    e.open('POST', a, p);
    e.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    e.timeout = 1E4;
    e.ontimeout = u();
    e.onreadystatechange = function () {
      this.readyState === 4 && this.status === 200 && c && c(e.responseText);
    };
    e.send(b);
  }
  function kb(a, b) {
    a && (this.Jb = a,
    this.ca = `spot${kb.ca++}`,
    b = b || {},
    this.Yg = b.text || '',
    this.jv = b.offsets ? b.offsets.slice(0) : [5, 5, 5, 5],
    this.oB = b.userData || q,
    this.Ih = b.minZoom || q,
    this.Gf = b.maxZoom || q);
  }
  kb.ca = 0;
  A.extend(kb.prototype, {
    ya(a) {
      this.Ih == q && (this.Ih = a.M.fc);
      this.Gf == q && (this.Gf = a.M.mc);
    },
    va(a) {
      if (a instanceof Q || a instanceof J) this.Jb = a;
    },
    la: x('Jb'),
    Gt: ba('Yg'),
    zD: x('Yg'),
    setUserData: ba('oB'),
    getUserData: x('oB'),
  });
  function Cc() {
    this.P = q;
    this.Kb = 'control';
    this.Ua = this.GJ = p;
  }
  A.lang.xa(Cc, A.lang.Ha, 'Control');
  A.extend(Cc.prototype, {
    initialize(a) {
      this.P = a;
      if (this.R) {
        return a.ab.appendChild(this.R),
        this.R;
      }
    },
    Ge(a) {
      !this.R && (this.initialize && $a(this.initialize)) && (this.R = this.initialize(a));
      this.m = this.m || {
        Eg: t,
      };
      this.cB();
      this.pr();
      this.R && (this.R.Oq = this);
    },
    cB() {
      const a = this.R;
      if (a) {
        const b = a.style;
        b.position = 'absolute';
        b.zIndex = this.wu || '10';
        b.MozUserSelect = 'none';
        b.WebkitTextSizeAdjust = 'none';
        this.m.Eg || A.U.hb(a, 'BMap_noprint');
        I() || A.V(a, 'contextmenu', na);
      }
    },
    remove() {
      this.P = q;
      this.R && (this.R.parentNode && this.R.parentNode.removeChild(this.R),
      this.R = this.R.Oq = q);
    },
    Fa() {
      this.R = Db(this.P.ab, "<div unselectable='on'></div>");
      this.Ua == t && A.U.$(this.R);
      return this.R;
    },
    pr() {
      this.rc(this.m.anchor);
    },
    rc(a) {
      if (this.b2 || !Za(a) || isNaN(a) || a < Dc || a > 3) a = this.defaultAnchor;
      this.m = this.m || {
        Eg: t,
      };
      this.m.Ea = this.m.Ea || this.defaultOffset;
      const b = this.m.anchor;
      this.m.anchor = a;
      if (this.R) {
        let c = this.R;
        const e = this.m.Ea.width;
        const f = this.m.Ea.height;
        c.style.left = c.style.top = c.style.right = c.style.bottom = 'auto';
        switch (a) {
          case Dc:
            c.style.top = `${f}px`;
            c.style.left = `${e}px`;
            break;
          case Ec:
            c.style.top = `${f}px`;
            c.style.right = `${e}px`;
            break;
          case Fc:
            c.style.bottom = `${f}px`;
            c.style.left = `${e}px`;
            break;
          case 3:
            c.style.bottom = `${f}px`,
            c.style.right = `${e}px`;
        }
        c = ['TL', 'TR', 'BL', 'BR'];
        A.U.qc(this.R, `anchor${c[b]}`);
        A.U.hb(this.R, `anchor${c[a]}`);
      }
    },
    bD() {
      return this.m.anchor;
    },
    getContainer: x('R'),
    Ld(a) {
      a instanceof N && (this.m = this.m || {
        Eg: t,
      },
      this.m.Ea = new N(a.width, a.height),
      this.R && this.rc(this.m.anchor));
    },
    hj() {
      return this.m.Ea;
    },
    Yc: x('R'),
    show() {
      this.Ua != p && (this.Ua = p,
      this.R && A.U.show(this.R));
    },
    $() {
      this.Ua != t && (this.Ua = t,
      this.R && A.U.$(this.R));
    },
    isPrintable() {
      return !!this.m.Eg;
    },
    Oc() {
      return !this.R && !this.P ? t : !!this.Ua;
    },
  });
  var Dc = 0;
  var Ec = 1;
  var Fc = 2;
  function mb(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      Eg: t,
      fF: a.showZoomInfo || p,
      anchor: a.anchor,
      Ea: a.offset,
      type: a.type,
      qW: a.enableGeolocation || t,
    };
    this.defaultAnchor = I() ? 3 : Dc;
    this.defaultOffset = new N(10, 10);
    this.rc(a.anchor);
    this.Pm(a.type);
    this.yf();
  }
  A.lang.xa(mb, Cc, 'NavigationControl');
  A.extend(mb.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    Pm(a) {
      this.m.type = Za(a) && a >= 0 && a <= 3 ? a : 0;
    },
    Vo() {
      return this.m.type;
    },
    yf() {
      const a = this;
      Ta.load('navictrl', () => {
        a.xf();
      });
    },
  });
  function Gc(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      anchor: a.anchor || Fc,
      Ea: a.offset || new N(10, 30),
      B_: a.showAddressBar !== t,
      L2: a.enableAutoLocation || t,
      rM: a.locationIcon || q,
    };
    const b = this;
    this.wu = 1200;
    b.v0 = [];
    this.pe = [];
    Ta.load('geoctrl', () => {
      (function e() {
        if (b.pe.length !== 0) {
          const a = b.pe.shift();
          b[a.method].apply(b, a.arguments);
          e();
        }
      }());
      b.HP();
    });
    Ra(Ka);
  }
  A.lang.xa(Gc, Cc, 'GeolocationControl');
  A.extend(Gc.prototype, {
    location() {
      this.pe.push({
        method: 'location',
        arguments,
      });
    },
    getAddressComponent: da(q),
  });
  function Hc(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      Eg: t,
      anchor: a.anchor,
      Ea: a.offset,
    };
    this.cc = [];
    this.defaultAnchor = Fc;
    this.defaultOffset = new N(5, 2);
    this.rc(a.anchor);
    this.GJ = t;
    this.yf();
  }
  A.lang.xa(Hc, Cc, 'CopyrightControl');
  A.object.extend(Hc.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    Zv(a) {
      if (a && Za(a.id) && !isNaN(a.id)) {
        const b = {
          bounds: q,
          content: '',
        }; let
          c;
        for (c in a) b[c] = a[c];
        if (a = this.im(a.id)) for (const e in b) a[e] = b[e];
        else this.cc.push(b);
      }
    },
    im(a) {
      for (let b = 0, c = this.cc.length; b < c; b++) if (this.cc[b].id == a) return this.cc[b];
    },
    iD: x('cc'),
    HE(a) {
      for (let b = 0, c = this.cc.length; b < c; b++) {
        this.cc[b].id == a && (r = this.cc.splice(b, 1),
        b--,
        c = this.cc.length);
      }
    },
    yf() {
      const a = this;
      Ta.load('copyrightctrl', () => {
        a.xf();
      });
    },
  });
  function ob(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      Eg: t,
      size: a.size || new N(150, 150),
      padding: 5,
      bb: a.isOpen === p ? p : t,
      N0: 4,
      Ea: a.offset,
      anchor: a.anchor,
    };
    this.defaultAnchor = 3;
    this.defaultOffset = new N(0, 0);
    this.gq = this.hq = 13;
    this.rc(a.anchor);
    this.Be(this.m.size);
    this.yf();
  }
  A.lang.xa(ob, Cc, 'OverviewMapControl');
  A.extend(ob.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    rc(a) {
      Cc.prototype.rc.call(this, a);
    },
    qe() {
      this.qe.Tn = p;
      this.m.bb = !this.m.bb;
      this.R || (this.qe.Tn = t);
    },
    Be(a) {
      a instanceof N || (a = new N(150, 150));
      a.width = a.width > 0 ? a.width : 150;
      a.height = a.height > 0 ? a.height : 150;
      this.m.size = a;
    },
    xb() {
      return this.m.size;
    },
    bb() {
      return this.m.bb;
    },
    yf() {
      const a = this;
      Ta.load('control', () => {
        a.xf();
      });
    },
  });
  function Ic(a) {
    Cc.call(this);
    a = a || {};
    this.defaultAnchor = Dc;
    this.aV = a.canCheckSize === t ? t : p;
    this.$i = '';
    this.defaultOffset = new N(10, 10);
    this.onChangeBefore = [];
    this.onChangeAfter = [];
    this.onChangeSuccess = [];
    this.m = {
      Eg: t,
      Ea: a.offset || this.defaultOffset,
      anchor: a.anchor || this.defaultAnchor,
      expand: !!a.expand,
    };
    a.onChangeBefore && $a(a.onChangeBefore) && this.onChangeBefore.push(a.onChangeBefore);
    a.onChangeAfter && $a(a.onChangeAfter) && this.onChangeAfter.push(a.onChangeAfter);
    a.onChangeSuccess && $a(a.onChangeSuccess) && this.onChangeSuccess.push(a.onChangeSuccess);
    this.rc(a.anchor);
    this.yf();
  }
  A.lang.xa(Ic, Cc, 'CityListControl');
  A.object.extend(Ic.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    yf() {
      const a = this;
      Ta.load('citylistcontrol', () => {
        a.xf();
      }, p);
    },
  });
  function nb(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      Eg: t,
      color: 'black',
      dd: 'metric',
      Ea: a.offset,
    };
    this.defaultAnchor = Fc;
    this.defaultOffset = new N(81, 18);
    this.rc(a.anchor);
    this.Qh = {
      metric: {
        name: 'metric',
        WJ: 1,
        KL: 1E3,
        tO: '\u7c73',
        uO: '\u516c\u91cc',
      },
      us: {
        name: 'us',
        WJ: 3.2808,
        KL: 5280,
        tO: '\u82f1\u5c3a',
        uO: '\u82f1\u91cc',
      },
    };
    this.Qh[this.m.dd] || (this.m.dd = 'metric');
    this.zI = q;
    this.ZH = {};
    this.yf();
  }
  A.lang.xa(nb, Cc, 'ScaleControl');
  A.object.extend(nb.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    Lk(a) {
      this.m.color = `${a}`;
    },
    h3() {
      return this.m.color;
    },
    bF(a) {
      this.m.dd = this.Qh[a] && this.Qh[a].name || this.m.dd;
    },
    PX() {
      return this.m.dd;
    },
    yf() {
      const a = this;
      Ta.load('control', () => {
        a.xf();
      });
    },
  });
  const Jc = 0;
  function pb(a) {
    Cc.call(this);
    a = a || {};
    this.defaultAnchor = Ec;
    this.defaultOffset = new N(10, 10);
    this.m = {
      Eg: t,
      lh: [Na, ab, Sa, Qa],
      LV: ['B_DIMENSIONAL_MAP', 'B_SATELLITE_MAP', 'B_NORMAL_MAP'],
      type: a.type || Jc,
      Ea: a.offset || this.defaultOffset,
      uW: p,
    };
    this.rc(a.anchor);
    Object.prototype.toString.call(a.mapTypes) == '[object Array]' && (this.m.lh = a.mapTypes.slice(0));
    this.yf();
  }
  A.lang.xa(pb, Cc, 'MapTypeControl');
  A.object.extend(pb.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    qy(a) {
      this.P.Hn = a;
    },
    yf() {
      const a = this;
      Ta.load('control', () => {
        a.xf();
      }, p);
    },
  });
  function Kc(a) {
    Cc.call(this);
    a = a || {};
    this.m = {
      Eg: t,
      Ea: a.offset,
      anchor: a.anchor,
    };
    this.Ni = t;
    this.Hv = q;
    this.hI = new Lc({
      Se: 'api',
    });
    this.iI = new Mc(q, {
      Se: 'api',
    });
    this.defaultAnchor = Ec;
    this.defaultOffset = new N(10, 10);
    this.rc(a.anchor);
    this.yf();
    Ra(wa);
  }
  A.lang.xa(Kc, Cc, 'PanoramaControl');
  A.extend(Kc.prototype, {
    initialize(a) {
      this.P = a;
      return this.R;
    },
    yf() {
      const a = this;
      Ta.load('control', () => {
        a.xf();
      });
    },
  });
  function Nc(a) {
    A.lang.Ha.call(this);
    this.m = {
      ab: q,
      cursor: 'default',
    };
    this.m = A.extend(this.m, a);
    this.Kb = 'contextmenu';
    this.P = q;
    this.Aa = [];
    this.If = [];
    this.Ee = [];
    this.Aw = this.Qr = q;
    this.Hh = t;
    const b = this;
    Ta.load('menu', () => {
      b.mb();
    });
  }
  A.lang.xa(Nc, A.lang.Ha, 'ContextMenu');
  A.object.extend(Nc.prototype, {
    ya(a, b) {
      this.P = a;
      this.yl = b || q;
    },
    remove() {
      this.P = this.yl = q;
    },
    $v(a) {
      if (a && !(a.Kb != 'menuitem' || a.Yg == '' || a.Vi <= 0)) {
        for (let b = 0, c = this.Aa.length; b < c; b++) if (this.Aa[b] === a) return;
        this.Aa.push(a);
        this.If.push(a);
      }
    },
    removeItem(a) {
      if (a && a.Kb == 'menuitem') {
        for (var b = 0, c = this.Aa.length; b < c; b++) {
          this.Aa[b] === a && (this.Aa[b].remove(),
          this.Aa.splice(b, 1),
          c--);
        }
        b = 0;
        for (c = this.If.length; b < c; b++) {
          this.If[b] === a && (this.If[b].remove(),
          this.If.splice(b, 1),
          c--);
        }
      }
    },
    zB() {
      this.Aa.push({
        Kb: 'divider',
        Ij: this.Ee.length,
      });
      this.Ee.push({
        U: q,
      });
    },
    JE(a) {
      if (this.Ee[a]) {
        for (let b = 0, c = this.Aa.length; b < c; b++) {
          this.Aa[b] && (this.Aa[b].Kb == 'divider' && this.Aa[b].Ij == a) && (this.Aa.splice(b, 1),
          c--),
          this.Aa[b] && (this.Aa[b].Kb == 'divider' && this.Aa[b].Ij > a) && this.Aa[b].Ij--;
        }
        this.Ee.splice(a, 1);
      }
    },
    Yc: x('R'),
    show() {
      this.Hh != p && (this.Hh = p);
    },
    $() {
      this.Hh != t && (this.Hh = t);
    },
    f_(a) {
      a && (this.m.cursor = a);
    },
    getItem(a) {
      return this.If[a];
    },
  });
  const Oc = `${H.sa}menu_zoom_in.png`;
  const Pc = `${H.sa}menu_zoom_out.png`;
  function Qc(a, b, c) {
    if (a && $a(b)) {
      A.lang.Ha.call(this);
      this.m = {
        width: 100,
        id: '',
        sm: '',
      };
      c = c || {};
      this.m.width = 1 * c.width ? c.width : 100;
      this.m.id = c.id ? c.id : '';
      this.m.sm = c.iconUrl ? c.iconUrl : '';
      this.Yg = `${a}`;
      this.$y = b;
      this.P = q;
      this.Kb = 'menuitem';
      this.wr = this.Zu = this.R = this.Ch = q;
      this.Fh = p;
      const e = this;
      Ta.load('menu', () => {
        e.mb();
      });
    }
  }
  A.lang.xa(Qc, A.lang.Ha, 'MenuItem');
  A.object.extend(Qc.prototype, {
    ya(a, b) {
      this.P = a;
      this.Ch = b;
    },
    remove() {
      this.P = this.Ch = q;
    },
    Gt(a) {
      a && (this.Yg = `${a}`);
    },
    Ub(a) {
      a && (this.m.sm = a);
    },
    Yc: x('R'),
    enable() {
      this.Fh = p;
    },
    disable() {
      this.Fh = t;
    },
  });
  function hb(a, b) {
    a && !b && (b = a);
    this.He = this.Wd = this.Me = this.Zd = this.Kl = this.wl = q;
    a && (this.Kl = new Q(a.lng, a.lat),
    this.wl = new Q(b.lng, b.lat),
    this.Me = a.lng,
    this.Zd = a.lat,
    this.He = b.lng,
    this.Wd = b.lat);
  }
  A.object.extend(hb.prototype, {
    rj() {
      return !this.Kl || !this.wl;
    },
    Sb(a) {
      return !(a instanceof hb) || this.rj() ? t : this.Ve().Sb(a.Ve()) && this.Qf().Sb(a.Qf());
    },
    Ve: x('Kl'),
    Qf: x('wl'),
    rV(a) {
      return !(a instanceof hb) || this.rj() || a.rj() ? t : a.Me > this.Me && a.He < this.He && a.Zd > this.Zd && a.Wd < this.Wd;
    },
    Nb() {
      return this.rj() ? q : new Q((this.Me + this.He) / 2, (this.Zd + this.Wd) / 2);
    },
    Os(a) {
      if (!(a instanceof hb) || Math.max(a.Me, a.He) < Math.min(this.Me, this.He) || Math.min(a.Me, a.He) > Math.max(this.Me, this.He) || Math.max(a.Zd, a.Wd) < Math.min(this.Zd, this.Wd) || Math.min(a.Zd, a.Wd) > Math.max(this.Zd, this.Wd)) return q;
      const b = Math.max(this.Me, a.Me);
      const c = Math.min(this.He, a.He);
      const e = Math.max(this.Zd, a.Zd);
      var a = Math.min(this.Wd, a.Wd);
      return new hb(new Q(b, e), new Q(c, a));
    },
    Mr(a) {
      return !(a instanceof Q || a instanceof J) || this.rj() ? t : a.lng >= this.Me && a.lng <= this.He && a.lat >= this.Zd && a.lat <= this.Wd;
    },
    extend(a) {
      if (a instanceof Q || a instanceof J) {
        const b = a.lng;
        var a = a.lat;
        this.Kl || (this.Kl = new Q(0, 0));
        this.wl || (this.wl = new Q(0, 0));
        if (!this.Me || this.Me > b) this.Kl.lng = this.Me = b;
        if (!this.He || this.He < b) this.wl.lng = this.He = b;
        if (!this.Zd || this.Zd > a) this.Kl.lat = this.Zd = a;
        if (!this.Wd || this.Wd < a) this.wl.lat = this.Wd = a;
      }
    },
    sF() {
      return this.rj() ? new Q(0, 0) : new Q(Math.abs(this.He - this.Me), Math.abs(this.Wd - this.Zd));
    },
  });
  function Q(a, b) {
    isNaN(a) && (a = Nb(a),
    a = isNaN(a) ? 0 : a);
    bb(a) && (a = parseFloat(a));
    isNaN(b) && (b = Nb(b),
    b = isNaN(b) ? 0 : b);
    bb(b) && (b = parseFloat(b));
    this.lng = a;
    this.lat = b;
  }
  Q.VD = function (a) {
    return a && a.lng <= 180 && a.lng >= -180 && a.lat <= 74 && a.lat >= -74;
  };
  Q.prototype.Sb = function (a) {
    return a && this.lat == a.lat && this.lng == a.lng;
  };
  function J(a, b) {
    isNaN(a) && (a = Nb(a),
    a = isNaN(a) ? 0 : a);
    bb(a) && (a = parseFloat(a));
    isNaN(b) && (b = Nb(b),
    b = isNaN(b) ? 0 : b);
    bb(b) && (b = parseFloat(b));
    this.lng = a;
    this.lat = b;
    this.Se = 'inner';
  }
  J.VD = function (a) {
    return a && a.lng <= 180 && a.lng >= -180 && a.lat <= 74 && a.lat >= -74;
  };
  J.prototype.Sb = function (a) {
    return a && this.lat == a.lat && this.lng == a.lng;
  };
  function Rc() {}
  Rc.prototype.zg = function () {
    aa('lngLatToPoint\u65b9\u6cd5\u672a\u5b9e\u73b0');
  };
  Rc.prototype.vj = function () {
    aa('pointToLngLat\u65b9\u6cd5\u672a\u5b9e\u73b0');
  };
  function Sc() {}
  var gb = {
    YJ(a, b, c) {
      Ta.load('coordtransutils', () => {
        gb.CU(a, b, c);
      }, p);
    },
    XJ(a, b, c) {
      Ta.load('coordtransutils', () => {
        gb.BU(a, b, c);
      }, p);
    },
  };
  function Tc() {
    this.Ta = [];
    const a = this;
    Ta.load('convertor', () => {
      a.FP();
    });
  }
  A.xa(Tc, A.lang.Ha, 'Convertor');
  A.extend(Tc.prototype, {
    translate(a, b, c, e) {
      this.Ta.push({
        method: 'translate',
        arguments: [a, b, c, e],
      });
    },
  });
  V(Tc.prototype, {
    translate: Tc.prototype.translate,
  });
  function T() {}
  T.prototype = new Rc();
  A.extend(T, {
    $O: 6370996.81,
    fG: [1.289059486E7, 8362377.87, 5591021, 3481989.83, 1678043.12, 0],
    nu: [86, 60, 45, 30, 15, 0],
    fP: [[1.410526172116255E-8, 8.98305509648872E-6, -1.9939833816331, 200.9824383106796, -187.2403703815547, 91.6087516669843, -23.38765649603339, 2.57121317296198, -0.03801003308653, 1.73379812E7], [-7.435856389565537E-9, 8.983055097726239E-6, -0.78625201886289, 96.32687599759846, -1.85204757529826, -59.36935905485877, 47.40033549296737, -16.50741931063887, 2.28786674699375, 1.026014486E7], [-3.030883460898826E-8, 8.98305509983578E-6, 0.30071316287616, 59.74293618442277, 7.357984074871, -25.38371002664745, 13.45380521110908, -3.29883767235584, 0.32710905363475, 6856817.37], [-1.981981304930552E-8, 8.983055099779535E-6, 0.03278182852591, 40.31678527705744, 0.65659298677277, -4.44255534477492, 0.85341911805263, 0.12923347998204, -0.04625736007561, 4482777.06], [3.09191371068437E-9, 8.983055096812155E-6, 6.995724062E-5, 23.10934304144901, -2.3663490511E-4, -0.6321817810242, -0.00663494467273, 0.03430082397953, -0.00466043876332, 2555164.4], [2.890871144776878E-9, 8.983055095805407E-6, -3.068298E-8, 7.47137025468032, -3.53937994E-6, -0.02145144861037, -1.234426596E-5, 1.0322952773E-4, -3.23890364E-6, 826088.5]],
    cG: [[-0.0015702102444, 111320.7020616939, 1704480524535203, -10338987376042340, 26112667856603880, -35149669176653700, 26595700718403920, -10725012454188240, 1800819912950474, 82.5], [8.277824516172526E-4, 111320.7020463578, 6.477955746671607E8, -4.082003173641316E9, 1.077490566351142E10, -1.517187553151559E10, 1.205306533862167E10, -5.124939663577472E9, 9.133119359512032E8, 67.5], [0.00337398766765, 111320.7020202162, 4481351.045890365, -2.339375119931662E7, 7.968221547186455E7, -1.159649932797253E8, 9.723671115602145E7, -4.366194633752821E7, 8477230.501135234, 52.5], [0.00220636496208, 111320.7020209128, 51751.86112841131, 3796837.749470245, 992013.7397791013, -1221952.21711287, 1340652.697009075, -620943.6990984312, 144416.9293806241, 37.5], [-3.441963504368392E-4, 111320.7020576856, 278.2353980772752, 2485758.690035394, 6070.750963243378, 54821.18345352118, 9540.606633304236, -2710.55326746645, 1405.483844121726, 22.5], [-3.218135878613132E-4, 111320.7020701615, 0.00369383431289, 823725.6402795718, 0.46104986909093, 2351.343141331292, 1.58060784298199, 8.77738589078284, 0.37238884252424, 7.45]],
    n3(a, b) {
      if (!a || !b) return 0;
      let c; let e; var
        a = this.dc(a);
      if (!a) return 0;
      c = this.Tk(a.lng);
      e = this.Tk(a.lat);
      b = this.dc(b);
      return !b ? 0 : this.ue(c, this.Tk(b.lng), e, this.Tk(b.lat));
    },
    uk(a, b) {
      if (!a || !b) return 0;
      a.lng = this.pD(a.lng, -180, 180);
      a.lat = this.vD(a.lat, -74, 74);
      b.lng = this.pD(b.lng, -180, 180);
      b.lat = this.vD(b.lat, -74, 74);
      return this.ue(this.Tk(a.lng), this.Tk(b.lng), this.Tk(a.lat), this.Tk(b.lat));
    },
    dc(a) {
      if (a === q || a === l) return new J(0, 0);
      let b; let
        c;
      b = new J(Math.abs(a.lng), Math.abs(a.lat));
      for (let e = 0; e < this.fG.length; e++) {
        if (b.lat >= this.fG[e]) {
          c = this.fP[e];
          break;
        }
      }
      a = this.ZJ(a, c);
      return a = new J(a.lng, a.lat);
    },
    Wa(a) {
      if (a === q || a === l || a.lng > 180 || a.lng < -180 || a.lat > 90 || a.lat < -90) return new J(0, 0);
      let b; let
        c;
      a.lng = this.pD(a.lng, -180, 180);
      a.lat = this.vD(a.lat, -85, 85);
      b = new J(a.lng, a.lat);
      for (var e = 0; e < this.nu.length; e++) {
        if (b.lat >= this.nu[e]) {
          c = this.cG[e];
          break;
        }
      }
      if (!c) {
        for (e = 0; e < this.nu.length; e++) {
          if (b.lat <= -this.nu[e]) {
            c = this.cG[e];
            break;
          }
        }
      }
      a = this.ZJ(a, c);
      return a = new J(a.lng, a.lat);
    },
    ZJ(a, b) {
      if (a && b) {
        var c = b[0] + b[1] * Math.abs(a.lng);
        var e = Math.abs(a.lat) / b[9];
        var e = b[2] + b[3] * e + b[4] * e * e + b[5] * e * e * e + b[6] * e * e * e * e + b[7] * e * e * e * e * e + b[8] * e * e * e * e * e * e;
        var c = c * (a.lng < 0 ? -1 : 1);
        var e = e * (a.lat < 0 ? -1 : 1);
        return new J(c, e);
      }
    },
    ue(a, b, c, e) {
      return this.$O * Math.acos(Math.sin(c) * Math.sin(e) + Math.cos(c) * Math.cos(e) * Math.cos(b - a));
    },
    Tk(a) {
      return Math.PI * a / 180;
    },
    N5(a) {
      return 180 * a / Math.PI;
    },
    vD(a, b, c) {
      b != q && (a = Math.max(a, b));
      c != q && (a = Math.min(a, c));
      return a;
    },
    pD(a, b, c) {
      for (; a > c;) a -= c - b;
      for (; a < b;) a += c - b;
      return a;
    },
  });
  A.extend(T.prototype, {
    ii(a) {
      return T.Wa(a);
    },
    zg(a) {
      a = T.Wa(a);
      return new R(a.lng, a.lat);
    },
    nh(a) {
      return T.dc(a);
    },
    vj(a) {
      a = new J(a.x, a.y);
      a = T.dc(a);
      return new Q(a.lng, a.lat);
    },
    yc(a, b, c, e, f) {
      if (a) {
        return a = this.ii(a, f),
        b = this.Xb(b),
        new R(Math.round((a.lng - c.lng) / b + e.width / 2), Math.round((c.lat - a.lat) / b + e.height / 2));
      }
    },
    TY(a, b, c, e) {
      if (a) {
        return b = this.Xb(b),
        new R(Math.round((a.lng - c.lng) / b + e.width / 2), Math.round((c.lat - a.lat) / b + e.height / 2));
      }
    },
    Zb(a, b, c, e, f) {
      if (a) {
        return b = this.Xb(b),
        this.nh(new J(c.lng + b * (a.x - e.width / 2), c.lat - b * (a.y - e.height / 2)), f);
      }
    },
    Xb(a) {
      return Math.pow(2, 18 - a);
    },
    CN: ba('Ia'),
  });
  function jb() {
    this.$i = 'bj';
  }
  jb.prototype = new T();
  A.extend(jb.prototype, {
    ii(a, b) {
      return this.qQ(b, T.Wa(a));
    },
    nh(a, b) {
      return T.dc(this.rQ(b, a));
    },
    lngLatToPointFor3D(a, b) {
      const c = this;
      const e = T.Wa(a);
      Ta.load('coordtrans', () => {
        var a = Sc.tD(c.$i || 'bj', e);
        var a = new R(a.x, a.y);
        b && b(a);
      }, p);
    },
    pointToLngLatFor3D(a, b) {
      const c = this;
      const e = new Q(a.x, a.y);
      Ta.load('coordtrans', () => {
        var a = Sc.qD(c.$i || 'bj', e);
        var a = new Q(a.lng, a.lat);
        var a = T.dc(a);
        b && b(a);
      }, p);
    },
    qQ(a, b) {
      if (Ta.ob('coordtrans').Le == Ta.Bj.Np) {
        const c = Sc.tD(a || 'bj', b);
        return new Q(c.x, c.y);
      }
      Ta.load('coordtrans', u());
      return new Q(0, 0);
    },
    rQ(a, b) {
      if (Ta.ob('coordtrans').Le == Ta.Bj.Np) {
        const c = Sc.qD(a || 'bj', b);
        return new Q(c.lng, c.lat);
      }
      Ta.load('coordtrans', u());
      return new Q(0, 0);
    },
    Xb(a) {
      return Math.pow(2, 20 - a);
    },
    CN: ba('Ia'),
  });
  function Vc() {
    this.Kb = 'overlay';
  }
  A.lang.xa(Vc, A.lang.Ha, 'Overlay');
  Vc.zk = function (a) {
    a *= 1;
    return !a ? 0 : -1E5 * a << 1;
  };
  A.extend(Vc.prototype, {
    Ge(a) {
      if (!this.ba && $a(this.initialize) && (this.ba = this.initialize(a))) this.ba.style.WebkitUserSelect = 'none';
      this.draw();
    },
    initialize() {
      aa('initialize\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    draw() {
      aa('draw\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    remove() {
      this.ba && this.ba.parentNode && this.ba.parentNode.removeChild(this.ba);
      this.ba = q;
      this.dispatchEvent(new P('onremove'));
    },
    $() {
      this.ba && A.U.$(this.ba);
    },
    show() {
      this.ba && A.U.show(this.ba);
    },
    Oc() {
      return !this.ba || this.ba.style.display == 'none' || this.ba.style.visibility == 'hidden' ? t : p;
    },
  });
  D.Ze((a) => {
    function b(a, b) {
      const c = L('div');
      const i = c.style;
      i.position = 'absolute';
      i.top = i.left = i.width = i.height = '0';
      i.zIndex = b;
      a.appendChild(c);
      return c;
    }
    const c = a.aa;
    c.Pc = a.Pc = b(a.platform, 200);
    a.Xd.VC = b(c.Pc, 800);
    a.Xd.mE = b(c.Pc, 700);
    a.Xd.JK = b(c.Pc, 600);
    a.Xd.eE = b(c.Pc, 500);
    a.Xd.vM = b(c.Pc, 400);
    a.Xd.wM = b(c.Pc, 300);
    a.Xd.FO = b(c.Pc, 201);
    a.Xd.at = b(c.Pc, 200);
  });
  function ib() {
    A.lang.Ha.call(this);
    Vc.call(this);
    this.map = q;
    this.Ua = p;
    this.Db = q;
    this.SG = 0;
  }
  A.lang.xa(ib, Vc, 'OverlayInternal');
  A.extend(ib.prototype, {
    initialize(a) {
      this.map = a;
      A.lang.Ha.call(this, this.ca);
      return q;
    },
    Vw: x('map'),
    draw: u(),
    Cj: u(),
    remove() {
      this.map = q;
      A.lang.Dw(this.ca);
      Vc.prototype.remove.call(this);
    },
    $() {
      this.Ua !== t && (this.Ua = t);
    },
    show() {
      this.Ua !== p && (this.Ua = p);
    },
    Oc() {
      return !this.ba ? t : !!this.Ua;
    },
    Ra: x('ba'),
    BN(a) {
      var a = a || {}; let
        b;
      for (b in a) this.K[b] = a[b];
    },
    Cp: ba('zIndex'),
    ej() {
      this.K.ej = p;
    },
    UV() {
      this.K.ej = t;
    },
    jo: ba('jg'),
    mp() {
      this.jg = q;
    },
  });
  function Wc() {
    this.map = q;
    this.Ba = {};
    this.De = [];
  }
  D.Ze((a) => {
    const b = new Wc();
    b.map = a;
    a.Ba = b.Ba;
    a.De = b.De;
    a.addEventListener('load', (a) => {
      b.draw(a);
    });
    a.addEventListener('moveend', (a) => {
      b.draw(a);
    });
    A.fa.na && A.fa.na < 8 || document.compatMode === 'BackCompat' ? a.addEventListener('zoomend', (a) => {
      setTimeout(() => {
        b.draw(a);
      }, 20);
    }) : a.addEventListener('zoomend', (a) => {
      b.draw(a);
    });
    a.addEventListener('maptypechange', (a) => {
      b.draw(a);
    });
    a.addEventListener('addoverlay', (a) => {
      a = a.target;
      if (a instanceof ib) b.Ba[a.ca] || (b.Ba[a.ca] = a);
      else {
        for (var e = t, f = 0, g = b.De.length; f < g; f++) {
          if (b.De[f] === a) {
            e = p;
            break;
          }
        }
        e || b.De.push(a);
      }
    });
    a.addEventListener('removeoverlay', (a) => {
      a = a.target;
      if (a instanceof ib) delete b.Ba[a.ca];
      else {
        for (let e = 0, f = b.De.length; e < f; e++) {
          if (b.De[e] === a) {
            b.De.splice(e, 1);
            break;
          }
        }
      }
    });
    a.addEventListener('clearoverlays', function () {
      this.Wc();
      for (var a in b.Ba) {
        b.Ba[a].K.ej && (b.Ba[a].remove(),
        delete b.Ba[a]);
      }
      a = 0;
      for (let e = b.De.length; a < e; a++) {
        b.De[a].enableMassClear !== t && (b.De[a].remove(),
        b.De[a] = q,
        b.De.splice(a, 1),
        a--,
        e--);
      }
    });
    a.addEventListener('infowindowopen', function () {
      const a = this.Db;
      a && (A.U.$(a.zc),
      A.U.$(a.$b));
    });
    a.addEventListener('movestart', function () {
      this.ih() && this.ih().FI();
    });
    a.addEventListener('moveend', function () {
      this.ih() && this.ih().uI();
    });
  });
  Wc.prototype.draw = function (a) {
    if (D.Qp) {
      var b = D.Qp.ws(this.map);
      b.Kb === 'canvas' && b.canvas && b.lQ(b.canvas.getContext('2d'));
    }
    for (const c in this.Ba) this.Ba[c].draw(a);
    A.jc.Mb(this.De, (a) => {
      a.draw();
    });
    this.map.aa.sb && this.map.aa.sb.va();
    D.Qp && b.ZE();
  };
  function Xc(a) {
    ib.call(this);
    a = a || {};
    this.K = {
      strokeColor: a.strokeColor || '#3a6bdb',
      nc: a.strokeWeight || 5,
      ud: a.strokeOpacity || 0.65,
      strokeStyle: a.strokeStyle || 'solid',
      ej: a.enableMassClear === t ? t : p,
      wk: q,
      lm: q,
      kf: a.enableEditing === p ? p : t,
      AM: 5,
      t0: t,
      gf: a.enableClicking === t ? t : p,
      fi: a.icons && a.icons.length > 0 ? a.icons : q,
      PW: a.geodesic === p ? p : t,
      iE: a.linkRight === p ? p : t,
    };
    this.K.nc <= 0 && (this.K.nc = 5);
    if (this.K.ud < 0 || this.K.ud > 1) this.K.ud = 0.65;
    if (this.K.tg < 0 || this.K.tg > 1) this.K.tg = 0.65;
    this.K.strokeStyle != 'solid' && this.K.strokeStyle != 'dashed' && (this.K.strokeStyle = 'solid');
    this.ba = q;
    this.vu = new hb(0, 0);
    this.ef = [];
    this.oc = [];
    this.Va = {};
  }
  A.lang.xa(Xc, ib, 'Graph');
  Xc.Sw = function (a) {
    let b = [];
    if (!a) return b;
    bb(a) && A.jc.Mb(a.split(';'), (a) => {
      a = a.split(',');
      b.push(new Q(a[0], a[1]));
    });
    Object.prototype.toString.apply(a) == '[object Array]' && a.length > 0 && (b = a);
    return b;
  };
  Xc.xE = [0.09, 0.0050, 1.0E-4, 1.0E-5];
  A.extend(Xc.prototype, {
    initialize(a) {
      this.map = a;
      return q;
    },
    draw: u(),
    or(a) {
      this.ef.length = 0;
      this.ka = Xc.Sw(a).slice(0);
      this.zh();
    },
    le(a) {
      this.or(a);
    },
    zh() {
      if (this.ka) {
        const a = this;
        a.vu = new hb();
        A.jc.Mb(this.ka, (b) => {
          a.vu.extend(b);
        });
      }
    },
    Ue: x('ka'),
    Om(a, b) {
      b && this.ka[a] && (this.ef.length = 0,
      this.ka[a] = new Q(b.lng, b.lat),
      this.zh());
    },
    setStrokeColor(a) {
      this.K.strokeColor = a;
    },
    HX() {
      return this.K.strokeColor;
    },
    Bp(a) {
      a > 0 && (this.K.nc = a);
    },
    lL() {
      return this.K.nc;
    },
    zp(a) {
      a == l || (a > 1 || a < 0) || (this.K.ud = a);
    },
    IX() {
      return this.K.ud;
    },
    zt(a) {
      a > 1 || a < 0 || (this.K.tg = a);
    },
    bX() {
      return this.K.tg;
    },
    Ap(a) {
      a != 'solid' && a != 'dashed' || (this.K.strokeStyle = a);
    },
    kL() {
      return this.K.strokeStyle;
    },
    setFillColor(a) {
      this.K.fillColor = a || '';
    },
    aX() {
      return this.K.fillColor;
    },
    te: x('vu'),
    remove() {
      this.map && this.map.removeEventListener('onmousemove', this.Wu);
      ib.prototype.remove.call(this);
      this.ef.length = 0;
    },
    kf() {
      if (!(this.ka.length < 2)) {
        this.K.kf = p;
        const a = this;
        Ta.load('poly', () => {
          a.Pl();
        }, p);
      }
    },
    TV() {
      this.K.kf = t;
      const a = this;
      Ta.load('poly', () => {
        a.jk();
      }, p);
    },
    YW() {
      return this.K.kf;
    },
    eX() {
      for (var a = [], b = 0; b < this.ka.length - 1; b++) {
        const c = this.WU(this.ka[b], this.ka[b + 1]);
        var a = a.concat(c);
      }
      return a = a.concat(this.ka[this.ka.length - 1]);
    },
    WU(a, b) {
      if (a.Sb(b)) return [a];
      var c = T.ue(U(a.lng), U(a.lat), U(b.lng), U(b.lat));
      var c = T.uk(a, b);
      if (c < 25E4) return [a];
      const e = [];
      var c = Math.round(c / 15E4);
      const f = this.JJ(a, b);
      e.push(a);
      for (let g = 0; g < c; g++) {
        const i = this.KJ(a, b, g / c, f);
        e.push(i);
      }
      e.push(b);
      return e;
    },
    KJ(a, b, c, e) {
      const f = U(a.lat);
      const g = U(b.lat);
      var a = U(a.lng);
      const i = U(b.lng);
      var b = Math.sin((1 - c) * e) / Math.sin(e);
      var c = Math.sin(c * e) / Math.sin(e);
      var e = b * Math.cos(f) * Math.cos(a) + c * Math.cos(g) * Math.cos(i);
      var a = b * Math.cos(f) * Math.sin(a) + c * Math.cos(g) * Math.sin(i);
      return new Q(180 * (Math.atan2(a, e) / Math.PI), 180 * (Math.atan2(b * Math.sin(f) + c * Math.sin(g), Math.sqrt(Math.pow(e, 2) + Math.pow(a, 2))) / Math.PI));
    },
    JJ(a, b) {
      const c = U(a.lat);
      const e = U(b.lat);
      return Math.acos(Math.sin(c) * Math.sin(e) + Math.cos(c) * Math.cos(e) * Math.cos(Math.abs(U(b.lng) - U(a.lng))));
    },
  });
  function Yc(a) {
    ib.call(this);
    this.ba = this.map = q;
    this.K = {
      width: 0,
      height: 0,
      Ea: new N(0, 0),
      opacity: 1,
      background: 'transparent',
      zx: 1,
      hM: '#000',
      KY: 'solid',
      point: q,
    };
    this.BN(a);
    this.point = this.K.point;
  }
  A.lang.xa(Yc, ib, 'Division');
  A.extend(Yc.prototype, {
    Cj() {
      const a = this.K;
      const b = this.content;
      const c = ['<div class="BMap_Division" style="position:absolute;'];
      c.push(`width:${a.width}px;display:block;`);
      c.push('overflow:hidden;');
      a.borderColor != 'none' && c.push(`border:${a.zx}px ${a.KY} ${a.hM};`);
      c.push(`opacity:${a.opacity}; filter:(opacity=${100 * a.opacity})`);
      c.push(`background:${a.background};`);
      c.push('z-index:60;">');
      c.push(b);
      c.push('</div>');
      this.ba = Db(this.map.Rf().mE, c.join(''));
    },
    initialize(a) {
      this.map = a;
      this.Cj();
      this.ba && A.V(this.ba, I() ? 'touchstart' : 'mousedown', (a) => {
        ma(a);
      });
      return this.ba;
    },
    draw() {
      const a = this.map.Ye(this.K.point);
      this.K.Ea = new N(-Math.round(this.K.width / 2) - Math.round(this.K.zx), -Math.round(this.K.height / 2) - Math.round(this.K.zx));
      this.ba.style.left = `${a.x + this.K.Ea.width}px`;
      this.ba.style.top = `${a.y + this.K.Ea.height}px`;
    },
    la() {
      return this.K.point;
    },
    A1() {
      return this.map.Qn(this.la());
    },
    va(a) {
      this.K.point = a;
      this.draw();
    },
    g_(a, b) {
      this.K.width = Math.round(a);
      this.K.height = Math.round(b);
      this.ba && (this.ba.style.width = `${this.K.width}px`,
      this.ba.style.height = `${this.K.height}px`,
      this.draw());
    },
  });
  function Zc(a, b, c) {
    a && b && (this.imageUrl = a,
    this.size = b,
    a = new N(Math.floor(b.width / 2), Math.floor(b.height / 2)),
    c = c || {},
    a = c.anchor || a,
    b = c.imageOffset || new N(0, 0),
    this.imageSize = c.imageSize,
    this.anchor = a,
    this.imageOffset = b,
    this.infoWindowAnchor = c.infoWindowAnchor || this.anchor,
    this.printImageUrl = c.printImageUrl || '');
  }
  A.extend(Zc.prototype, {
    DN(a) {
      a && (this.imageUrl = a);
    },
    x_(a) {
      a && (this.printImageUrl = a);
    },
    Be(a) {
      a && (this.size = new N(a.width, a.height));
    },
    rc(a) {
      a && (this.anchor = new N(a.width, a.height));
    },
    At(a) {
      a && (this.imageOffset = new N(a.width, a.height));
    },
    l_(a) {
      a && (this.infoWindowAnchor = new N(a.width, a.height));
    },
    i_(a) {
      a && (this.imageSize = new N(a.width, a.height));
    },
    toString: da('Icon'),
  });
  function $c(a, b) {
    if (a) {
      b = b || {};
      this.style = {
        anchor: b.anchor || new N(0, 0),
        fillColor: b.fillColor || '#000',
        tg: b.fillOpacity || 0,
        scale: b.scale || 1,
        rotation: b.rotation || 0,
        strokeColor: b.strokeColor || '#000',
        ud: b.strokeOpacity || 1,
        nc: b.strokeWeight,
      };
      this.Kb = typeof a === 'number' ? a : 'UserDefined';
      this.Di = this.style.anchor;
      this.Tq = new N(0, 0);
      this.anchor = q;
      this.QA = a;
      const c = this;
      Ta.load('symbol', () => {
        c.mn();
      }, p);
    }
  }
  A.extend($c.prototype, {
    setPath: ba('QA'),
    setAnchor(a) {
      this.Di = this.style.anchor = a;
    },
    setRotation(a) {
      this.style.rotation = a;
    },
    setScale(a) {
      this.style.scale = a;
    },
    setStrokeWeight(a) {
      this.style.nc = a;
    },
    setStrokeColor(a) {
      a = A.Kr.XB(a, this.style.ud);
      this.style.strokeColor = a;
    },
    setStrokeOpacity(a) {
      this.style.ud = a;
    },
    setFillOpacity(a) {
      this.style.tg = a;
    },
    setFillColor(a) {
      this.style.fillColor = a;
    },
  });
  function ad(a, b, c, e) {
    a && (this.ov = {},
    this.HK = e ? !!e : t,
    this.Uc = [],
    this.Q_ = a instanceof $c ? a : q,
    this.nI = b === l ? p : !!(b.indexOf('%') + 1),
    this.Wj = isNaN(parseFloat(b)) ? 1 : this.nI ? parseFloat(b) / 100 : parseFloat(b),
    this.oI = !!(c.indexOf('%') + 1),
    this.repeat = c != l ? this.oI ? parseFloat(c) / 100 : parseFloat(c) : 0);
  }
  function bd(a, b) {
    A.lang.Ha.call(this);
    this.content = a;
    this.map = q;
    b = b || {};
    this.K = {
      width: b.width || 0,
      height: b.height || 0,
      maxWidth: b.maxWidth || 730,
      Ea: b.offset || new N(0, 0),
      title: b.title || '',
      oE: b.maxContent || '',
      fh: b.enableMaximize || t,
      hs: b.enableAutoPan === t ? t : p,
      EC: b.enableCloseOnClick === t ? t : p,
      margin: b.margin || [10, 10, 40, 10],
      TB: b.collisions || [[10, 10], [10, 10], [10, 10], [10, 10]],
      dY: t,
      hZ: b.onClosing || da(p),
      AK: t,
      JC: b.enableParano === p ? p : t,
      message: b.message,
      MC: b.enableSearchTool === p ? p : t,
      ix: b.headerContent || '',
      FC: b.enableContentScroll || t,
    };
    if (this.K.width != 0 && (this.K.width < 220 && (this.K.width = 220),
    this.K.width > 730)) this.K.width = 730;
    if (this.K.height != 0 && (this.K.height < 60 && (this.K.height = 60),
    this.K.height > 650)) this.K.height = 650;
    if (this.K.maxWidth != 0 && (this.K.maxWidth < 220 && (this.K.maxWidth = 220),
    this.K.maxWidth > 730)) this.K.maxWidth = 730;
    this.ee = t;
    this.yi = H.sa;
    this.tb = q;
    const c = this;
    Ta.load('infowindow', () => {
      c.mb();
    });
  }
  A.lang.xa(bd, A.lang.Ha, 'InfoWindow');
  A.extend(bd.prototype, {
    setWidth(a) {
      !a && a != 0 || (isNaN(a) || a < 0) || (a != 0 && (a < 220 && (a = 220),
      a > 730 && (a = 730)),
      this.K.width = a);
    },
    setHeight(a) {
      !a && a != 0 || (isNaN(a) || a < 0) || (a != 0 && (a < 60 && (a = 60),
      a > 650 && (a = 650)),
      this.K.height = a);
    },
    IN(a) {
      !a && a != 0 || (isNaN(a) || a < 0) || (a != 0 && (a < 220 && (a = 220),
      a > 730 && (a = 730)),
      this.K.maxWidth = a);
    },
    Dc(a) {
      this.K.title = a;
    },
    getTitle() {
      return this.K.title;
    },
    bd: ba('content'),
    tk: x('content'),
    Ct(a) {
      this.K.oE = `${a}`;
    },
    ke: u(),
    hs() {
      this.K.hs = p;
    },
    disableAutoPan() {
      this.K.hs = t;
    },
    enableCloseOnClick() {
      this.K.EC = p;
    },
    disableCloseOnClick() {
      this.K.EC = t;
    },
    fh() {
      this.K.fh = p;
    },
    Fw() {
      this.K.fh = t;
    },
    show() {
      this.Ua = p;
    },
    $() {
      this.Ua = t;
    },
    close() {
      this.$();
    },
    Cx() {
      this.ee = p;
    },
    restore() {
      this.ee = t;
    },
    Oc() {
      return this.bb();
    },
    bb: da(t),
    la() {
      if (this.tb && this.tb.la) return this.tb.la();
    },
    hj() {
      return this.K.Ea;
    },
  });
  Ma.prototype.$c = function (a, b) {
    if (a instanceof bd && (b instanceof Q || b instanceof J)) {
      const c = this.aa;
      c.xm ? c.xm.va(b) : (c.xm = new W(b, {
        icon: new Zc(`${H.sa}blank.gif`, {
          width: 1,
          height: 1,
        }),
        offset: new N(0, 0),
        clickable: t,
      }),
      c.xm.jR = 1);
      this.Pa(c.xm);
      c.xm.$c(a);
    }
  };
  Ma.prototype.Wc = function () {
    const a = this.aa.sb || this.aa.nl;
    a && a.tb && a.tb.Wc();
  };
  ib.prototype.$c = function (a) {
    this.map && (this.map.Wc(),
    a.Ua = p,
    this.map.aa.nl = a,
    a.tb = this,
    A.lang.Ha.call(a, a.ca));
  };
  ib.prototype.Wc = function () {
    this.map && this.map.aa.nl && (this.map.aa.nl.Ua = t,
    A.lang.Dw(this.map.aa.nl.ca),
    this.map.aa.nl = q);
  };
  function cd(a, b) {
    ib.call(this);
    this.content = a;
    this.ba = this.map = q;
    b = b || {};
    this.K = {
      width: 0,
      Ea: b.offset || new N(0, 0),
      Gp: {
        backgroundColor: '#fff',
        border: '1px solid #f00',
        padding: '1px',
        whiteSpace: 'nowrap',
        font: `12px ${H.fontFamily}`,
        zIndex: '80',
        MozUserSelect: 'none',
      },
      position: b.position || q,
      ej: b.enableMassClear === t ? t : p,
      gf: p,
      left: b.left === p ? p : t,
      right: b.right === p ? p : t,
    };
    this.K.width < 0 && (this.K.width = 0);
    Jb(b.enableClicking) && (this.K.gf = b.enableClicking);
    this.point = this.K.position;
    const c = this;
    Ta.load('marker', () => {
      c.mb();
    });
  }
  A.lang.xa(cd, ib, 'Label');
  A.extend(cd.prototype, {
    la() {
      return this.Ln ? this.Ln.la() : this.map ? cb(this.point, this.map.M.Ia) : this.point;
    },
    Oj() {
      return this.Ln ? this.Ln.Oj() : this.point;
    },
    va(a) {
      if ((a instanceof Q || a instanceof J) && !this.Ww()) this.point = this.K.position = new Q(a.lng, a.lat);
    },
    bd: ba('content'),
    YE(a) {
      a >= 0 && a <= 1 && (this.K.opacity = a);
    },
    Ld(a) {
      a instanceof N && (this.K.Ea = new N(a.width, a.height));
    },
    hj() {
      return this.K.Ea;
    },
    Md(a) {
      a = a || {};
      this.K.Gp = A.extend(this.K.Gp, a);
    },
    ti(a) {
      return this.Md(a);
    },
    Dc(a) {
      this.K.title = a || '';
    },
    getTitle() {
      return this.K.title;
    },
    HN(a) {
      this.point = (this.Ln = a) ? this.K.position = a.Oj() : this.K.position = q;
    },
    Ww() {
      return this.Ln || q;
    },
    tk: x('content'),
  });
  function dd(a, b) {
    if (arguments.length !== 0) {
      ib.apply(this, arguments);
      b = b || {};
      this.K = {
        ib: a,
        opacity: b.opacity || 1,
        Zo: b.imageURL || '',
        Zr: b.displayOnMinLevel || 1,
        ej: b.enableMassClear === t ? t : p,
        Yr: b.displayOnMaxLevel || 19,
        K_: b.stretch || t,
      };
      b.opacity === 0 && (this.K.opacity = 0);
      const c = this;
      Ta.load('groundoverlay', () => {
        c.mb();
      });
    }
  }
  A.lang.xa(dd, ib, 'GroundOverlay');
  A.extend(dd.prototype, {
    setBounds(a) {
      this.K.ib = a;
    },
    getBounds() {
      return this.K.ib;
    },
    setOpacity(a) {
      this.K.opacity = a;
    },
    getOpacity() {
      return this.K.opacity;
    },
    setImageURL(a) {
      this.K.Zo = a;
    },
    getImageURL() {
      return this.K.Zo;
    },
    setDisplayOnMinLevel(a) {
      this.K.Zr = a;
    },
    getDisplayOnMinLevel() {
      return this.K.Zr;
    },
    setDisplayOnMaxLevel(a) {
      this.K.Yr = a;
    },
    getDisplayOnMaxLevel() {
      return this.K.Yr;
    },
  });
  const ed = 3;
  const fd = 4;
  function gd() {
    const a = document.createElement('canvas');
    return !(!a.getContext || !a.getContext('2d'));
  }
  function hd(a, b) {
    const c = this;
    gd() && (a === l && aa(Error('\u6ca1\u6709\u4f20\u5165points\u6570\u636e')),
    Object.prototype.toString.call(a) !== '[object Array]' && aa(Error('points\u6570\u636e\u4e0d\u662f\u6570\u7ec4')),
    b = b || {},
    ib.apply(c, arguments),
    c.ha = {
      ka: a,
    },
    c.K = {
      shape: b.shape || ed,
      size: b.size || fd,
      color: b.color || '#fa937e',
      ej: p,
    },
    this.NA = [],
    this.pe = [],
    Ta.load('pointcollection', () => {
      for (var a = 0, b; b = c.NA[a]; a++) c[b.method].apply(c, b.arguments);
      for (a = 0; b = c.pe[a]; a++) c[b.method].apply(c, b.arguments);
    }));
  }
  A.lang.xa(hd, ib, 'PointCollection');
  A.extend(hd.prototype, {
    initialize(a) {
      this.NA && this.NA.push({
        method: 'initialize',
        arguments,
      });
    },
    setPoints(a) {
      this.pe && this.pe.push({
        method: 'setPoints',
        arguments,
      });
    },
    setStyles(a) {
      this.pe && this.pe.push({
        method: 'setStyles',
        arguments,
      });
    },
    clear() {
      this.pe && this.pe.push({
        method: 'clear',
        arguments,
      });
    },
    remove() {
      this.pe && this.pe.push({
        method: 'remove',
        arguments,
      });
    },
  });
  const id = new Zc(`${H.sa}marker_red_sprite.png`, new N(19, 25), {
    anchor: new N(10, 25),
    infoWindowAnchor: new N(10, 0),
  });
  const jd = new Zc(`${H.sa}marker_red_sprite.png`, new N(20, 11), {
    anchor: new N(6, 11),
    imageOffset: new N(-19, -13),
  });
  function W(a, b) {
    ib.call(this);
    b = b || {};
    this.point = a;
    this.Ia = (this.cq = this.map = q) ? this.map.M.Ia : 5;
    this.K = {
      Ea: b.offset || new N(0, 0),
      ve: b.icon || id,
      Nk: jd,
      title: b.title || '',
      label: q,
      EJ: b.baseZIndex || 0,
      gf: p,
      n6: t,
      aE: t,
      ej: b.enableMassClear === t ? t : p,
      pc: t,
      jN: b.raiseOnDrag === p ? p : t,
      rN: t,
      Gd: b.draggingCursor || H.Gd,
      rotation: b.rotation || 0,
      left: b.left === p ? p : t,
      right: b.right === p ? p : t,
    };
    b.icon && !b.shadow && (this.K.Nk = q);
    b.enableDragging && (this.K.pc = b.enableDragging);
    Jb(b.enableClicking) && (this.K.gf = b.enableClicking);
    const c = this;
    Ta.load('marker', () => {
      c.mb();
    });
  }
  W.qu = Vc.zk(-90) + 1E6;
  W.XF = W.qu + 1E6;
  A.lang.xa(W, ib, 'Marker');
  A.extend(W.prototype, {
    Ub(a) {
      if (a instanceof Zc || a instanceof $c) this.K.ve = a;
    },
    Oo() {
      return this.K.ve;
    },
    iy(a) {
      a instanceof Zc && (this.K.Nk = a);
    },
    getShadow() {
      return this.K.Nk;
    },
    Mm(a) {
      this.K.label = a || q;
    },
    oD() {
      return this.K.label;
    },
    pc() {
      this.K.pc = p;
    },
    mC() {
      this.K.pc = t;
    },
    Oj: x('point'),
    la() {
      return this.point instanceof Q || this.point instanceof J ? this.map ? cb(this.point, this.map.M.Ia) : new Q(this.point.lng, this.point.lat) : this.point;
    },
    va(a) {
      if (a instanceof Q || a instanceof J) this.point = this.map ? Ya(a, this.map.M.Ia) : new J(a.lng, a.lat);
    },
    ui(a, b) {
      this.K.aE = !!a;
      a && (this.uG = b || 0);
    },
    Dc(a) {
      this.K.title = `${a}`;
    },
    getTitle() {
      return this.K.title;
    },
    Ld(a) {
      a instanceof N && (this.K.Ea = a);
    },
    hj() {
      return this.K.Ea;
    },
    Lm: ba('cq'),
    yp(a) {
      this.K.rotation = a;
    },
    iL() {
      return this.K.rotation;
    },
  });
  function kd(a) {
    this.options = a || {};
    this.lZ = this.options.paneName || 'labelPane';
    this.zIndex = this.options.zIndex || 0;
    this.sV = this.options.contextType || '2d';
  }
  kd.prototype = new Vc();
  kd.prototype.initialize = function (a) {
    this.P = a;
    const b = this.canvas = document.createElement('canvas');
    const c = this.canvas.getContext(this.sV);
    b.style.cssText = `position:absolute;left:0;top:0;z-index:${this.zIndex};`;
    ld(this);
    md(c);
    a.getPanes()[this.lZ].appendChild(b);
    const e = this;
    a.addEventListener('resize', () => {
      ld(e);
      md(c);
      e.mb();
    });
    return this.canvas;
  };
  function ld(a) {
    const b = a.P.xb();
    var a = a.canvas;
    a.width = b.width;
    a.height = b.height;
    a.style.width = `${a.width}px`;
    a.style.height = `${a.height}px`;
  }
  function md(a) {
    const b = (window.devicePixelRatio || 1) / (a.FU || a.i6 || a.F4 || a.G4 || a.K4 || a.FU || 1);
    const c = a.canvas.width;
    const e = a.canvas.height;
    a.canvas.width = c * b;
    a.canvas.height = e * b;
    a.canvas.style.width = `${c}px`;
    a.canvas.style.height = `${e}px`;
    a.scale(b, b);
  }
  kd.prototype.draw = function () {
    const a = this;
    const b = arguments;
    clearTimeout(a.Z_);
    a.Z_ = setTimeout(() => {
      a.mb.apply(a, b);
    }, 15);
  };
  ea = kd.prototype;
  ea.mb = function () {
    const a = this.P;
    this.canvas.style.left = `${-a.offsetX}px`;
    this.canvas.style.top = `${-a.offsetY}px`;
    this.dispatchEvent('draw');
    this.options.update && this.options.update.apply(this, arguments);
  };
  ea.Ra = x('canvas');
  ea.show = function () {
    this.canvas || this.P.Pa(this);
    this.canvas.style.display = 'block';
  };
  ea.$ = function () {
    this.canvas.style.display = 'none';
  };
  ea.Cp = function (a) {
    this.canvas.style.zIndex = a;
  };
  ea.zk = x('zIndex');
  function nd(a, b) {
    Xc.call(this, b);
    b = b || {};
    this.K.tg = b.fillOpacity ? b.fillOpacity : 0.65;
    this.K.fillColor = b.fillColor == '' ? '' : b.fillColor ? b.fillColor : '#fff';
    this.le(a);
    const c = this;
    Ta.load('poly', () => {
      c.mb();
    });
  }
  A.lang.xa(nd, Xc, 'Polygon');
  A.extend(nd.prototype, {
    le(a, b) {
      this.bo = Xc.Sw(a).slice(0);
      const c = Xc.Sw(a).slice(0);
      c.length > 1 && c.push(new Q(c[0].lng, c[0].lat));
      Xc.prototype.le.call(this, c, b);
    },
    Om(a, b) {
      this.bo[a] && (this.bo[a] = new Q(b.lng, b.lat),
      this.ka[a] = new Q(b.lng, b.lat),
      a == 0 && !this.ka[0].Sb(this.ka[this.ka.length - 1]) && (this.ka[this.ka.length - 1] = new Q(b.lng, b.lat)),
      this.zh());
    },
    Ue() {
      let a = this.bo;
      a.length == 0 && (a = this.ka);
      return a;
    },
  });
  function od(a, b) {
    Xc.call(this, b);
    this.or(a);
    const c = this;
    Ta.load('poly', () => {
      c.mb();
    });
  }
  A.lang.xa(od, Xc, 'Polyline');
  function pd(a, b, c) {
    this.point = a;
    this.Da = Math.abs(b);
    nd.call(this, [], c);
  }
  pd.xE = [0.01, 1.0E-4, 1.0E-5, 4.0E-6];
  A.lang.xa(pd, nd, 'Circle');
  A.extend(pd.prototype, {
    initialize(a) {
      this.map = a;
      this.ka = this.Ru(this.point, this.Da);
      this.zh();
      return q;
    },
    Nb() {
      return this.map ? cb(this.point, this.map.M.Ia) : this.point;
    },
    Ou: x('point'),
    tf(a) {
      a && (this.point = a);
    },
    gL: x('Da'),
    uf(a) {
      this.Da = Math.abs(a);
    },
    Ru(a, b) {
      if (!a || !b || !this.map) return [];
      for (var c = [], e = b / 6378800, f = Math.PI / 180 * a.lat, g = Math.PI / 180 * a.lng, i = 0; i < 360; i += 9) {
        var k = Math.PI / 180 * i;
        const m = Math.asin(Math.sin(f) * Math.cos(e) + Math.cos(f) * Math.sin(e) * Math.cos(k));
        var k = new Q(((g - Math.atan2(Math.sin(k) * Math.sin(e) * Math.cos(f), Math.cos(e) - Math.sin(f) * Math.sin(m)) + Math.PI) % (2 * Math.PI) - Math.PI) * (180 / Math.PI), m * (180 / Math.PI));
        c.push(k);
      }
      e = c[0];
      c.push(new Q(e.lng, e.lat));
      return c;
    },
  });
  const qd = {};
  function rd(a) {
    this.map = a;
    this.tj = [];
    this.Zf = [];
    this.Hg = [];
    this.UU = 300;
    this.EE = 0;
    this.Ag = {};
    this.Zi = {};
    this.Dk = 0;
    this.UD = p;
    this.IV = {};
    this.Kn = this.nq(1);
    this.og = this.nq(2);
    this.xl = this.nq(3);
    this.gg = this.nq(4);
    a.platform.appendChild(this.Kn);
    a.platform.appendChild(this.og);
    a.platform.appendChild(this.xl);
    a.platform.appendChild(this.gg);
    var b = 256 * Math.pow(2, 15);
    var c = 3 * b;
    var a = T.Wa(new J(180, 0)).lng;
    var c = c - a;
    var b = -3 * b;
    const e = T.Wa(new J(-180, 0)).lng;
    this.uA = a;
    this.vA = e;
    this.rA = c + (e - b);
    this.TH = a - e;
  }
  D.Ze((a) => {
    const b = new rd(a);
    b.ya();
    a.$e = b;
  });
  A.extend(rd.prototype, {
    ya() {
      const a = this;
      const b = a.map;
      b.addEventListener('loadcode', () => {
        a.ep();
      });
      b.addEventListener('addtilelayer', (b) => {
        a.Ne(b);
      });
      b.addEventListener('removetilelayer', (b) => {
        a.Yf(b);
      });
      b.addEventListener('setmaptype', (b) => {
        a.Gg(b);
      });
      b.addEventListener('zoomstartcode', (b) => {
        a.Lc(b);
      });
      b.addEventListener('setcustomstyles', (b) => {
        a.Bt(b.target);
        a.Wf(p);
      });
      b.addEventListener('initindoorlayer', (b) => {
        a.PD(b);
      });
    },
    ep() {
      const a = this;
      if (A.fa.na) {
        try {
          document.execCommand('BackgroundImageCache', t, p);
        } catch (b) {}
      }
      this.loaded || a.px();
      a.Wf();
      this.loaded || (this.loaded = p,
      Ta.load('tile', () => {
        a.GP();
      }));
    },
    PD(a) {
      this.au = new sd(this);
      this.au.Ne(new td(this.map, this.au, a.We));
    },
    px() {
      for (let a = this.map.wa().df, b = 0; b < a.length; b++) {
        const c = new ud();
        A.extend(c, a[b]);
        this.tj.push(c);
        c.ya(this.map, this.Kn);
      }
      this.Bt();
    },
    nq(a) {
      const b = L('div');
      b.style.position = 'absolute';
      b.style.overflow = 'visible';
      b.style.left = b.style.top = '0';
      b.style.zIndex = a;
      return b;
    },
    zf() {
      this.Dk--;
      const a = this;
      this.UD && (this.map.dispatchEvent(new P('onfirsttileloaded')),
      this.UD = t);
      this.Dk == 0 && (this.Ii && (clearTimeout(this.Ii),
      this.Ii = q),
      this.Ii = setTimeout(() => {
        if (a.Dk == 0) {
          a.map.dispatchEvent(new P('ontilesloaded'));
          a.UD = p;
        }
        a.Ii = q;
      }, 80));
    },
    AD(a, b) {
      return `TILE-${b.ca}-${a[0]}-${a[1]}-${a[2]}`;
    },
    lx(a) {
      const b = a.Gb;
      b && Cb(b) && b.parentNode.removeChild(b);
      delete this.Ag[a.name];
      a.loaded || (vd(a),
      a.Gb = q,
      a.ym = q);
    },
    qL(a, b, c) {
      let e = this.map;
      var f = e.wa();
      const g = e.Xa;
      let i = e.Tb;
      let k = f.Xb(g);
      var m = this.VW();
      let n = m[0];
      let o = m[1];
      let s = m[2];
      let v = m[3];
      let w = m[4];
      var c = typeof c !== 'undefined' ? c : 0;
      var f = f.Id();
      var m = e.ca.replace(/^TANGRAM_/, '');
      for (this.Ce ? this.Ce.length = 0 : this.Ce = []; n < s; n++) {
        for (var y = o; y < v; y++) {
          var z = n;
          const B = y;
          this.Ce.push([z, B]);
          z = `${m}_${b}_${z}_${B}_${g}`;
          this.IV[z] = z;
        }
      }
      this.Ce.sort(function (a) {
        return function (b, c) {
          return 0.4 * Math.abs(b[0] - a[0]) + 0.6 * Math.abs(b[1] - a[1]) - (0.4 * Math.abs(c[0] - a[0]) + 0.6 * Math.abs(c[1] - a[1]));
        };
      }([w[0] - 1, w[1] - 1]));
      i = [Math.round(-i.lng / k), Math.round(i.lat / k)];
      n = -e.offsetY + e.height / 2;
      a.style.left = `${-e.offsetX + e.width / 2}px`;
      a.style.top = `${n}px`;
      this.Oe ? this.Oe.length = 0 : this.Oe = [];
      n = 0;
      for (e = a.childNodes.length; n < e; n++) {
        y = a.childNodes[n],
        y.Lq = t,
        this.Oe.push(y);
      }
      if (n = this.Bm) for (var C in n) delete n[C];
      else this.Bm = {};
      this.Pe ? this.Pe.length = 0 : this.Pe = [];
      n = 0;
      for (e = this.Ce.length; n < e; n++) {
        C = this.Ce[n][0];
        k = this.Ce[n][1];
        y = 0;
        for (o = this.Oe.length; y < o; y++) {
          if (s = this.Oe[y],
          s.id == `${m}_${b}_${C}_${k}_${g}`) {
            s.Lq = p;
            this.Bm[s.id] = s;
            break;
          }
        }
      }
      n = 0;
      for (e = this.Oe.length; n < e; n++) {
        s = this.Oe[n],
        s.Lq || this.Pe.push(s);
      }
      this.pF = [];
      y = (f + c) * this.map.M.devicePixelRatio;
      n = 0;
      for (e = this.Ce.length; n < e; n++) {
        C = this.Ce[n][0],
        k = this.Ce[n][1],
        v = C * f + i[0] - c / 2,
        w = (-1 - k) * f + i[1] - c / 2,
        z = `${m}_${b}_${C}_${k}_${g}`,
        o = this.Bm[z],
        s = q,
        o ? (s = o.style,
        s.left = `${v}px`,
        s.top = `${w}px`,
        o.yn || this.pF.push([C, k, o])) : (this.Pe.length > 0 ? (o = this.Pe.shift(),
        o.getContext('2d').clearRect(-c / 2, -c / 2, y, y),
        s = o.style) : (o = document.createElement('canvas'),
        s = o.style,
        s.position = 'absolute',
        s.width = `${f + c}px`,
        s.height = `${f + c}px`,
        this.DY() && (s.WebkitTransform = 'scale(1.001)'),
        o.setAttribute('width', y),
        o.setAttribute('height', y),
        a.appendChild(o)),
        o.id = z,
        s.left = `${v}px`,
        s.top = `${w}px`,
        z.indexOf('bg') > -1 && (v = '#F3F1EC',
        this.map.M.DU && (v = this.map.M.DU),
        s.background = v || ''),
        this.pF.push([C, k, o])),
        o.style.visibility = '';
      }
      n = 0;
      for (e = this.Pe.length; n < e; n++) this.Pe[n].style.visibility = 'hidden';
      return this.pF;
    },
    DY() {
      return /M040/i.test(navigator.userAgent);
    },
    VW() {
      const a = this.map;
      var b = a.wa();
      var c = b.vL(a.Xa);
      const e = a.Tb;
      const f = Math.ceil(e.lng / c);
      const g = Math.ceil(e.lat / c);
      var b = b.Id();
      var c = [f, g, (e.lng - f * c) / c * b, (e.lat - g * c) / c * b];
      return [c[0] - Math.ceil((a.width / 2 - c[2]) / b), c[1] - Math.ceil((a.height / 2 - c[3]) / b), c[0] + Math.ceil((a.width / 2 + c[2]) / b), c[1] + Math.ceil((a.height / 2 + c[3]) / b), c];
    },
    E_(a, b, c, e) {
      const f = this;
      f.p2 = b;
      let g = this.map.wa();
      const i = f.AD(a, c);
      const k = g.Id();
      var b = [a[0] * k + b[0], (-1 - a[1]) * k + b[1]];
      let m = this.Ag[i];
      if (this.map.wa() !== ab && this.map.wa() !== Sa) {
        const n = this.gw(a[0], a[2]).offsetX;
        b[0] += n;
        b.H1 = n;
      }
      m && m.Gb ? (Ab(m.Gb, b),
      e && (e = new R(a[0], a[1]),
      g = this.map.M.xe ? this.map.M.xe.style : 'normal',
      e = c.getTilesUrl(e, a[2], g),
      m.loaded = t,
      wd(m, e)),
      m.loaded ? this.zf() : xd(m, () => {
        f.zf();
      })) : (m = this.Zi[i]) && m.Gb ? (c.Ib.insertBefore(m.Gb, c.Ib.lastChild),
      this.Ag[i] = m,
      Ab(m.Gb, b),
      e && (e = new R(a[0], a[1]),
      g = this.map.M.xe ? this.map.M.xe.style : 'normal',
      e = c.getTilesUrl(e, a[2], g),
      m.loaded = t,
      wd(m, e)),
      m.loaded ? this.zf() : xd(m, () => {
        f.zf();
      })) : (m = k * Math.pow(2, g.Te() - a[2]),
      new J(a[0] * m, a[1] * m),
      e = new R(a[0], a[1]),
      g = this.map.M.xe ? this.map.M.xe.style : 'normal',
      e = c.getTilesUrl(e, a[2], g),
      m = new yd(this, e, b, a, c),
      xd(m, () => {
        f.zf();
      }),
      m.Jn(),
      this.Ag[i] = m);
    },
    zf() {
      this.Dk--;
      const a = this;
      this.Dk == 0 && (this.Ii && (clearTimeout(this.Ii),
      this.Ii = q),
      this.Ii = setTimeout(() => {
        if (a.Dk == 0) {
          a.map.dispatchEvent(new P('ontilesloaded'));
          if (va) {
            if (qa && ra && ua) {
              const b = eb();
              const c = a.map.xb();
              setTimeout(() => {
                Ra(5030, {
                  load_script_time: ra - qa,
                  load_tiles_time: b - ua,
                  map_width: c.width,
                  map_height: c.height,
                  map_size: c.width * c.height,
                });
              }, 1E4);
              D.aq('cus.fire', 'time', {
                z_imgfirstloaded: b - ua,
              });
            }
            va = t;
          }
        }
        a.Ii = q;
      }, 80));
    },
    AD(a, b) {
      return this.map.wa() === Qa ? `TILE-${b.ca}-${this.map.nw}-${a[0]}-${a[1]}-${a[2]}` : `TILE-${b.ca}-${a[0]}-${a[1]}-${a[2]}`;
    },
    lx(a) {
      const b = a.Gb;
      b && (zd(b),
      Cb(b) && b.parentNode.removeChild(b));
      delete this.Ag[a.name];
      a.loaded || (zd(b),
      vd(a),
      a.Gb = q,
      a.ym = q);
    },
    gw(a, b) {
      for (var c = 0, e = 6 * Math.pow(2, b - 3), f = e / 2 - 1, g = -e / 2; a > f;) {
        a -= e,
        c -= this.rA;
      }
      for (; a < g;) {
        a += e,
        c += this.rA;
      }
      c = Math.round(c / Math.pow(2, 18 - b));
      return {
        offsetX: c,
        Zl: a,
      };
    },
    YU(a) {
      for (var b = a.lng; b > this.uA;) b -= this.TH;
      for (; b < this.vA;) b += this.TH;
      a.lng = b;
      return a;
    },
    ZU(a, b) {
      for (var c = 256 * Math.pow(2, 18 - b), e = Math.floor(this.uA / c), f = Math.floor(this.vA / c), c = Math.floor(this.rA / c), g = [], i = 0; i < a.length; i++) {
        var k = a[i];
        var m = k[0];
        var k = k[1];
        if (m >= e) {
          var m = m + c;
          var n = `id_${m}_${k}_${b}`;
          a[n] || (a[n] = p,
          g.push([m, k]));
        } else {
          m <= f && (m -= c,
          n = `id_${m}_${k}_${b}`,
          a[n] || (a[n] = p,
          g.push([m, k])));
        }
      }
      for (i = 0; i < g.length; i++) a.push(g[i]);
      return a;
    },
    Wf(a) {
      if (!this.map.M.sg) {
        const b = this;
        if (b.map.wa() == Qa) {
          Ta.load('coordtrans', () => {
            b.map.Lb || (b.map.Lb = Qa.sk(b.map.bh),
            b.map.nw = Qa.TK(b.map.Lb));
            b.VH();
          }, p);
        } else {
          if (a && a) for (const c in this.Zi) delete this.Zi[c];
          b.VH(a);
        }
      }
    },
    VH(a) {
      const b = this.tj.concat(this.Zf);
      const c = b.length;
      let e = this.map;
      let f = e.wa();
      var g = e.Tb;
      var i = e.width;
      var i = e.wa().Xb(e.Xa) * i;
      var i = this.tY(g.lng - i / 2, g.lng + i / 2);
      this.map.wa() !== ab && this.map.wa() !== Sa && (g = this.YU(g));
      for (let k = 0; k < c; k++) {
        const m = b[k];
        if (m.fc && e.Xa < m.fc) break;
        if (m.fw) {
          var n = this.Ib = m.Ib;
          if (a) {
            var o = n;
            if (o && o.childNodes) {
              for (var s = o.childNodes.length, v = s - 1; v >= 0; v--) {
                s = o.childNodes[v],
                o.removeChild(s),
                s = q;
              }
            }
          }
          if (this.map.Od()) {
            this.og.style.display = 'block';
            n.style.display = 'none';
            this.map.dispatchEvent(new P('vectorchanged'), {
              isvector: p,
            });
            continue;
          } else {
            n.style.display = 'block',
            this.og.style.display = 'none',
            this.map.dispatchEvent(new P('vectorchanged'), {
              isvector: t,
            });
          }
        }
        if (!m.G1 && !(m.vx && !this.map.Od() || m.VL && this.map.Od())) {
          e = this.map;
          f = e.wa();
          n = f.jj();
          s = e.Xa;
          g = e.Tb;
          f == Qa && g.Sb(new J(0, 0)) && (g = e.Tb = n.ii(e.be, e.Lb));
          var w = f.Xb(s);
          var n = f.vL(s);
          var o = Math.ceil(g.lng / n);
          var y = Math.ceil(g.lat / n);
          var z = f.Id();
          var n = [o, y, (g.lng - o * n) / n * z, (g.lat - y * n) / n * z];
          var y = i ? 1.5 * (e.width / 2) : e.width / 2;
          var v = n[0] - Math.ceil((y - n[2]) / z);
          var o = n[1] - Math.ceil((e.height / 2 - n[3]) / z);
          var y = n[0] + Math.ceil((y + n[2]) / z);
          var B = 0;
          f === Qa && e.ja() == 15 && (B = 1);
          f = n[1] + Math.ceil((e.height / 2 + n[3]) / z) + B;
          this.zJ = new J(g.lng, g.lat);
          let C = this.Ag; var z = -this.zJ.lng / w; var B = this.zJ.lat / w; var g = [Math.ceil(z), Math.ceil(B)]; var w = e.ja(); var
            E;
          for (E in C) {
            var F = C[E];
            const G = F.info;
            (G[2] != w || G[2] == w && (v > G[0] || y <= G[0] || o > G[1] || f <= G[1])) && this.lx(F);
          }
          C = -e.offsetX + e.width / 2;
          F = -e.offsetY + e.height / 2;
          m.Ib && (m.Ib.style.left = `${Math.ceil(z + C) - g[0]}px`,
          m.Ib.style.top = `${Math.ceil(B + F) - g[1]}px`,
          m.Ib.style.WebkitTransform = 'translate3d(0,0,0)');
          z = [];
          for (e.qB = []; v < y; v++) {
            for (B = o; B < f; B++) {
              z.push([v, B]),
              e.qB.push({
                x: v,
                y: B,
              });
            }
          }
          this.map.wa() !== ab && this.map.wa() !== Sa && (z = this.ZU(z, s));
          z.sort(function (a) {
            return function (b, c) {
              return 0.4 * Math.abs(b[0] - a[0]) + 0.6 * Math.abs(b[1] - a[1]) - (0.4 * Math.abs(c[0] - a[0]) + 0.6 * Math.abs(c[1] - a[1]));
            };
          }([n[0] - 1, n[1] - 1]));
          s = z.length;
          this.Dk += s;
          for (v = 0; v < s; v++) this.E_([z[v][0], z[v][1], w], g, m, a);
        }
      }
    },
    tY(a, b) {
      return a < this.vA || b > this.uA;
    },
    Ne(a) {
      const b = this;
      const c = a.target;
      b.map.Od();
      c.Wm && this.map.Ne(c.Wm);
      if (c.vx) {
        for (a = 0; a < b.Hg.length; a++) if (b.Hg[a] == c) return;
        Ta.load('vector', () => {
          c.ya(b.map, b.og);
          b.Hg.push(c);
        }, p);
      } else {
        for (a = 0; a < b.Zf.length; a++) if (b.Zf[a] == c) return;
        c.ya(this.map, this.xl);
        b.Zf.push(c);
      }
    },
    Yf(a) {
      a = a.target;
      this.map.Od();
      a.Wm && this.map.Yf(a.Wm);
      if (a.vx) for (var b = 0, c = this.Hg.length; b < c; b++) a == this.Hg[b] && this.Hg.splice(b, 1);
      else {
        b = 0;
        for (c = this.Zf.length; b < c; b++) a == this.Zf[b] && this.Zf.splice(b, 1);
      }
      a.remove();
    },
    Gg() {
      for (let a = this.tj, b = 0, c = a.length; b < c; b++) a[b].remove();
      delete this.Ib;
      this.tj = [];
      this.Zi = this.Ag = {};
      this.px();
      this.Wf();
    },
    Lc() {
      const a = this;
      a.xd && A.U.$(a.xd);
      setTimeout(() => {
        a.Wf();
        a.map.dispatchEvent(new P('onzoomend'));
      }, 10);
    },
    b6: u(),
    Bt(a) {
      const b = this.map.wa();
      if (!this.map.Od() && (a ? this.map.M.N_ = a : a = this.map.M.N_,
      a)) {
        for (var c = q, c = D.$t == '2' ? [`${D.url.proto + D.url.domain.main_domain_cdn.other[0]}/`] : [`${D.url.proto + D.url.domain.main_domain_cdn.baidu[0]}/`, `${D.url.proto + D.url.domain.main_domain_cdn.baidu[1]}/`, `${D.url.proto + D.url.domain.main_domain_cdn.baidu[2]}/`], e = 0, f; f = this.tj[e]; e++) {
          if (f.z_ == p) {
            b.m.mc = 18;
            f.getTilesUrl = function (b, e) {
              var f = b.x;
              var f = this.map.$e.gw(f, e).Zl;
              const m = b.y;
              let n = Tb('normal');
              let o = 1;
              this.map.mx() && (o = 2);
              n = `customimage/tile?&x=${f}&y=${m}&z=${e}&udt=${n}&scale=${o}&ak=${pa}`;
              n = a.styleStr ? `${n}&styles=${encodeURIComponent(a.styleStr)}` : `${n}&customid=${a.style}`;
              return c[Math.abs(f + m) % c.length] + n;
            };
            break;
          }
        }
      }
    },
  });
  function yd(a, b, c, e, f) {
    this.ym = a;
    this.position = c;
    this.Bu = [];
    this.name = a.AD(e, f);
    this.info = e;
    this.$I = f.Vs();
    e = L('img');
    Bb(e);
    e.MK = t;
    const g = e.style;
    var a = a.map.wa();
    g.position = 'absolute';
    g.border = 'none';
    g.width = `${a.Id()}px`;
    g.height = `${a.Id()}px`;
    g.left = `${c[0]}px`;
    g.top = `${c[1]}px`;
    g.maxWidth = 'none';
    this.Gb = e;
    this.src = b;
    Ad && (this.Gb.style.opacity = 0);
    const i = this;
    this.Gb.onload = function () {
      D.LY.tQ();
      i.loaded = p;
      if (i.ym) {
        const a = i.ym;
        const b = a.Zi;
        if (!b[i.name]) {
          a.EE++;
          b[i.name] = i;
        }
        if (i.Gb && !Cb(i.Gb) && f.Ib) {
          f.Ib.appendChild(i.Gb);
          if (A.fa.na <= 6 && A.fa.na > 0 && i.$I) i.Gb.style.cssText = `${i.Gb.style.cssText};filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="${i.src}",sizingMethod=scale);`;
        }
        let c = a.EE - a.UU; let
          e;
        for (e in b) {
          if (c <= 0) break;
          if (!a.Ag[e]) {
            b[e].ym = q;
            let g = b[e].Gb;
            if (g && g.parentNode) {
              g.parentNode.removeChild(g);
              zd(g);
            }
            g = q;
            b[e].Gb = q;
            delete b[e];
            a.EE--;
            c--;
          }
        }
        Ad && new wb({
          Ic: 20,
          duration: 200,
          za(a) {
            if (i.Gb && i.Gb.style) i.Gb.style.opacity = a * 1;
          },
          finish() {
            i.Gb && i.Gb.style && delete i.Gb.style.opacity;
          },
        });
        vd(i);
      }
    };
    this.Gb.onerror = function () {
      vd(i);
      if (i.ym) {
        const a = i.ym.map.wa();
        if (a.m.PC) {
          i.error = p;
          i.Gb.src = a.m.PC;
          i.Gb && !Cb(i.Gb) && f.Ib.appendChild(i.Gb);
        }
      }
    };
    e = q;
  }
  function xd(a, b) {
    a.Bu.push(b);
  }
  yd.prototype.Jn = function () {
    this.Gb.src = A.fa.na > 0 && A.fa.na <= 6 && this.$I ? `${H.sa}blank.gif` : this.src !== '' && this.Gb.src == this.src ? `${this.src}&t = ${Date.now()}` : this.src;
  };
  function vd(a) {
    for (let b = 0; b < a.Bu.length; b++) a.Bu[b]();
    a.Bu.length = 0;
  }
  function zd(a) {
    if (a) {
      a.onload = a.onerror = q;
      let b = a.attributes; let c; let e; let
        f;
      if (b) {
        e = b.length;
        for (c = 0; c < e; c += 1) {
          f = b[c].name,
          $a(a[f]) && (a[f] = q);
        }
      }
      if (b = a.children) {
        e = b.length;
        for (c = 0; c < e; c += 1) zd(a.children[c]);
      }
    }
  }
  function wd(a, b) {
    a.src = b;
    a.Jn();
  }
  var Ad = !A.fa.na || A.fa.na > 8;
  function ud(a) {
    this.We = a || {};
    this.uV = this.We.copyright || q;
    this.n0 = this.We.transparentPng || t;
    this.fw = this.We.baseLayer || t;
    this.zIndex = this.We.zIndex || 0;
    this.ca = ud.aS++;
  }
  ud.aS = 0;
  A.lang.xa(ud, A.lang.Ha, 'TileLayer');
  A.extend(ud.prototype, {
    ya(a, b) {
      this.fw && (this.zIndex = -100);
      this.map = a;
      if (!this.Ib) {
        const c = L('div');
        const e = c.style;
        e.position = 'absolute';
        e.overflow = 'visible';
        e.zIndex = this.zIndex;
        e.left = `${Math.ceil(-a.offsetX + a.width / 2)}px`;
        e.top = `${Math.ceil(-a.offsetY + a.height / 2)}px`;
        b.appendChild(c);
        this.Ib = c;
      }
    },
    remove() {
      this.Ib && this.Ib.parentNode && (this.Ib.innerHTML = '',
      this.Ib.parentNode.removeChild(this.Ib));
      delete this.Ib;
    },
    Vs: x('n0'),
    getTilesUrl(a, b) {
      if (this.map.wa() !== ab && this.map.wa() !== Sa) var c = this.map.$e.gw(a.x, b).Zl;
      let e = '';
      this.We.tileUrlTemplate && (e = this.We.tileUrlTemplate.replace(/\{X\}/, c),
      e = e.replace(/\{Y\}/, a.y),
      e = e.replace(/\{Z\}/, b));
      return e;
    },
    im: x('uV'),
    wa() {
      return this.Sa || Na;
    },
  });
  function Bd(a) {
    ud.call(this, a);
    this.m = a || {};
    this.VL = p;
    if (this.m.predictDate) {
      if (this.m.predictDate.weekday < 1 || this.m.predictDate.weekday > 7) this.m.predictDate = 1;
      if (this.m.predictDate.hour < 0 || this.m.predictDate.hour > 23) this.m.predictDate.hour = 0;
    }
    this.cU = `${D.url.proto + D.url.domain.traffic}/traffic/`;
  }
  Bd.prototype = new ud();
  Bd.prototype.ya = function (a, b) {
    ud.prototype.ya.call(this, a, b);
    this.P = a;
  };
  Bd.prototype.Vs = da(p);
  Bd.prototype.getTilesUrl = function (a, b) {
    var c = '';
    this.m.predictDate ? c = `HistoryService?day=${this.m.predictDate.weekday - 1}&hour=${this.m.predictDate.hour}&t=${(new Date()).getTime()}&` : (c = `TrafficTileService?time=${(new Date()).getTime()}&`,
    c += 'label=web2D&v=016&');
    var c = `${this.cU + c}level=${b}&x=${a.x}&y=${a.y}`;
    let e = 1;
    this.P.mx() && (e = 2);
    return (`${c}&scaler=${e}`).replace(/-(\d+)/gi, 'M$1');
  };
  const Cd = [`${D.url.proto + D.url.domain.TILES_YUN_HOST[0]}/georender/gss`, `${D.url.proto + D.url.domain.TILES_YUN_HOST[1]}/georender/gss`, `${D.url.proto + D.url.domain.TILES_YUN_HOST[2]}/georender/gss`, `${D.url.proto + D.url.domain.TILES_YUN_HOST[3]}/georender/gss`];
  const Dd = `${D.url.proto + D.url.domain.main_domain_nocdn.baidu}/style/poi/rangestyle`;
  const Ed = 100;
  function qb(a, b) {
    ud.call(this);
    const c = this;
    this.VL = p;
    try {
      document.createElement('canvas').getContext('2d');
    } catch (e) {}
    Kb(a) ? b = a || {} : (c.xn = a,
    b = b || {});
    b.geotableId && (c.Bf = b.geotableId);
    b.databoxId && (c.xn = b.databoxId);
    const f = `${D.nd}geosearch`;
    c.cb = {
      dN: b.pointDensity || Ed,
      ZX: `${f}/detail/`,
      $X: `${f}/v2/detail/`,
      wJ: b.age || 36E5,
      ut: b.q || '',
      Y_: 'png',
      Z3: [5, 5, 5, 5],
      HY: {
        backgroundColor: '#FFFFD5',
        borderColor: '#808080',
      },
      DB: b.ak || pa,
      cO: b.tags || '',
      filter: b.filter || '',
      UN: b.sortby || '',
      GD: b.hotspotName || `tile_md_${(1E5 * Math.random()).toFixed(0)}`,
      zF: p,
    };
    Ta.load('clayer', () => {
      c.Rd();
    });
  }
  qb.prototype = new ud();
  qb.prototype.ya = function (a, b) {
    ud.prototype.ya.call(this, a, b);
    this.P = a;
  };
  qb.prototype.getTilesUrl = function (a, b) {
    var c = a.x;
    const e = a.y;
    let f = this.cb;
    var c = `${Cd[Math.abs(c + e) % Cd.length]}/image?grids=${c}_${e}_${b}&q=${f.ut}&tags=${f.cO}&filter=${f.filter}&sortby=${f.UN}&ak=${this.cb.DB}&age=${f.wJ}&page_size=${f.dN}&format=${f.Y_}`;
    f.zF || (f = (1E5 * Math.random()).toFixed(0),
    c += `&timeStamp=${f}`);
    this.Bf ? c += `&geotable_id=${this.Bf}` : this.xn && (c += `&databox_id=${this.xn}`);
    return c;
  };
  qb.prototype.enableUseCache = function () {
    this.cb.zF = p;
  };
  qb.prototype.disableUseCache = function () {
    this.cb.zF = t;
  };
  qb.BT = /^point\(|\)$/ig;
  qb.CT = /\s+/;
  qb.ET = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
  const Fd = {};
  function Gd(a, b) {
    this.hd = a;
    this.JP = 18;
    this.m = {
      vy: 256,
      Bc: new T(),
    };
    A.extend(this.m, b || {});
  }
  const Hd = [0, 0, 0, 8, 7, 7, 6, 6, 5, 5, 4, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0];
  const Id = [512, 2048, 4096, 32768, 65536, 262144, 1048576, 4194304, 8388608];
  const Jd = [0, 0, 0, 3, 5, 5, 7, 7, 9, 9, 10, 12, 12, 12, 15, 15, 17, 17, 19, 19, 19, 19];
  const Kd = [0, 0, 0, 256, 256, 512, 256, 512, 256, 512, 256, 256, 512, 1024, 256, 512, 512, 1024, 512, 1024, 2048, 4096];
  Gd.prototype = {
    getName: x('hd'),
    Id(a) {
      return this.hd === 'na' ? Kd[a] : this.m.vy;
    },
    vs(a) {
      return this.hd === 'na' ? Jd[a] : a;
    },
    jj() {
      return this.m.Bc;
    },
    Xb(a) {
      return Math.pow(2, this.JP - a);
    },
    rD(a) {
      return this.hd === 'na' ? Id[Hd[a]] : this.Xb(a) * this.Id(a);
    },
  };
  const Ld = {
    drawPoly(a, b, c, e, f, g) {
      const i = a[1];
      if (i) {
        for (var a = a[6], k = 0; k < i.length; k++) {
          const m = i[k][0];
          const n = f.nj(m, 'polygon', c, g);
          if (n && n.length) {
            for (let o = i[k][1], s = 0; s < o.length; s++) {
              let v = o[s][1];
              f.Oc(v[0], c) && (v[`cache${c}`] || (v[`cache${c}`] = f.Dm(v[1], c, e, a)),
              v = v[`cache${c}`],
              f.P.io(b.canvas.id, v, {
                type: 'polygon',
                Vb: m,
                style: n,
              }),
              this.kW(b, v, n, c));
            }
          }
        }
      }
    },
    kW(a, b, c, e) {
      c = c[0];
      if (!c.Vb || !(e > 6 && (c.Vb === 71013 || c.Vb === 71012 || c.Vb === 71011) || e === 6 && (c.Vb === 71011 || c.Vb === 71012) || e === 5 && (c.Vb === 71011 || c.Vb === 71013) || e < 5 && (c.Vb === 71012 || c.Vb === 71013))) {
        a.fillStyle = c.Mw;
        a.beginPath();
        a.moveTo(b[0], b[1]);
        for (var e = 2, f = b.length; e < f; e += 2) a.lineTo(b[e], b[e + 1]);
        a.closePath();
        c.borderWidth && (a.strokeStyle = c.ro,
        a.lineWidth = c.borderWidth / 2,
        a.stroke());
        a.fill();
      }
    },
    drawGaoqingRoadBorder(a, b, c, e, f) {
      const g = a[1];
      if (g) {
        for (var a = a[6], i = 0; i < g.length; i++) {
          const k = g[i][0];
          const m = f.nj(k, 'polygon', c);
          if (m && m.length && m[0].borderWidth) {
            for (let n = g[i][1], o = 0; o < n.length; o++) {
              let s = n[o][1];
              f.Oc(s[0], c) && (s[`cache${c}`] || (s[`cache${c}`] = f.Dm(s[1], c, e, a)),
              s = s[`cache${c}`],
              f.P.io(b.canvas.id, s, {
                type: 'polygon',
                Vb: k,
                style: m,
              }),
              this.mW(b, s, m));
            }
          }
        }
      }
    },
    drawGaoqingRoadFill(a, b, c, e, f) {
      const g = a[1];
      if (g) {
        for (var a = a[6], i = 0; i < g.length; i++) {
          const k = g[i][0];
          const m = f.nj(k, 'polygon', c);
          if (m && m.length) {
            for (let n = g[i][1], o = 0; o < n.length; o++) {
              let s = n[o][1];
              f.Oc(s[0], c) && (s[`cache${c}`] || (s[`cache${c}`] = f.Dm(s[1], c, e, a)),
              s = s[`cache${c}`],
              f.P.io(b.canvas.id, s, {
                type: 'polygon',
                Vb: k,
                style: m,
              }),
              this.nW(b, s, m));
            }
          }
        }
      }
    },
    mW(a, b, c) {
      c = c[0];
      a.beginPath();
      a.moveTo(b[0], b[1]);
      for (let e = 2, f = b.length; e < f; e += 2) a.lineTo(b[e], b[e + 1]);
      a.closePath();
      a.strokeStyle = c.ro;
      a.lineWidth = c.borderWidth / 2;
      a.stroke();
    },
    nW(a, b, c) {
      a.fillStyle = c[0].Mw;
      a.beginPath();
      a.moveTo(b[0], b[1]);
      for (var c = 2, e = b.length; c < e; c += 2) a.lineTo(b[c], b[c + 1]);
      a.closePath();
      a.fill();
    },
  };
  const Md = {
    drawArrow(a, b, c, e, f, g) {
      b.lineWidth = 1.5;
      b.lineCap = 'butt';
      b.lineJoin = 'miter';
      b.strokeStyle = 'rgba(153,153,153,1)';
      let i = a[7];
      if (i) {
        a = i[1];
        e = g.Dm(i[0], c, e);
        for (i = 0; i < a.length; i++) {
          if (g.Oc(a[i], c)) {
            var k = e[4 * i];
            var m = e[4 * i + 1];
            var n = e[4 * i + 2];
            var o = e[4 * i + 3];
            const s = (k + n) / 2;
            const v = (m + o) / 2;
            var n = (k - n) / f;
            var o = (m - o) / f;
            var k = s + n / 2;
            var n = s - n / 2;
            var m = v + o / 2;
            var o = v - o / 2;
            this.dW(b, k, m, n, o);
          }
        }
      }
    },
    dW(a, b, c, e, f) {
      a.beginPath();
      a.moveTo(b, c);
      a.lineTo(e, f);
      a.stroke();
      c = this.VU([b, c], [e, f]);
      b = c[0];
      c = c[1];
      a.beginPath();
      a.moveTo(b[0], b[1]);
      a.lineTo(c[0], c[1]);
      a.lineTo(e, f);
      a.closePath();
      a.stroke();
    },
    VU(a, b) {
      var c = b[0] - a[0];
      const e = b[1] - a[1];
      var f = 1.8 * Math.sqrt(c * c + e * e);
      const g = b[0] + 4.8410665352790705 * (c / f);
      var f = b[1] + 4.8410665352790705 * (e / f);
      var c = Math.atan2(e, c) + Math.PI;
      return [[g + 4.8410665352790705 * Math.cos(c - 0.3), f + 4.8410665352790705 * Math.sin(c - 0.3)], [g + 4.8410665352790705 * Math.cos(c + 0.3), f + 4.8410665352790705 * Math.sin(c + 0.3)]];
    },
  };
  const Nd = {
    drawHregion(a, b, c, e, f) {
      const g = a[1];
      if (g) {
        for (var a = a[6], i = 0; i < g.length; i++) {
          const k = g[i][0];
          const m = f.nj(k, 'polygon3d', c);
          if (m && m.length) {
            for (let n = g[i][1], o = 0; o < n.length; o++) {
              let s = n[o][2];
              if (f.Oc(s[0], c)) {
                const v = s[2];
                s[`cache${c}`] || (s[`cache${c}`] = f.Dm(s[1], c, e, a));
                s = s[`cache${c}`];
                f.P.io(b.canvas.id, s, {
                  type: 'polygon',
                  Vb: k,
                  style: m,
                });
                this.lW(b, s, v, m);
              }
            }
          }
        }
      }
    },
    lW(a, b, c, e) {
      e = e[0];
      if (!(c < e.filter)) {
        a.fillStyle = e.EW;
        a.beginPath();
        a.moveTo(b[0], b[1]);
        for (var c = 2, f = b.length; c < f; c += 2) a.lineTo(b[c], b[c + 1]);
        a.closePath();
        e.borderWidth && (a.strokeStyle = e.ro,
        a.lineWidth = e.borderWidth / 2,
        a.stroke());
        a.fill();
      }
    },
  };
  var Od = {
    parse(a, b, c, e, f) {
      for (var g = e.P, i = g.ja(), k = Math.pow(2, 18 - i), m = g.Bc.ii(g.Nb()), n = m.lng, o = m.lat, m = g.xb(), s = m.width, v = m.height, m = [], w = 0; w < a.length; w++) {
        const y = [];
        const z = a[w].W_;
        y.x = z[0];
        y.y = z[1];
        y.m6 = z[2];
        for (var B = (z[0] * c * k - n) / k + s / 2, C = (o - (z[1] + 1) * c * k) / k + v / 2, E = 0; E < a[w].length; E++) a[w][E].aM ? this.$M(a[w][E].aM, z, e, b, c, B, C, i, k, s, v, y) : a[w][E].fY ? this.$M(a[w][E].fY, z, e, b, c, B, C, i, k, s, v, y, p, window.d4) : this.rZ(a[w][E].IY, z, e, b, c, B, C, i, k, s, v, y, f);
        m.push(y);
      }
      if (/collision=0/.test(location.search)) {
        a = [];
        for (w = 0; w < m.length; w++) for (E = 0; E < m[w].length; E++) a.push(m[w][E]);
      } else a = this.EZ(m, e.P.ja());
      g.jV();
      for (w = 0; w < a.length; w++) {
        if (c = a[w],
        !c.Qs) {
          if (E = [c.Uf, c.Vf, c.Uf, c.mi, c.li, c.mi, c.li, c.Vf, c.Uf, c.Vf],
          c.style && g.io('poi', E, {
            type: 'polygon',
            Vb: c.style.Vb,
            style: c.style,
          }),
          c.type === 'fixed') {
            E = t;
            c.ve && (c.style && c.direction === 4) && (E = p);
            if (c.ve) {
              if (E) {
                var F = this;
                this.fs(b, c, e, E, (a) => {
                  for (let c = 0; c < a.vf.length; c++) F.uK(b, a.vf[c].ce, a.vf[c].de, a.vf[c].text, a.style, e);
                });
              } else this.fs(b, c, e);
            }
            if (c.style && !E) for (E = 0; E < c.vf.length; E++) this.uK(b, c.vf[E].ce, c.vf[E].de, c.vf[E].text, c.style, e);
          } else if (c.type === 'line') {
            for (E = 0; E < c.KO.length; E++) {
              f = c.KO[E],
              Od.gW(b, f.ce, f.de, f.yU, f.IO, f.width, f.height, c.style, e);
            }
          }
        }
      }
      return m;
    },
    $M(a, b, c, e, f, g, i, k, m, n, o, s, v, w) {
      if (a = a[1]) {
        for (b = 0; b < a.length; b++) {
          var y = a[b];
          var z = y[0];
          let B = c.nj(z, 'point', k, w);
          var z = c.nj(z, 'pointText', k, w);
          var y = y[1];
          let C = q;
          let E = 100;
          let F = 0;
          let G = 0;
          B && B[0] && (B = B[0],
          C = B.ve,
          E = B.zoom || 100);
          z = z && z[0] ? z[0] : q;
          for (B = 0; B < y.length; B++) {
            let K = y[B][4];
            if (K && c.Oc(K[2], k)) {
              const O = Math.round(K[0] / 100) / m + g;
              const M = f - Math.round(K[1] / 100) / m + i;
              if (v || !(O < -50 || M < -50 || O > n + 50 || M > o + 50)) {
                var S = K[7] || '';
                const ca = {
                  type: 'fixed',
                  uid: K[3] || '',
                  name: S,
                  Xx: K[4],
                  Ls: q,
                  vf: [],
                  Lx: [O, M],
                  style: z,
                };
                if (C) {
                  var Z = window.iconSetInfo_high[C] || window.iconSetInfo_high[`MapRes/${C}`];
                  if (!Z) {
                    var Aa = C.charCodeAt(0);
                    Aa >= 48 && Aa <= 57 && (Z = window.iconSetInfo_high[`_${C}`]);
                  }
                  Z && (F = Z[2],
                  G = Z[3],
                  F = F / 2 * E / 100,
                  G = G / 2 * E / 100,
                  ca.Ls = {
                    ce: O - F / 2,
                    de: M - G / 2,
                    width: F,
                    height: G,
                  },
                  ca.ve = C);
                }
                if (z) {
                  K = K[5];
                  typeof K !== 'number' && (K = 0);
                  let ta = Z = 0;
                  var Aa = (z.fontSize || 12) / 2;
                  const Ga = 0.2 * Aa;
                  e.font = Od.Rw(z, c);
                  var S = S.split('\\');
                  const sa = S.length;
                  ca.direction = K;
                  for (let Va = 0; Va < sa; Va++) {
                    const Fe = S[Va];
                    const Uc = e.measureText(Fe).width;
                    switch (K) {
                      case 3:
                        ta = M - Aa / 2 * sa - Ga * (sa - 1) / 2;
                        Z = O - Uc - F / 2;
                        ta = ta + Aa * Va + Ga * Va;
                        break;
                      case 1:
                        ta = M - Aa / 2 * sa - Ga * (sa - 1) / 2;
                        Z = O + F / 2;
                        ta = ta + Aa * Va + Ga * Va;
                        break;
                      case 2:
                        ta = M - G / 2 - Aa * sa - Ga * (sa - 1) - Ga;
                        Z = O - Uc / 2;
                        ta = ta + Aa * Va + Ga * Va;
                        break;
                      case 0:
                        ta = M + G / 2 + Ga / 2;
                        Z = O - Uc / 2;
                        ta = ta + Aa * Va + Ga * Va;
                        break;
                      case 4:
                        ta = M - Aa / 2 * sa - Ga * (sa - 1) / 2,
                        Z = O - Uc / 2,
                        ta = ta + Aa * Va + Ga * Va;
                    }
                    ca.vf.push({
                      ce: Z,
                      de: ta,
                      width: Uc,
                      height: Aa,
                      text: Fe,
                    });
                  }
                }
                s.push(ca);
              }
            }
          }
        }
      }
    },
    rZ(a, b, c, e, f, g, i, k, m, n, o, s, v) {
      b = a[7].length;
      if ((n = c.nj(a[0], 'pointText', k)) && n.length) {
        n = n[0];
        e.font = Od.Rw(n, c);
        for (var o = n.fontSize / 2, w = a[1], y = a[2], z = y.split('').length, B = a[4], C = B.slice(0, 2), E = 2; E < B.length; E += 2) {
          C[E] = C[E - 2] + B[E],
          C[E + 1] = C[E - 1] + B[E + 1];
        }
        for (E = 2; E < B.length; E += 2) {
          E % (2 * z) === 0 || E % (2 * z) === 1 || (C[E] = C[E - 2] + B[E] / v,
          C[E + 1] = C[E - 1] + B[E + 1] / v);
        }
        for (v = 0; v < b; v++) {
          if (c.Oc(a[7][v], k)) {
            var E = [];
            let F = l;
            let G = l;
            let K = l;
            let O = l;
            const M = y.split('');
            a[6][v] && M.reverse();
            for (var B = 2 * v * z, B = C.slice(B, B + 2 * z), S = 0; S < z; S++) {
              const ca = a[5][z * v + S];
              const Z = B[2 * S] / 100 / m + g;
              const Aa = f - B[2 * S + 1] / 100 / m + i;
              const ta = M[S];
              const Ga = e.measureText(ta).width;
              if (F === l) {
                F = Z - Ga / 2,
                G = Aa - o / 2,
                K = F + Ga,
                O = G + o;
              } else {
                const sa = Z - Ga / 2;
                const Va = Aa - o / 2;
                sa < F && (F = sa);
                Va < G && (G = Va);
                sa + Ga > K && (K = sa + Ga);
                Va + o > O && (O = Va + o);
              }
              E.push({
                IO: ta,
                ce: Z,
                de: Aa,
                yU: ca,
                width: Ga,
                height: o,
              });
            }
            s.push({
              type: 'line',
              Xx: w,
              style: n,
              KO: E,
              Uf: F,
              Vf: G,
              li: K,
              mi: O,
            });
          }
        }
      }
    },
    fs(a, b, c, e, f) {
      const g = b.ve;
      if (g !== 'lanche') {
        if (Od.nx[g]) this.rK(a, b, Od.nx[g], e, f);
        else if (c = c.$K(g)) {
          const i = new Image();
          i.setAttribute('crossOrigin', 'anonymous');
          const k = this;
          i.onload = function () {
            Od.nx[g] = this;
            k.rK(a, b, this, e, f);
            i.onload = q;
          };
          i.src = c;
        }
      }
    },
    rK(a, b, c, e, f) {
      const g = b.Ls;
      const i = g.ce;
      const k = g.de;
      let m = q;
      let n = q;
      let o = p;
      const s = b.style ? b.style.Vb : q;
      if (b.style && s === 62203) {
        for (let v = n = m = 0; v < b.vf.length; v++) {
          m < b.vf[v].width && (m = b.vf[v].width),
          n += 20;
        }
        m = Math.ceil(m) + 10;
      }
      e && s === 519 && (o = t);
      m !== q && n !== q ? this.jW(a, b, c, 8, m, n) : e && o ? (m = Math.ceil(b.vf[0].width) + 6,
      this.cW(a, b, c, 12, m, c.height / 2)) : a.drawImage(c, i, k, g.width, g.height);
      f && f(b);
    },
    jW(a, b, c, e, f, g) {
      const i = b.Lx[0] - f / 2;
      var b = b.Lx[1] - g / 2;
      navigator.userAgent.indexOf('iPhone') > 0 && (b += 1);
      const k = e / 2;
      a.drawImage(c, 0, 0, e, e, i, b, k, k);
      a.drawImage(c, e, 0, 1, e, i + k, b, f - 2 * k, k);
      a.drawImage(c, c.width - e, 0, e, e, i + f - k, b, k, k);
      a.drawImage(c, 0, e, e, 1, i, b + k, k, g - 2 * k);
      a.drawImage(c, e, e, 1, 1, i + k, b + k, f - 2 * k, g - 2 * k);
      a.drawImage(c, c.width - e, e, e, 1, i + f - k, b + k, k, g - 2 * k);
      a.drawImage(c, 0, c.height - e, e, e, i, b + g - k, k, k);
      a.drawImage(c, e, c.height - e, 1, e, i + k, b + g - k, f - 2 * k, k);
      a.drawImage(c, c.width - e, c.height - e, e, e, i + f - k, b + g - k, k, k);
    },
    cW(a, b, c, e, f, g) {
      const i = b.Lx[0] - f / 2;
      var b = b.Lx[1] - g / 2;
      var g = e / 2;
      a.drawImage(c, 0, 0, e, c.height, i, b, g, c.height / 2);
      a.drawImage(c, e, 0, 1, c.height, i + g, b, f - 2 * g, c.height / 2);
      a.drawImage(c, c.width - e, 0, e, c.height, i + f - g, b, g, c.height / 2);
    },
    gW(a, b, c, e, f, g, i, k, m) {
      a.font = Od.Rw(k, m);
      a.fillStyle = k.KK;
      g /= 2;
      i /= 2;
      a.save();
      a.translate(b, c);
      a.rotate(-e / 180 * Math.PI);
      k.fx > 0 && (a.lineWidth = k.fx,
      a.strokeStyle = k.AL,
      a.strokeText(f, -g, -i));
      a.fillText(f, -g, -i);
      a.restore();
    },
    uK(a, b, c, e, f, g) {
      a.font = Od.Rw(f, g);
      a.fillStyle = f.KK;
      f.fx > 0 && (a.lineWidth = f.fx,
      a.strokeStyle = f.AL,
      a.strokeText(e, b, c));
      a.fillText(e, b, c);
    },
    Rw(a, b) {
      const c = a.fontSize / 2;
      let e = 10 * a.fontWeight;
      return e = b.WD ? `${e} bold` + ` ${c}px` + ' arial, "PingFang SC", sans-serif' : `${e} ${c}px` + ' arial, sans-serif';
    },
    EZ(a, b) {
      const c = [];
      let e = 0;
      b === 5 && (e = 1);
      a.sort((a, b) => (a.x * a.y < b.x * b.y ? -1 : 1));
      for (var f = 0, g = a.length; f < g; f++) {
        for (var i = a[f], k = 0, m = i.length; k < m; k++) {
          const n = i[k];
          let o = l;
          let s = l;
          let v = l;
          let w = l;
          if (n.type === 'fixed') {
            let y = n.Ls;
            const z = n.vf;
            y && (o = y.ce,
            s = y.de,
            v = y.ce + y.width,
            w = y.de + y.height);
            for (y = 0; y < z.length; y++) {
              const B = z[y];
              o !== l ? (B.ce < o && (o = B.ce),
              B.de < s && (s = B.de),
              B.ce + B.width > v && (v = B.ce + B.width),
              B.de + B.height > w && (w = B.de + B.height)) : (o = B.ce,
              s = B.de,
              v = B.ce + B.width,
              w = B.de + B.height);
            }
          } else {
            n.type === 'line' ? (o = n.Uf,
            s = n.Vf,
            v = n.li,
            w = n.mi) : n.type === 'biaopai' && (w = n.a5,
            o = w.ce,
            s = w.de,
            v = w.ce + w.width,
            w = w.de + w.height);
          }
          o !== l && (n.Uf = o,
          n.Vf = s,
          n.li = v,
          n.mi = w,
          c.push(n));
        }
      }
      c.sort((a, b) => b.Xx - a.Xx || b.Uf - a.Uf || b.Vf - a.Vf);
      f = 0;
      for (g = c.length; f < g; f++) {
        m = c[f];
        m.Qs = t;
        m.CJ = [];
        for (k = f + 1; k < g; k++) {
          i = c[k],
          m.li - e < i.Uf || (m.Uf > i.li - e || m.mi - e < i.Vf || m.Vf > i.mi - e) || m.CJ.push(k);
        }
      }
      f = 0;
      for (g = c.length; f < g; f++) {
        if (k = c[f],
        k.Qs === t) {
          e = k.CJ;
          k = 0;
          for (m = e.length; k < m; k++) c[e[k]].Qs = p;
        }
      }
      return c;
    },
    nx: {},
  };
  const Pd = ['round', 'butt', 'square'];
  const Qd = ['miter', 'round', 'bevel'];
  const Rd = {
    daojiao: [{
      stroke: '#FF6600',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
    daojiao_bai: [{
      stroke: '#f5f3f0',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
    junhuoxian: [{
      stroke: '#DB7093',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
    lundu: [{
      stroke: '#5c91c5',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [10, 11],
    }],
    shengjie: [{
      stroke: '#737373',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [6, 3],
    }],
    weidingguojie: [{
      stroke: '#aea08a',
      Cb: 1,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
    weidingguojie_guowai: [{
      stroke: '#a29e96',
      Cb: 2,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
    weidingguojie_guonei: [{
      stroke: '#b5a37c',
      Cb: 2,
      Ab: 'round',
      Bb: 'round',
      td: [4, 3],
    }],
  };
  const Sd = {};
  function Td(a, b, c) {
    if (/^tielu|^MapRes\/tielu/.test(a)) {
      if (window[`${c}zoomFrontStyle`][b].bmapRailwayVisibility === 'off') return [];
      let e = '#ffffff';
      let f = '#949494';
      window[`${c}zoomFrontStyle`] && (window[`${c}zoomFrontStyle`][b] && window[`${c}zoomFrontStyle`][b].bmapRailwayStrokeColor) && (e = window[`${c}zoomFrontStyle`][b].bmapRailwayStrokeColor);
      window[`${c}zoomFrontStyle`] && (window[`${c}zoomFrontStyle`][b] && window[`${c}zoomFrontStyle`][b].bmapRailwayFillColor) && (f = window[`${c}zoomFrontStyle`][b].bmapRailwayFillColor);
      if (b >= 4 && b <= 9 || b >= 10 && b <= 16) {
        return [{
          stroke: e,
          Cb: 1.5,
          Ab: 'butt',
          Bb: 'round',
          td: [10, 11],
        }, {
          stroke: f,
          Cb: 2,
          Ab: 'round',
          Bb: 'round',
        }];
      }
      if (b >= 17 && b <= 18) {
        return [{
          stroke: e,
          Cb: 2.5,
          Ab: 'butt',
          Bb: 'round',
          td: [15, 16],
        }, {
          stroke: f,
          Cb: 5,
          Ab: 'round',
          Bb: 'round',
        }];
      }
      if (b >= 19 && b <= 20) {
        return [{
          stroke: e,
          Cb: 4.5,
          Ab: 'butt',
          Bb: 'round',
          td: [25, 26],
        }, {
          stroke: f,
          Cb: 5,
          Ab: 'round',
          Bb: 'round',
        }];
      }
    } else if (a.indexOf('ditie_zj') === 0 || a.indexOf('MapRes/ditie_zj') === 0) {
      if (b >= 12 && b <= 16) {
        return [{
          stroke: '#868686',
          Cb: 1,
          Ab: 'round',
          Bb: 'round',
          td: [7, 4],
        }];
      }
      if (b >= 17 && b <= 18 || b >= 19 && b <= 20) {
        return [{
          stroke: '#6e6e6e',
          Cb: 1,
          Ab: 'round',
          Bb: 'round',
          td: [7, 4],
        }];
      }
    } else if (/^tongdaomian|^MapRes\/tongdaomian/.test(a)) {
      if (b === 17) {
        return [{
          stroke: '#e5e5e5',
          Cb: 4,
          Ab: 'square',
          Bb: 'round',
        }, {
          stroke: '#a8a8a8',
          Cb: 6,
          Ab: 'square',
          Bb: 'round',
        }];
      }
      if (b === 18) {
        return [{
          stroke: '#e5e5e5',
          Cb: 6,
          Ab: 'square',
          Bb: 'round',
        }, {
          stroke: '#a8a8a8',
          Cb: 8,
          Ab: 'square',
          Bb: 'round',
        }];
      }
      if (b >= 19 && b <= 21) {
        return [{
          stroke: '#e5e5e5',
          Cb: 8,
          Ab: 'square',
          Bb: 'round',
        }, {
          stroke: '#a8a8a8',
          Cb: 10,
          Ab: 'square',
          Bb: 'round',
        }];
      }
    } else if (/^jietizhongduan|^dixiatongdaojieti|^MapRes\/jietizhongduan|^MapRes\/dixiatongdaojieti/.test(a)) {
      if (b === 17) {
        return [{
          stroke: '#e5e5e5',
          Cb: 4,
          Ab: 'butt',
          Bb: 'round',
          td: [2, 1],
        }, {
          stroke: '#bebebe',
          Cb: 6,
          Ab: 'butt',
          Bb: 'round',
        }];
      }
      if (b === 18) {
        return [{
          stroke: '#e5e5e5',
          Cb: 6,
          Ab: 'butt',
          Bb: 'round',
          td: [3, 1],
        }, {
          stroke: '#bebebe',
          Cb: 8,
          Ab: 'butt',
          Bb: 'round',
        }];
      }
      if (b >= 19 && b <= 21) {
        return [{
          stroke: '#e5e5e5',
          Cb: 8,
          Ab: 'butt',
          Bb: 'round',
          td: [4, 2],
        }, {
          stroke: '#bebebe',
          Cb: 10,
          Ab: 'butt',
          Bb: 'round',
        }];
      }
    } else if (/^guojietianqiao|^MapRes\/guojietianqiao/.test(a)) {
      return b === 18 ? [{
        stroke: '#ffffff',
        Cb: 6,
        Ab: 'butt',
        Bb: 'round',
        td: [4, 2],
      }, {
        stroke: '#bebebe',
        Cb: 8,
        Ab: 'butt',
        Bb: 'round',
      }] : [{
        stroke: '#ffffff',
        Cb: 8,
        Ab: 'butt',
        Bb: 'round',
        td: [4, 2],
      }, {
        stroke: '#bebebe',
        Cb: 10,
        Ab: 'butt',
        Bb: 'round',
      }];
    }
    return Rd[a] || Rd[a.replace('MapRes/', '')];
  }
  const Ud = {
    drawLink(a, b, c, e, f) {
      this.ca = f.P.ca;
      const g = a[1];
      g && (a = a[6],
      this.sO(g, c, e, b, a, f, p),
      this.sO(g, c, e, b, a, f, t));
    },
    sO(a, b, c, e, f, g, i) {
      for (let k = 0; k < a.length; k++) {
        const m = a[k][0];
        const n = g.nj(m, 'line', b);
        if (n && n.length && (!i || n[0].borderWidth)) {
          if (!n[0].Jo || Td(n[0].Jo, b, this.ca)) {
            for (let o = a[k][1], s = 0; s < o.length; s++) {
              let v = o[s][3];
              g.Oc(v[0], b) && (v[`cache${b}`] || (v[`cache${b}`] = g.Dm(v[1], b, c, f)),
              v = v[`cache${b}`],
              g.P.io(e.canvas.id, v, {
                type: 'polyline',
                Vb: m,
                style: n,
              }),
              this.hW(e, v, n, i, b));
            }
          }
        }
      }
    },
    drawSingleTexture(a, b, c, e, f) {
      const g = a[1];
      if (g) {
        for (var a = a[6], i = 0; i < g.length; i++) {
          const k = f.nj(g[i][0], 'line', c);
          if (k && k.length) {
            for (let m = g[i][1], n = 0; n < m.length; n++) {
              let o = m[n][11];
              if (f.Oc(o[0], c)) {
                var s;
                o[`cache${c}`] || (o[`cache${c}`] = f.Dm(o[1], c, e, a));
                s = o[`cache${c}`];
                o = o[3];
                o *= Math.pow(2, c - f.M0[c].Mc);
                this.iW(b, s, k, o, f);
              }
            }
          }
        }
      }
    },
    iW(a, b, c, e, f) {
      const g = c[0].Jo;
      const i = this;
      if (Sd[g]) i.fs(b, e, a, Sd[g]);
      else if (c = f.$K(g)) {
        const k = new Image();
        k.onload = function () {
          Sd[g] = k;
          i.fs(b, e, a, k);
          k.onload = q;
        };
        k.src = c;
      }
    },
    fs(a, b, c, e) {
      var f = [a[0], a[1]];
      var g = [a[2], a[3]];
      var a = g[0] - f[0];
      var g = g[1] - f[1];
      var f = [f[0] + a / 2, f[1] + g / 2];
      const i = Math.sqrt(a * a + g * g);
      var b = b / 10;
      var a = Math.atan2(g, a);
      c.save();
      c.translate(f[0], f[1]);
      c.rotate(Math.PI / 2 + a);
      c.drawImage(e, -b / 2, -i / 2, b, i);
      c.restore();
    },
    hW(a, b, c, e, f) {
      c = c[0];
      if (!e && c.Jo && Td(c.Jo, f, this.ca)) this.oW(a, b, c, Td(c.Jo, f, this.ca));
      else {
        a.beginPath();
        a.moveTo(b[0], b[1]);
        for (var f = 2, g = b.length; f < g; f += 2) a.lineTo(b[f], b[f + 1]);
        c.borderWidth && e ? (a.strokeStyle = c.ro,
        a.lineCap = Pd[c.OU],
        a.lineJoin = Qd[1],
        a.lineWidth = c.borderWidth / 2,
        a.stroke()) : e || (a.strokeStyle = c.Mw,
        a.lineCap = Pd[c.DW],
        a.lineJoin = Qd[1],
        a.lineWidth = c.GK / 2,
        a.stroke());
      }
    },
    oW(a, b, c, e) {
      if (c = e[1]) {
        a.strokeStyle = c.stroke;
        a.lineCap = c.Ab;
        a.lineJoin = c.Bb;
        a.lineWidth = c.Cb;
        a.beginPath();
        a.moveTo(b[0], b[1]);
        for (var c = 2, f = b.length; c < f; c += 2) a.lineTo(b[c], b[c + 1]);
        a.stroke();
      }
      if (e = e[0]) {
        if (e.td) this.fW(a, b, e);
        else {
          a.strokeStyle = e.stroke;
          a.lineCap = e.Ab;
          a.lineJoin = e.Bb;
          a.lineWidth = e.Cb;
          a.beginPath();
          a.moveTo(b[0], b[1]);
          c = 2;
          for (f = b.length; c < f; c += 2) a.lineTo(b[c], b[c + 1]);
          a.stroke();
        }
      }
    },
    fW(a, b, c) {
      a.strokeStyle = c.stroke;
      a.lineCap = c.Ab;
      a.lineJoin = c.Bb;
      a.lineWidth = c.Cb;
      let e = p;
      var c = c.td[0];
      a.beginPath();
      for (let f = 0; f < b.length - 2; f += 2) {
        let g = b[f];
        let i = b[f + 1];
        const k = b[f + 2] - g;
        var m = b[f + 3] - i;
        const n = k !== 0 ? m / k : m > 0 ? 1E15 : -1E15;
        var m = Math.sqrt(k * k + m * m);
        let o = c;
        for (a.moveTo(g, i); m >= 0.1;) {
          o > m && (o = m);
          let s = Math.sqrt(o * o / (1 + n * n));
          k < 0 && (s = -s);
          g += s;
          i += n * s;
          a[e ? 'lineTo' : 'moveTo'](g, i);
          m -= o;
          e = !e;
        }
      }
      a.stroke();
    },
  };
  let Vd = 3; let Wd = 4; let Xd = 7; let Yd = 8; let Zd = 15; let $d = 16; const ae = {}; const be = {}; const ce = {}; let de; const
    ee = {
      3: {
        start: 3,
        Mc: 3,
      },
      4: {
        start: 4,
        Mc: 5,
      },
      5: {
        start: 4,
        Mc: 5,
      },
      6: {
        start: 6,
        Mc: 7,
      },
      7: {
        start: 6,
        Mc: 7,
      },
      8: {
        start: 8,
        Mc: 9,
      },
      9: {
        start: 8,
        Mc: 9,
      },
      10: {
        start: 10,
        Mc: 10,
      },
      11: {
        start: 11,
        Mc: 12,
      },
      12: {
        start: 11,
        Mc: 12,
      },
      13: {
        start: 11,
        Mc: 12,
      },
      14: {
        start: 14,
        Mc: 15,
      },
      15: {
        start: 14,
        Mc: 15,
      },
      16: {
        start: 16,
        Mc: 17,
      },
      17: {
        start: 16,
        Mc: 17,
      },
      18: {
        start: 18,
        Mc: 19,
      },
      19: {
        start: 18,
        Mc: 19,
      },
      20: {
        start: 18,
        Mc: 19,
      },
      21: {
        start: 18,
        Mc: 19,
      },
    };
  function fe(a) {
    this.P = a;
    this.Hc = a.M.devicePixelRatio;
    this.M0 = ee;
  }
  fe.prototype = {
    uC(a, b, c, e, f, g, i, k, m) {
      this.P.YN = {};
      const n = this;
      let o = n.P.ca;
      m || (m = 0);
      if (!window[`${o}StyleBody`] && m < 100) {
        setTimeout(() => {
          n.uC(a, b, c, e, f, g, i, k, m + 1);
        }, 100);
      } else {
        de || (de = k);
        const s = b.getContext('2d');
        let v = b.parentNode;
        v.removeChild(b);
        s.clearRect(0, 0, g, g);
        v.appendChild(b);
        v = this.Hc;
        v > 1 && !b._scale && (s.scale(v, v),
        b._scale = p);
        s.fillStyle = this.ZM('#F5F3F0');
        window[`${o}zoomFrontStyle`][f].bmapLandColor && (s.fillStyle = this.ZM(window[`${o}zoomFrontStyle`][f].bmapLandColor));
        o = b.style.width;
        b.style.width = '0px';
        b.style.width = o;
        s.fillRect(0, 0, g, g);
        if (a[0]) {
          for (o = 0; o < a[0].length; o++) {
            v = a[0][o],
            v[0] === Xd && Ld.drawPoly(v, s, f, g, this);
          }
        }
        this.P.ja() >= 17 ? (n.tK(a, s, f, g, i, c, e),
        b.yn = p) : setTimeout(() => {
          if (!b.WG) {
            n.tK(a, s, f, g, i, c, e);
            b.yn = p;
          }
        }, 1);
      }
    },
    tK(a, b, c, e) {
      const f = this.P.ca;
      if (a[0]) {
        for (let g = 0; g < a[0].length; g++) {
          const i = a[0][g];
          const k = i[0];
          k === Wd ? Ud.drawLink(i, b, c, e, this) : k === $d ? Ud.drawLink(i, b, c, e, this) : k === Zd ? (Ld.drawGaoqingRoadBorder(i, b, c, e, this),
          Ld.drawGaoqingRoadFill(i, b, c, e, this)) : k === 18 ? window[`${f}zoomFrontStyle`] && (window[`${f}zoomFrontStyle`][c] && window[`${f}zoomFrontStyle`][c].bmapRoadarrowVisibility !== 'off') && Md.drawArrow(i, b, c, e, Math.pow(2, c - ee[c].Mc), this) : k === Yd ? Nd.drawHregion(i, b, c, e, this) : k === 19 && Ud.drawSingleTexture(i, b, c, e, this);
        }
      }
    },
    sK(a, b, c, e, f, g, i) {
      const k = this;
      const m = k.P.ca;
      i || (i = 0);
      !window[`${m}StyleBody`] && i < 100 ? setTimeout(() => {
        k.sK(a, b, c, e, f, g, i + 1);
      }, 100) : (de || (de = b),
      a.yZ = Od.parse(a, c, e, this, f));
    },
    nj(a, b, c, e) {
      const f = `${a}-${b}-${c}`;
      if (e) {
        return ae[f] || (ae[f] = this.vg(a, b, c, e)),
        ae[f];
      }
      this.P.YN[f] = this.vg(a, b, c);
      return this.P.YN[f];
    },
    vg(a, b, c, e) {
      let f = this.P.ca; let
        g;
      g = e || window[`${f}_bmap_baseFs`];
      f = window[`${f}StyleBody`];
      e = g[2];
      if (b === 'arrow') return this.nZ(e[2]);
      switch (b) {
        case 'point':
          e = e[0];
          f = f[0] || {};
          break;
        case 'pointText':
          e = e[1];
          f = f[1] || {};
          break;
        case 'line':
          e = e[3];
          f = f[3] || {};
          break;
        case 'polygon':
          e = e[4];
          f = f[4] || {};
          break;
        case 'polygon3d':
          e = e[5],
          f = f[5] || {};
      }
      const i = [];
      var c = g[1][c - 1][0][a];
      if (!c) return i;
      for (g = 0; g < c.length; g++) {
        let k = f[c[g]] || e[c[g]];
        if (k) {
          switch (b) {
            case 'polygon':
              k = this.wZ(k, a);
              break;
            case 'line':
              k = this.sZ(k, a);
              break;
            case 'pointText':
              k = this.uZ(k, a);
              break;
            case 'point':
              k = this.tZ(k, a);
              break;
            case 'polygon3d':
              k = this.vZ(k, a);
          }
          k.H5 = c[g];
          i[i.length] = k;
        }
      }
      return i;
    },
    uZ(a, b) {
      return {
        Vb: b,
        KK: this.Dg(a[0]),
        AL: this.Dg(a[1]),
        f2: this.Dg(a[2]),
        fontSize: a[3],
        fx: a[4],
        fontWeight: a[5],
        fontStyle: a[6],
        PV: a[7],
      };
    },
    tZ(a, b) {
      return {
        Vb: b,
        Xx: a[0],
        Z5: a[1],
        ve: a[2],
        bY: a[3],
        I4: a[4],
        PV: a[5],
        zoom: a[6],
      };
    },
    sZ(a, b) {
      return {
        Vb: b,
        ro: this.Dg(a[0]),
        Mw: this.Dg(a[1]),
        borderWidth: a[2],
        GK: a[3],
        OU: a[4],
        DW: a[5],
        R3: a[6],
        S3: a[7],
        T3: a[8],
        l4: a[9],
        m4: a[10],
        PU: a[11],
        Jo: a[12],
        QU: a[13],
        R2: a[14],
        j4: a[15],
        P3: a[16],
        H4: a[17],
        m5: a[18],
      };
    },
    wZ(a, b) {
      return {
        Vb: b,
        Mw: this.Dg(a[0]),
        ro: this.Dg(a[1]),
        borderWidth: a[2],
        PU: a[3],
        QU: a[4],
        h6: a[5],
        O3: a[6],
        L5: a[7],
        M5: this.Dg(a[8]),
      };
    },
    vZ(a, b) {
      return {
        Vb: b,
        filter: a[0],
        kN: a[1],
        Q3: a[2],
        borderWidth: a[3],
        ro: this.Dg(a[4]),
        EW: this.Dg(a[5]),
        Q2: this.Dg(a[6]),
        Y4: a[7],
      };
    },
    nZ(a) {
      for (const b in a) {
        return a = a[b],
        {
          color: this.Dg(a[0]),
          bY: a[1],
          ve: a[2],
        };
      }
    },
    Dg(a) {
      const b = a;
      if (ce[b]) return ce[b];
      a >>>= 0;
      ce[b] = `rgba(${a & 255},${a >> 8 & 255},${a >> 16 & 255},${(a >> 24 & 255) / 255})`;
      return ce[b];
    },
    ZM(a) {
      a = a.replace('#', '');
      a.length === 6 && (a += 'ff');
      for (var b = 'rgba(', c = 0; c < 8; c += 2) b = c < 6 ? `${b}${parseInt(a.slice(c, c + 2), 16)},` : `${b}${parseInt(a.slice(c, c + 2), 16) / 255})`;
      return b;
    },
    Oc(a, b) {
      let c;
      be[a] || (c = a.toString(2),
      c.length < 8 && (c = Array(8 - c.length + 1).join('0') + c),
      be[a] = c);
      c = be[a];
      return c[b - ee[b].start] === '1';
    },
    Dm(a, b, c) {
      const e = [];
      var b = Math.pow(2, b - ee[b].Mc) / 100;
      let f = a[0] * b;
      let g = a[1] * b;
      e[e.length] = f;
      e[e.length] = c - g;
      for (let i = 2; i < a.length; i += 2) {
        f += a[i] * b,
        g += a[i + 1] * b,
        e[e.length] = f,
        e[e.length] = c - g;
      }
      return e;
    },
    $K(a) {
      if (a) {
        const b = a.length % de.length;
        const c = this.gX();
        return `${de[b] + a}.png?v=${c.BF}&udt=${c.xF}`;
      }
    },
    gX() {
      if (this.KD) return this.KD;
      const a = typeof MSV !== 'undefined' ? MSV.A4 : {};
      return this.KD = {
        BF: a.version ? a.version : '001',
        xF: a.o0 ? a.o0 : '20150621',
      };
    },
  };
  P = A.lang.ku;
  Vd = 3;
  Wd = 4;
  Xd = 7;
  Yd = 8;
  Zd = 15;
  $d = 16;
  function td(a, b, c) {
    c = c || {};
    this.P = a;
    this.Ov = b;
    this.Hc = b.kN;
    this.cb = {
      X_: 'na',
      zIndex: 0,
      eO: c.tileUrls || {
        http: ['http://online0.map.bdimg.com/pvd/?qt=vtile', 'http://online1.map.bdimg.com/pvd/?qt=vtile', 'http://online2.map.bdimg.com/pvd/?qt=vtile', 'http://online3.map.bdimg.com/pvd/?qt=vtile', 'http://online4.map.bdimg.com/pvd/?qt=vtile'],
        https: ['https://ss0.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/pvd/?qt=vtile', 'https://ss1.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/pvd/?qt=vtile', 'https://ss2.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/pvd/?qt=vtile', 'https://ss3.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/pvd/?qt=vtile', 'https://ss0.bdstatic.com/8bo_dTSlQ1gBo1vgoIiO_jowehsv/pvd/?qt=vtile'],
      },
      JD: c.iconUrls || ['https://ss0.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/sty/map_icons2x/', 'https://ss1.bdstatic.com/8bo_dTSlR1gBo1vgoIiO_jowehsv/sty/map_icons2x/'],
      dF: p,
    };
    this.nB = '';
    this.xS = {};
    var c = c.urlOpts || {
      styles: 'pl',
      extdata: 1,
      textimg: 0,
      mesh3d: 0,
      limit: 30,
    }; let
      e;
    for (e in c) c.hasOwnProperty(e) && (this.nB = `${this.nB}&${e}=${c[e]}`);
    this.dh = {};
    this.Rr = [];
    this.Ws = 0;
    this.tx = t;
    this.nx = {};
    a = this.cb.X_;
    Fd[a] ? a = Fd[a] : (b = new Gd(a, l),
    a = Fd[a] = b);
    this.Dd = a;
    this.P.Dd = this.Dd;
  }
  window.VectorIndoorTileLayer = 'VectorIndoorTileLayer';
  ea = td.prototype;
  ea.ya = function () {
    const a = this.P;
    const b = a.$e;
    if (!this.co) {
      var c = b.nq(this.cb.zIndex);
      c.style.WebkitTransform = 'translate3d(0px, 0px, 0)';
      this.co = c;
    }
    b.gg.appendChild(this.co);
    b.e4 = c;
    if (this.cb.dF) {
      ge(this);
      const e = this;
      a.addEventListener('checkvectorclick', function (a) {
        let b;
        a: {
          b = a.offsetX;
          const c = a.offsetY;
          const k = e.Rr.yZ;
          if (k) {
            for (let m = 0; m < k.length; m++) {
              for (let n = k[m], o = 0; o < n.length; o++) {
                if (a = n[o],
                !a.Qs && a.Ls && b > a.Uf && b < a.li && c > a.Vf && c < a.mi) {
                  b = a.Ls;
                  b = {
                    type: 9,
                    name: a.name,
                    uid: a.uid,
                    point: {
                      x: b.ce + b.width / 2,
                      y: b.de + 6,
                    },
                  };
                  break a;
                }
              }
            }
          }
          b = q;
        }
        b && (a = new P('onvectorclick'),
        a.a4 = b,
        a.Se = 'base',
        this.dispatchEvent(a));
      });
    }
  };
  function ge(a) {
    const b = a.P;
    const c = b.$e;
    const e = a.Hc;
    var f = b.xb();
    const g = f.width;
    var f = f.height;
    const i = L('canvas');
    i.style.cssText = `position: absolute;left:0;top:0;width:${g}px;height:${f}px;z-index:2;`;
    i.width = g * e;
    i.height = f * e;
    a.xx = i;
    a.bp = i.getContext('2d');
    a.bp.scale(e, e);
    a.bp.textBaseline = 'top';
    c.gg.appendChild(i);
    b.hS = i;
  }
  ea.LX = x('Dd');
  ea.update = function (a, b) {
    b = b || {};
    this.yF = b.yF;
    b.gm && (this.p0 = b.gm);
    if (this.cb.dF && (b.Xl && this.Xl(),
    b.F_)) {
      var c = this.Hc;
      var e = this.P.xb();
      var f = e.width;
      var e = e.height;
      const g = this.xx;
      const i = g.style;
      i.width = `${f}px`;
      i.height = `${e}px`;
      g.width = f * c;
      g.height = e * c;
      this.bp.scale(c, c);
      this.bp.textBaseline = 'top';
    }
    if (b.c6) {
      c = this.co;
      f = 0;
      for (e = c.childNodes.length; f < e; f++) c.childNodes[f].yn = t;
    }
    this.Bw = a;
    this.ep(a);
  };
  ea.ep = function (a) {
    this.Rr = [];
    var b = this.P;
    let c = b.ja();
    var e = b.Bc.ii(b.be);
    var f = this.Dd.Xb(c);
    var e = [Math.round(-e.lng / f), Math.round(e.lat / f)];
    var f = this.Dd.Id(c);
    let g = b.ca.replace(/^TANGRAM_/, '');
    let i = this.Dd.vs(c);
    var b = this.P;
    let k = -b.offsetY + b.height / 2;
    const m = this.co;
    m.style.left = `${-b.offsetX + b.width / 2}px`;
    m.style.top = `${k}px`;
    this.Oe ? this.Oe.length = 0 : this.Oe = [];
    b = 0;
    for (k = m.childNodes.length; b < k; b++) {
      var n = m.childNodes[b];
      n.Lq = t;
      this.Oe.push(n);
    }
    if (b = this.Bm) for (var o in b) delete b[o];
    else this.Bm = {};
    this.Pe ? this.Pe.length = 0 : this.Pe = [];
    b = 0;
    for (k = a.length; b < k; b++) {
      var n = a[b][0];
      var s = a[b][1];
      o = 0;
      for (var v = this.Oe.length; o < v; o++) {
        var w = this.Oe[o];
        if (w.id === `${g}_${n}_${s}_${i}_${c}`) {
          w.Lq = p;
          this.Bm[w.id] = w;
          break;
        }
      }
    }
    b = 0;
    for (k = this.Oe.length; b < k; b++) {
      w = this.Oe[b],
      w.Lq || (w.rB = q,
      delete w.rB,
      w.yn = t,
      this.Pe.push(w));
    }
    o = [];
    v = f * this.Hc;
    b = 0;
    for (k = a.length; b < k; b++) {
      var n = a[b][0];
      var s = a[b][1];
      var w = n * f + e[0];
      const y = (-1 - s) * f + e[1];
      const z = `${g}_${n}_${s}_${i}_${c}`;
      var B = this.Bm[z];
      let C = q;
      if (B) {
        C = B.style,
        C.left = `${w}px`,
        C.top = `${y}px`,
        C.width = `${f}px`,
        C.height = `${f}px`,
        B.yn ? B.oF && B.oF && this.Rr.push(B.oF) : (B.WG = p,
        B.rB = q,
        delete B.rB,
        o.push([n, s, B]));
      } else {
        if (this.Pe.length > 0) {
          var B = this.Pe.shift();
          const E = B.getContext('2d');
          B.getAttribute('width') !== v && (B._scale = t);
          B.setAttribute('width', v);
          B.setAttribute('height', v);
          C = B.style;
          C.width = `${f}px`;
          C.height = `${f}px`;
          E.clearRect(0, 0, v, v);
        } else {
          B = document.createElement('canvas'),
          C = B.style,
          C.position = 'absolute',
          this.cb.backgroundColor && (C.background = this.cb.backgroundColor),
          C.width = `${f}px`,
          C.height = `${f}px`,
          B.setAttribute('width', v),
          B.setAttribute('height', v),
          m.appendChild(B);
        }
        B.id = z;
        C.left = `${w}px`;
        C.top = `${y}px`;
        o.push([n, s, B]);
      }
      B.style.visibility = '';
    }
    b = 0;
    for (k = this.Pe.length; b < k; b++) this.Pe[b].style.visibility = 'hidden';
    if (o.length === 0) {
      he(this);
      a = this.P.ca.replace(/^TANGRAM_/, '');
      c = this.P.ja();
      e = this.Dd.vs(c);
      f = {};
      for (g = 0; g < this.Bw.length; g++) {
        i = this.Bw[g],
        i = `${a}_${i[0]}_${i[1]}_${e}_${c}`,
        this.dh[i] && (f[i] = this.dh[i],
        this.yF && this.Ov.vC.uC(this.dh[i].D0, this.dh[i].V_, this.dh[i].Zl, this.dh[i].Jm, this.dh[i].lE, this.Dd.Id(this.dh[i].lE), this.Dd.rD(this.dh[i].lE), this.cb.JD));
      }
      this.dh = f;
    } else {
      this.Ws = o.length;
      this.tx = t;
      c = this.Dd.vs(this.P.ja());
      for (e = 0; e < a.length; e++) a[e][3] = c;
      for (e = 0; e < o.length; e++) {
        a = o[e][2],
        f = o[e][0],
        g = o[e][1],
        o[e][3] = c,
        a.yn = t,
        a.WG = t,
        ie(this, f, g, c, a);
      }
    }
  };
  function ie(a, b, c, e, f) {
    const g = `${b}_${c}_${e}`;
    const i = a.xS;
    if (i[g]) {
      if (i[g].status === 'loading') return;
    } else {
      i[g] = {
        status: 'init',
        sN: 0,
      };
    }
    let k = a;
    const m = k.P;
    var n = [];
    var n = D.$t === '0' ? k.cb.eO.http : k.cb.eO.https;
    const o = Math.abs(b + c) % n.length;
    var s = `x=${b}&y=${c}&z=${e}`;
    var v = je(a.Ov);
    var w = v.BF;
    var v = v.xF;
    const y = `_${b < 0 ? '_' : ''}${c < 0 ? '$' : ''}${parseInt(`${Math.abs(b)}${Math.abs(c)}${e}`, 10).toString(36)}`;
    var s = `${s + a.nB}v=${w}&udt=${v}&fn=window.${y}`;
    var w = `${n[o]}&${s}`;
    var w = `${n[o]}&param=${window.encodeURIComponent(Mb(s))}`;
    window[y] = function (a) {
      clearTimeout(i[g].Sk);
      i[g] = q;
      if (a) {
        let n = m.ja(); let
          o;
        a: {
          for (o = 0; o < k.Bw.length; o++) {
            const s = k.Bw[o];
            if (s[0] === b && s[1] === c && s[3] === e) {
              o = p;
              break a;
            }
          }
          o = t;
        }
        if (o !== t) {
          o = new P('updateindoor');
          o.IndoorCanvas = [];
          o.IndoorCanvas.push({
            canvasDom: f,
            data: a,
            canvasID: f.id,
            ratio: k.Hc,
          });
          m.dispatchEvent(o);
          if (m.M.ok) {
            if (k.dh[f.id] = {
              D0: a,
              V_: f,
              Zl: b,
              Jm: c,
              lE: n,
            },
            k.Ov.vC.uC(a, f, b, c, n, k.Dd.Id(n), k.Dd.rD(n), k.cb.JD),
            k.cb.dF) {
              n = [];
              n.W_ = [b, c, e];
              if (a[0]) {
                for (o = 0; o < a[0].length; o++) {
                  a[0][o][0] === Vd && n.push({
                    aM: a[0][o],
                  });
                }
              }
              if (a[2]) {
                for (o = 0; o < a[2].length; o++) {
                  n.push({
                    IY: a[2][o],
                  });
                }
              }
              f.oF = n;
              k.Rr.push(n);
              k.tx === t && k.Ws--;
              (k.Ws === 0 || k.tx === p) && he(k);
            }
          } else {
            k.Ws--,
            (k.Ws === 0 || k.tx === p) && he(k);
          }
          delete window[y];
        }
      }
    };
    oa(w);
    i[g].status = 'loading';
    k = a;
    i[g].Sk = setTimeout(() => {
      i[g].sN < 3 ? (i[g].sN++,
      i[g].status = 'init',
      ie(k, b, c, e, f)) : i[g] = q;
    }, 4E3);
  }
  function he(a) {
    if (a.xx) {
      const b = a.P;
      a.xx.style.left = `${-b.offsetX}px`;
      a.xx.style.top = `${-b.offsetY}px`;
      var c = new P('updateindoorlabel');
      c.labelCanvasDom = b.hS;
      b.dispatchEvent(c);
      if (b.M.ok) {
        a.Xl();
        var c = a.Dd;
        const e = b.ja();
        const f = c.vs(b.ja());
        a.Ov.vC.sK(a.Rr, a.cb.JD, a.bp, c.Id(e), Math.pow(2, e - f), e);
        a.p0 !== 'moving' && b.dispatchEvent(new P('ontilesloaded'));
      }
    }
  }
  ea.Xl = function () {
    const a = this.P.xb();
    const b = this.Hc;
    this.bp.clearRect(0, 0, a.width * b, a.height * b);
  };
  ea.remove = function () {
    const a = this.P.$e;
    this.co && a.gg.removeChild(this.co);
  };
  function sd(a) {
    this.P = a.map;
    this.df = [];
    this.yr = {};
    this.kN = this.P.M.devicePixelRatio;
    this.vC = new fe(this.P);
    this.ya();
  }
  window.VectorIndoorTileMgr = 'VectorIndoorTileMgr';
  ea = sd.prototype;
  ea.ya = function () {
    const a = this;
    const b = this.P;
    b.addEventListener('addtilelayer', (b) => {
      a.Ne(b.target);
    });
    b.addEventListener('removetilelayer', (b) => {
      a.Yf(b.target);
    });
    setTimeout(() => {
      b.addEventListener('onmoveend', (b) => {
        b.yz !== 'centerAndZoom' && a.update({
          gm: 'moveend',
        });
      });
      b.addEventListener('onmoving', () => {
        a.update({
          gm: 'moving',
        });
      });
      b.addEventListener('onzoomend', (b) => {
        b.yz !== 'centerAndZoom' && a.update({
          Xl: p,
          gm: 'zoomend',
        });
      });
      b.addEventListener('centerandzoom', () => {
        a.update({
          Xl: p,
          gm: 'centerandzoom',
        });
      });
      b.addEventListener('onupdatestyles', () => {
        a.update({
          Xl: p,
          yF: p,
          gm: 'updatestyles',
        });
        a.P.tf(a.P.Nb());
        setTimeout(() => {
          a.P.dispatchEvent(new P('onvectordrawend'));
        }, 10);
      });
      b.addEventListener('onmaptypechange', (b) => {
        b.Sa === Na && a.update({
          Xl: p,
          gm: 'maptypechange',
        });
      });
    }, 1);
    b.addEventListener('indoor_data_refresh', u());
    b.addEventListener('onresize', () => {
      a.update({
        F_: p,
      });
    });
    a.update();
  };
  ea.Ne = function (a) {
    if (a instanceof td) {
      for (let b = 0; b < this.df.length; b++) if (this.df[b] === a) return;
      this.df.push(a);
      a.ya();
      this.P.loaded && this.update();
    }
  };
  ea.Yf = function (a) {
    if (a instanceof td) {
      for (let b = 0; b < this.df.length; b++) {
        if (this.df[b] === a) {
          this.df.splice(b, 1);
          break;
        }
      }
      a.remove();
    }
  };
  ea.qL = function (a) {
    const b = a.getName();
    if (this.yr[b]) return this.yr[b];
    var c = this.P;
    var e = c.ja();
    var f = c.Tb;
    var g = a.rD(e);
    c.ca.replace(/^TANGRAM_/, '');
    const i = Math.ceil(f.lng / g);
    const k = Math.ceil(f.lat / g);
    var a = a.Id(e);
    const m = [i, k, (f.lng / g - i) * a, (f.lat / g - k) * a];
    var e = m[0] - Math.ceil((c.width / 2 - m[2]) / a);
    var f = m[1] - Math.ceil((c.height / 2 - m[3]) / a);
    var g = m[0] + Math.ceil((c.width / 2 + m[2]) / a);
    var c = m[1] + Math.ceil((c.height / 2 + m[3]) / a);
    this.Ce ? this.Ce.length = 0 : this.Ce = [];
    for (a = e; a < g; a++) for (e = f; e < c; e++) this.Ce.push([a, e]);
    this.Ce.sort(function (a) {
      return function (b, c) {
        return 0.4 * Math.abs(b[0] - a[0]) + 0.6 * Math.abs(b[1] - a[1]) - (0.4 * Math.abs(c[0] - a[0]) + 0.6 * Math.abs(c[1] - a[1]));
      };
    }([i, k]));
    this.yr[b] = this.Ce.slice(0);
    return this.yr[b];
  };
  function je(a) {
    if (a.CF) return a.CF;
    a.CF = {
      BF: '001',
      xF: Tb('normal'),
    };
    return a.CF;
  }
  ea.update = function (a) {
    this.yr = {};
    for (let b = 0; b < this.df.length; b++) {
      const c = this.df[b];
      const e = this.qL(c.Dd);
      c.update(e, a);
    }
  };
  function ke(a, b, c) {
    this.hd = a;
    this.df = b instanceof ud ? [b] : b.slice(0);
    c = c || {};
    this.m = {
      $_: c.tips || '',
      fE: '',
      fc: c.minZoom || 4,
      mc: c.maxZoom || 18,
      Y3: c.minZoom || 4,
      X3: c.maxZoom || 18,
      vy: 256,
      nF: c.textColor || 'black',
      PC: c.errorImageUrl || '',
      ib: new hb(new Q(-21364736, -16023552), new Q(23855104, 19431424)),
      Bc: c.projection || new T(),
    };
    this.df.length >= 1 && (this.df[0].fw = p);
    A.extend(this.m, c);
  }
  A.extend(ke.prototype, {
    getName: x('hd'),
    Fs() {
      return this.m.$_;
    },
    v3() {
      return this.m.fE;
    },
    KX() {
      return this.df[0];
    },
    K3: x('df'),
    Id() {
      return this.m.vy;
    },
    mf() {
      return this.m.fc;
    },
    Te() {
      return this.m.mc;
    },
    setMaxZoom(a) {
      this.m.mc = a;
    },
    pm() {
      return this.m.nF;
    },
    jj() {
      return this.m.Bc;
    },
    o3() {
      return this.m.PC;
    },
    Id() {
      return this.m.vy;
    },
    Xb(a) {
      return Math.pow(2, 18 - a);
    },
    vL(a) {
      return this.Xb(a) * this.Id();
    },
    $E(a) {
      this.jj().CN(a);
    },
  });
  const le = [`${D.url.proto + D.url.domain.TILE_BASE_URLS[0]}/it/`, `${D.url.proto + D.url.domain.TILE_BASE_URLS[1]}/it/`, `${D.url.proto + D.url.domain.TILE_BASE_URLS[2]}/it/`, `${D.url.proto + D.url.domain.TILE_BASE_URLS[3]}/it/`, `${D.url.proto + D.url.domain.TILE_BASE_URLS[4]}/it/`];
  const ne = [`${D.url.proto + D.url.domain.TILE_ONLINE_URLS[0]}/tile/`, `${D.url.proto + D.url.domain.TILE_ONLINE_URLS[1]}/tile/`, `${D.url.proto + D.url.domain.TILE_ONLINE_URLS[2]}/tile/`, `${D.url.proto + D.url.domain.TILE_ONLINE_URLS[3]}/tile/`];
  const oe = {
    dark: 'dl',
    light: 'll',
    normal: 'pl',
  };
  const pe = new ud();
  pe.z_ = p;
  pe.getTilesUrl = function (a, b, c) {
    const e = a.x;
    var a = a.y;
    const f = Tb('normal');
    const g = 1;
    var c = oe[c];
    // this.map.mx() && (g = 2); // 修改
    // e = this.map.$e.gw(e, b).Zl;
    // return (ne[Math.abs(e + a) % ne.length] + "?qt=vtile&x=" + (e + "").replace(/-/gi, "M") + "&y=" + (a + "").replace(/-/gi, "M") + "&z=" + b + "&styles=" + c + "&scaler=" + g + (6 == A.fa.na ? "&color_dep=32&colors=50" : "") + "&udt=" + f + "&from=jsapi3_0").replace(/-(\d+)/gi, "M$1")
    tdir = bmapcfg.tiles_dir.length > 0 ? bmapcfg.tiles_dir : `${bmapcfg.home}tiles`;
    return `${tdir}/${b}/${e}/${a}${bmapcfg.imgext}`; // 使用本地的瓦片
  };
  var Na = new ke('\u5730\u56fe', pe, {
    tips: '\u663e\u793a\u666e\u901a\u5730\u56fe',
    maxZoom: 19,
  });
  const qe = new ud();
  qe.dO = [`${D.url.proto + D.url.domain.TIlE_PERSPECT_URLS[0]}/resource/mappic/`, `${D.url.proto + D.url.domain.TIlE_PERSPECT_URLS[1]}/resource/mappic/`, `${D.url.proto + D.url.domain.TIlE_PERSPECT_URLS[2]}/resource/mappic/`, `${D.url.proto + D.url.domain.TIlE_PERSPECT_URLS[3]}/resource/mappic/`];
  qe.getTilesUrl = function (a, b) {
    const c = a.x;
    var e = a.y;
    const f = 256 * Math.pow(2, 20 - b);
    var e = Math.round((9998336 - f * e) / f) - 1;
    return url = `${this.dO[Math.abs(c + e) % this.dO.length] + this.map.Lb}/${this.map.nw}/3/lv${21 - b}/${c},${e}.jpg`;
  };
  var Qa = new ke('\u4e09\u7ef4', qe, {
    tips: '\u663e\u793a\u4e09\u7ef4\u5730\u56fe',
    minZoom: 15,
    maxZoom: 20,
    textColor: 'white',
    projection: new jb(),
  });
  Qa.Xb = function (a) {
    return Math.pow(2, 20 - a);
  };
  Qa.sk = function (a) {
    if (!a) return '';
    const b = H.NB; let
      c;
    for (c in b) if (a.search(c) > -1) return b[c].Sx;
    return '';
  };
  Qa.TK = function (a) {
    return {
      bj: 2,
      gz: 1,
      sz: 14,
      sh: 4,
    }[a];
  };
  const re = new ud({
    fw: p,
  });
  re.getTilesUrl = function (a, b) {
    const c = a.x;
    const e = a.y;
    return (`${le[Math.abs(c + e) % le.length]}u=x=${c};y=${e};z=${b};v=009;type=sate&fm=46&udt=${Tb('satellite')}`).replace(/-(\d+)/gi, 'M$1');
  };
  var ab = new ke('\u536b\u661f', re, {
    tips: '\u663e\u793a\u536b\u661f\u5f71\u50cf',
    minZoom: 4,
    maxZoom: 19,
    textColor: 'white',
  });
  const se = new ud({
    transparentPng: p,
  });
  se.getTilesUrl = function (a, b) {
    const c = a.x;
    const e = a.y;
    const f = Tb('satelliteStreet');
    return (`${ne[Math.abs(c + e) % ne.length]}?qt=vtile&x=${(`${c}`).replace(/-/gi, 'M')}&y=${(`${e}`).replace(/-/gi, 'M')}&z=${b}&styles=sl${A.fa.na == 6 ? '&color_dep=32&colors=50' : ''}&udt=${f}`).replace(/-(\d+)/gi, 'M$1');
  };
  var Sa = new ke('\u6df7\u5408', [re, se], {
    tips: '\u663e\u793a\u5e26\u6709\u8857\u9053\u7684\u536b\u661f\u5f71\u50cf',
    labelText: '\u8def\u7f51',
    minZoom: 4,
    maxZoom: 19,
    textColor: 'white',
  });
  const te = 1;
  const ue = {};
  window.Q0 = ue;
  function X(a, b) {
    A.lang.Ha.call(this);
    this.Ad = {};
    this.Nm(a);
    b = b || {};
    b.pa = b.renderOptions || {};
    this.m = {
      pa: {
        Oa: b.pa.panel || q,
        map: b.pa.map || q,
        ah: b.pa.autoViewport || p,
        xt: b.pa.selectFirstResult,
        Js: b.pa.highlightMode,
        pc: b.pa.enableDragging || t,
      },
      ht: b.onSearchComplete || u(),
      PM: b.onMarkersSet || u(),
      OM: b.onInfoHtmlSet || u(),
      RM: b.onResultsHtmlSet || u(),
      NM: b.onGetBusListComplete || u(),
      MM: b.onGetBusLineComplete || u(),
      KM: b.onBusListHtmlSet || u(),
      JM: b.onBusLineHtmlSet || u(),
      vE: b.onPolylinesSet || u(),
      np: b.reqFrom || '',
    };
    this.m.pa.ah = typeof b !== 'undefined' && typeof b.renderOptions !== 'undefined' && typeof b.renderOptions.autoViewport !== 'undefined' ? b.renderOptions.autoViewport : p;
    this.m.pa.Oa = A.Ec(this.m.pa.Oa);
  }
  A.xa(X, A.lang.Ha);
  A.extend(X.prototype, {
    getResults() {
      return this.Gc ? this.Fi : this.ma;
    },
    enableAutoViewport() {
      this.m.pa.ah = p;
    },
    disableAutoViewport() {
      this.m.pa.ah = t;
    },
    Nm(a) {
      a && (this.Ad.src = a);
    },
    Ft(a) {
      this.m.ht = a || u();
    },
    setMarkersSetCallback(a) {
      this.m.PM = a || u();
    },
    setPolylinesSetCallback(a) {
      this.m.vE = a || u();
    },
    setInfoHtmlSetCallback(a) {
      this.m.OM = a || u();
    },
    setResultsHtmlSetCallback(a) {
      this.m.RM = a || u();
    },
    nm: x('Le'),
  });
  const ve = {
    hG: D.nd,
    pb(a, b, c, e, f) {
      this.HZ(b);
      const g = (1E5 * Math.random()).toFixed(0);
      D._rd[`_cbk${g}`] = function (b) {
        b.result && b.result.error && b.result.error === 202 ? alert('\u8be5AK\u56e0\u4e3a\u6076\u610f\u884c\u4e3a\u5df2\u7ecf\u88ab\u7ba1\u7406\u5458\u5c01\u7981\uff01') : (c = c || {},
        a && a(b, c),
        delete D._rd[`_cbk${g}`]);
      };
      e = e || '';
      b = c && c.u0 ? Ib(b, encodeURI) : Ib(b, encodeURIComponent);
      this.hG = c && c.CK ? c.qN ? c.qN : D.fp : D.nd;
      e = `${this.hG + e}?${b}&ie=utf-8&oue=1&fromproduct=jsapi`;
      f || (e += '&res=api');
      e = `${e}&callback=BMap._rd._cbk${g}` + `&ak=${pa}`;
      oa(e);
    },
    HZ(a) {
      if (a.qt) {
        let b = '';
        switch (a.qt) {
          case 'bt':
            b = 'z_qt|bt';
            break;
          case 'nav':
            b = 'z_qt|nav';
            break;
          case 'walk':
            b = 'z_qt|walk';
            break;
          case 'bse':
            b = 'z_qt|bse';
            break;
          case 'nse':
            b = 'z_qt|nse';
            break;
          case 'drag':
            b = 'z_qt|drag';
        }
        b !== '' && D.alog('cus.fire', 'count', b);
      }
    },
  };
  window.d1 = ve;
  D._rd = {};
  var db = {};
  window.c1 = db;
  db.mN = function (a) {
    a = a.replace(/<\/?[^>]*>/g, '');
    return a = a.replace(/[ | ]* /g, ' ');
  };
  db.oZ = function (a) {
    return a.replace(/([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0|[1-9]\d*),([1-9]\d*\.\d*|0\.\d*[1-9]\d*|0?\.0+|0|[1-9]\d*)(,)/g, '$1,$2;');
  };
  db.pZ = function (a, b) {
    return a.replace(RegExp(`(((-?\\d+)(\\.\\d+)?),((-?\\d+)(\\.\\d+)?);)(((-?\\d+)(\\.\\d+)?),((-?\\d+)(\\.\\d+)?);){${b}}`, 'ig'), '$1');
  };
  const we = 2;
  const xe = 6;
  const ye = 8;
  const ze = 2;
  const Ae = 3;
  const Be = 6;
  const Ce = 0;
  const De = 'bt';
  const Ee = 'nav';
  const Ie = 'walk';
  const Je = 'bl';
  const Ke = 'bsl';
  const Le = 'ride';
  const Me = 15;
  const Ne = 18;
  D.I = window.Instance = A.lang.Nc;
  function Oe(a, b, c) {
    A.lang.Ha.call(this);
    if (a) {
      this.ab = typeof a === 'object' ? a : A.Ec(a);
      this.page = 1;
      this.Jd = 100;
      this.AJ = 'pg';
      this.Xf = 4;
      this.LJ = b;
      this.update = p;
      a = {
        page: 1,
        R5: 100,
        Jd: 100,
        Xf: 4,
        AJ: 'pg',
        update: p,
      };
      c || (c = a);
      for (const e in c) typeof c[e] !== 'undefined' && (this[e] = c[e]);
      this.za();
    }
  }
  A.extend(Oe.prototype, {
    za() {
      this.ya();
    },
    ya() {
      this.eV();
      this.ab.innerHTML = this.DV();
    },
    eV() {
      isNaN(parseInt(this.page)) && (this.page = 1);
      isNaN(parseInt(this.Jd)) && (this.Jd = 1);
      this.page < 1 && (this.page = 1);
      this.Jd < 1 && (this.Jd = 1);
      this.page > this.Jd && (this.page = this.Jd);
      this.page = parseInt(this.page);
      this.Jd = parseInt(this.Jd);
    },
    B3() {
      location.search.match(RegExp(`[?&]?${this.AJ}=([^&]*)[&$]?`, 'gi'));
      this.page = RegExp.$1;
    },
    DV() {
      const a = [];
      var b = this.page - 1;
      const c = this.page + 1;
      a.push('<p style="margin:0;padding:0;white-space:nowrap">');
      if (!(b < 1)) {
        if (this.page >= this.Xf) {
          var e;
          a.push('<span style="margin-right:3px"><a style="color:#7777cc" href="javascript:void(0)" onclick="{temp1}">\u9996\u9875</a></span>'.replace('{temp1}', `BMap.I('${this.ca}').toPage(1);`));
        }
        a.push('<span style="margin-right:3px"><a style="color:#7777cc" href="javascript:void(0)" onclick="{temp2}">\u4e0a\u4e00\u9875</a></span>'.replace('{temp2}', `BMap.I('${this.ca}').toPage(${b});`));
      }
      if (this.page < this.Xf) {
        e = this.page % this.Xf == 0 ? this.page - this.Xf - 1 : this.page - this.page % this.Xf + 1,
        b = e + this.Xf - 1;
      } else {
        e = Math.floor(this.Xf / 2);
        var f = this.Xf % 2 - 1;
        var b = this.Jd > this.page + e ? this.page + e : this.Jd;
        e = this.page - e - f;
      }
      this.page > this.Jd - this.Xf && this.page >= this.Xf && (e = this.Jd - this.Xf + 1,
      b = this.Jd);
      for (f = e; f <= b; f++) {
        f > 0 && (f == this.page ? a.push(`<span style="margin-right:3px">${f}</span>`) : f >= 1 && f <= this.Jd && (e = `<span><a style="color:#7777cc;margin-right:3px" href="javascript:void(0)" onclick="{temp3}">[${f}]</a></span>`,
        a.push(e.replace('{temp3}', `BMap.I('${this.ca}').toPage(${f});`))));
      }
      c > this.Jd || a.push('<span><a style="color:#7777cc" href="javascript:void(0)" onclick="{temp4}">\u4e0b\u4e00\u9875</a></span>'.replace('{temp4}', `BMap.I('${this.ca}').toPage(${c});`));
      a.push('</p>');
      return a.join('');
    },
    toPage(a) {
      a = a || 1;
      typeof this.LJ === 'function' && (this.LJ(a),
      this.page = a);
      this.update && this.za();
    },
  });
  function fb(a, b) {
    X.call(this, a, b);
    b = b || {};
    b.renderOptions = b.renderOptions || {};
    this.xp(b.pageCapacity);
    typeof b.renderOptions.selectFirstResult !== 'undefined' && !b.renderOptions.selectFirstResult ? this.nC() : this.HC();
    this.Ba = [];
    this.wf = [];
    this.gb = -1;
    this.Ta = [];
    const c = this;
    Ta.load('local', () => {
      c.cz();
    }, p);
  }
  A.xa(fb, X, 'LocalSearch');
  fb.Pp = 10;
  fb.Z0 = 1;
  fb.dn = 100;
  fb.WF = 2E3;
  fb.eG = 1E5;
  A.extend(fb.prototype, {
    search(a, b) {
      this.Ta.push({
        method: 'search',
        arguments: [a, b],
      });
    },
    Km(a, b, c) {
      this.Ta.push({
        method: 'searchInBounds',
        arguments: [a, b, c],
      });
    },
    up(a, b, c, e) {
      this.Ta.push({
        method: 'searchNearby',
        arguments: [a, b, c, e],
      });
    },
    Qe() {
      delete this.Ma;
      delete this.Le;
      delete this.ma;
      delete this.ta;
      this.gb = -1;
      this.Za();
      this.m.pa.Oa && (this.m.pa.Oa.innerHTML = '');
    },
    qm: u(),
    HC() {
      this.m.pa.xt = p;
    },
    nC() {
      this.m.pa.xt = t;
    },
    xp(a) {
      this.m.Fk = typeof a === 'number' && !isNaN(a) ? a < 1 ? fb.Pp : a > fb.dn ? fb.Pp : a : fb.Pp;
    },
    nf() {
      return this.m.Fk;
    },
    toString: da('LocalSearch'),
  });
  const Pe = fb.prototype;
  V(Pe, {
    clearResults: Pe.Qe,
    setPageCapacity: Pe.xp,
    getPageCapacity: Pe.nf,
    gotoPage: Pe.qm,
    searchNearby: Pe.up,
    searchInBounds: Pe.Km,
    search: Pe.search,
    enableFirstResultSelection: Pe.HC,
    disableFirstResultSelection: Pe.nC,
  });
  function Qe(a, b) {
    X.call(this, a, b);
  }
  A.xa(Qe, X, 'BaseRoute');
  A.extend(Qe.prototype, {
    Qe: u(),
  });
  function Re(a, b) {
    X.call(this, a, b);
    b = b || {};
    this.Et(b.policy);
    this.GN(b.intercityPolicy);
    this.QN(b.transitTypePolicy);
    this.xp(b.pageCapacity);
    this.Eb = De;
    this.Vp = te;
    this.Ba = [];
    this.gb = -1;
    this.m.An = b.enableTraffic || t;
    this.Ta = [];
    const c = this;
    Ta.load('route', () => {
      c.Rd();
    });
  }
  Re.dn = 100;
  Re.aP = [0, 1, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 1];
  Re.bP = [0, 3, 4, 0, 0, 0, 5];
  A.xa(Re, Qe, 'TransitRoute');
  A.extend(Re.prototype, {
    Et(a) {
      this.m.je = a >= 0 && a <= 5 ? a : 0;
    },
    GN(a) {
      this.m.vm = a >= 0 && a <= 2 ? a : 0;
    },
    QN(a) {
      this.m.Tm = a >= 0 && a <= 2 ? a : 0;
    },
    eA(a, b) {
      this.Ta.push({
        method: '_internalSearch',
        arguments: [a, b],
      });
    },
    search(a, b) {
      this.Ta.push({
        method: 'search',
        arguments: [a, b],
      });
    },
    xp(a) {
      if (typeof a === 'string' && (a = parseInt(a, 10),
      isNaN(a))) {
        this.m.Fk = Re.dn;
        return;
      }
      this.m.Fk = typeof a !== 'number' ? Re.dn : a >= 1 && a <= Re.dn ? Math.round(a) : Re.dn;
    },
    toString: da('TransitRoute'),
    Q1(a) {
      return a.replace(/\(.*\)/, '');
    },
  });
  let Se = Re.prototype;
  V(Se, {
    _internalSearch: Se.eA,
  });
  function Te(a, b) {
    X.call(this, a, b);
    this.Ba = [];
    this.gb = -1;
    this.Ta = [];
    const c = this;
    const e = this.m.pa;
    e.Js !== 1 && e.Js !== 2 && (e.Js = 1);
    this.Ku = this.m.pa.pc ? p : t;
    Ta.load('route', () => {
      c.Rd();
    });
    this.RD && this.RD();
  }
  Te.qP = ' \u73af\u5c9b \u65e0\u5c5e\u6027\u9053\u8def \u4e3b\u8def \u9ad8\u901f\u8fde\u63a5\u8def \u4ea4\u53c9\u70b9\u5185\u8def\u6bb5 \u8fde\u63a5\u9053\u8def \u505c\u8f66\u573a\u5185\u90e8\u9053\u8def \u670d\u52a1\u533a\u5185\u90e8\u9053\u8def \u6865 \u6b65\u884c\u8857 \u8f85\u8def \u531d\u9053 \u5168\u5c01\u95ed\u9053\u8def \u672a\u5b9a\u4e49\u4ea4\u901a\u533a\u57df POI\u8fde\u63a5\u8def \u96a7\u9053 \u6b65\u884c\u9053 \u516c\u4ea4\u4e13\u7528\u9053 \u63d0\u524d\u53f3\u8f6c\u9053'.split(' ');
  A.xa(Te, Qe, 'DWRoute');
  A.extend(Te.prototype, {
    search(a, b, c) {
      this.Ta.push({
        method: 'search',
        arguments: [a, b, c],
      });
    },
  });
  function Ue(a, b) {
    Te.call(this, a, b);
    b = b || {};
    this.m.An = b.enableTraffic || t;
    this.Et(b.policy);
    this.Eb = Ee;
    this.Vp = Ae;
  }
  A.xa(Ue, Te, 'DrivingRoute');
  Ue.prototype.Et = function (a) {
    this.m.je = a >= 0 && a <= 5 ? a : 0;
  };
  function Ve(a, b) {
    Te.call(this, a, b);
    this.Eb = Ie;
    this.Vp = ze;
    this.Ku = t;
  }
  A.xa(Ve, Te, 'WalkingRoute');
  function We(a, b) {
    Te.call(this, a, b);
    this.Eb = Le;
    this.Vp = Be;
    this.Ku = t;
  }
  A.xa(We, Te, 'RidingRoute');
  function Xe(a, b) {
    A.lang.Ha.call(this);
    this.Tf = [];
    this.Hk = [];
    this.m = b;
    this.sj = a;
    this.map = this.m.pa.map || q;
    this.yN = this.m.yN;
    this.Db = q;
    this.lk = 0;
    this.kF = '';
    this.lf = 1;
    this.OC = '';
    this.op = [0, 0, 0, 0, 0, 0, 0];
    this.mM = [];
    this.Pr = [1, 1, 1, 1, 1, 1, 1];
    this.lO = [1, 1, 1, 1, 1, 1, 1];
    this.pp = [0, 0, 0, 0, 0, 0, 0];
    this.Im = [0, 0, 0, 0, 0, 0, 0];
    this.Hb = [{
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }, {
      B: '',
      Ed: 0,
      Um: 0,
      x: 0,
      y: 0,
      ra: -1,
    }];
    this.Xh = -1;
    this.Vt = [];
    this.vF = [];
    Ta.load('route', u());
  }
  A.lang.xa(Xe, A.lang.Ha, 'RouteAddr');
  const Ye = navigator.userAgent;
  /ipad|iphone|ipod|iph/i.test(Ye);
  var Ze = /android/i.test(Ye);
  function $e(a) {
    this.We = a || {};
  }
  A.extend($e.prototype, {
    xN(a, b, c) {
      const e = this;
      Ta.load('route', () => {
        e.Rd(a, b, c);
      });
    },
  });
  function af(a) {
    this.m = {};
    A.extend(this.m, a);
    this.Ta = [];
    const b = this;
    Ta.load('othersearch', () => {
      b.Rd();
    });
  }
  A.xa(af, A.lang.Ha, 'Geocoder');
  A.extend(af.prototype, {
    mm(a, b, c) {
      this.Ta.push({
        method: 'getPoint',
        arguments: [a, b, c],
      });
    },
    km(a, b, c) {
      this.Ta.push({
        method: 'getLocation',
        arguments: [a, b, c],
      });
    },
    toString: da('Geocoder'),
  });
  const bf = af.prototype;
  V(bf, {
    getPoint: bf.mm,
    getLocation: bf.km,
  });
  function Geolocation(a) {
    a = a || {};
    this.M = {
      timeout: a.timeout || 1E4,
      maximumAge: a.maximumAge || 6E5,
      enableHighAccuracy: a.enableHighAccuracy || t,
      zi: a.SDKLocation || t,
    };
    this.pe = [];
    const b = this;
    Ta.load('othersearch', () => {
      for (var a = 0, e; e = b.pe[a]; a++) b[e.method].apply(b, e.arguments);
    });
  }
  A.extend(Geolocation.prototype, {
    getCurrentPosition(a, b) {
      this.pe.push({
        method: 'getCurrentPosition',
        arguments,
      });
    },
    getStatus() {
      return we;
    },
    enableSDKLocation() {
      I() && (this.M.zi = p);
    },
    disableSDKLocation() {
      this.M.zi = t;
    },
  });
  function cf(a) {
    a = a || {};
    a.pa = a.renderOptions || {};
    this.m = {
      pa: {
        map: a.pa.map || q,
      },
    };
    this.Ta = [];
    const b = this;
    Ta.load('othersearch', () => {
      b.Rd();
    });
  }
  A.xa(cf, A.lang.Ha, 'LocalCity');
  A.extend(cf.prototype, {
    get(a) {
      this.Ta.push({
        method: 'get',
        arguments: [a],
      });
    },
    toString: da('LocalCity'),
  });
  function df() {
    this.Ta = [];
    const a = this;
    Ta.load('othersearch', () => {
      a.Rd();
    });
  }
  A.xa(df, A.lang.Ha, 'Boundary');
  A.extend(df.prototype, {
    get(a, b) {
      this.Ta.push({
        method: 'get',
        arguments: [a, b],
      });
    },
    toString: da('Boundary'),
  });
  function ef(a, b) {
    X.call(this, a, b);
    this.nP = Je;
    this.pP = Me;
    this.mP = Ke;
    this.oP = Ne;
    this.Ta = [];
    const c = this;
    Ta.load('buslinesearch', () => {
      c.Rd();
    });
  }
  ef.$u = `${H.sa}iw_plus.gif`;
  ef.gS = `${H.sa}iw_minus.gif`;
  ef.ZT = `${H.sa}stop_icon.png`;
  A.xa(ef, X);
  A.extend(ef.prototype, {
    getBusList(a) {
      this.Ta.push({
        method: 'getBusList',
        arguments: [a],
      });
    },
    getBusLine(a) {
      this.Ta.push({
        method: 'getBusLine',
        arguments: [a],
      });
    },
    setGetBusListCompleteCallback(a) {
      this.m.NM = a || u();
    },
    setGetBusLineCompleteCallback(a) {
      this.m.MM = a || u();
    },
    setBusListHtmlSetCallback(a) {
      this.m.KM = a || u();
    },
    setBusLineHtmlSetCallback(a) {
      this.m.JM = a || u();
    },
    setPolylinesSetCallback(a) {
      this.m.vE = a || u();
    },
  });
  function ff(a) {
    X.call(this, a);
    a = a || {};
    this.cb = {
      input: a.input || q,
      GB: a.baseDom || q,
      types: a.types || [],
      ht: a.onSearchComplete || u(),
    };
    this.Ad.src = a.location || '\u5168\u56fd';
    this.Wi = '';
    this.ng = q;
    this.HH = '';
    this.Mi();
    Ra(Ja);
    const b = this;
    Ta.load('autocomplete', () => {
      b.Rd();
    });
  }
  A.xa(ff, X, 'Autocomplete');
  A.extend(ff.prototype, {
    Mi: u(),
    show: u(),
    $: u(),
    aF(a) {
      this.cb.types = a;
    },
    Nm(a) {
      this.Ad.src = a;
    },
    search: ba('Wi'),
    ey: ba('HH'),
    Ft(a) {
      this.cb.ht = a;
    },
  });
  let Ua;
  function Pa(a, b) {
    function c() {
      f.m.visible ? (f.Je === 'inter' && Wa() && f.m.haveBreakId && f.m.indoorExitControl === p ? A.U.show(f.Iq) : A.U.$(f.Iq),
      this.m.closeControl && this.Af && this.P && this.P.Ra() === this.R ? A.U.show(f.Af) : A.U.$(f.Af),
      this.m.forceCloseControl && A.U.show(f.Af)) : (A.U.$(f.Af),
      A.U.$(f.Iq));
    }
    this.R = typeof a === 'string' ? A.ea(a) : a;
    this.ca = gf++;
    this.m = {
      enableScrollWheelZoom: p,
      panoramaRenderer: Oa() ? 'javascript' : 'flash',
      swfSrc: `${D.di('main_domain_nocdn', 'res/swf/')}APILoader.swf`,
      visible: p,
      indoorExitControl: p,
      indoorFloorControl: t,
      linksControl: p,
      clickOnRoad: p,
      navigationControl: p,
      closeControl: p,
      indoorSceneSwitchControl: p,
      albumsControl: t,
      albumsControlOptions: {},
      copyrightControlOptions: {},
      forceCloseControl: t,
      haveBreakId: t,
    };
    var b = b || {}; let
      e;
    for (e in b) this.m[e] = b[e];
    b.closeControl === p && (this.m.forceCloseControl = p);
    b.useWebGL === t && Oa(t);
    this.Ka = {
      heading: 0,
      pitch: 0,
    };
    this.In = [];
    this.Jb = this.fb = q;
    this.$j = this.Fq();
    this.Ba = [];
    this.Lc = 1;
    this.Je = this.ES = this.fl = '';
    this.Ie = {};
    this.Mf = q;
    this.Ug = [];
    this.Yq = [];
    this.$j == 'cvsRender' || Oa() ? (this.Sj = 90,
    this.Uj = -90) : this.$j == 'cssRender' && (this.Sj = 45,
    this.Uj = -45);
    this.cr = t;
    var f = this;
    this.Jn = function () {
      this.$j === 'flashRender' ? Ta.load('panoramaflash', () => {
        f.Mi();
      }, p) : Ta.load('panorama', () => {
        f.mb();
      }, p);
      b.Se == 'api' ? Ra(Ea) : Ra(Fa);
      this.Jn = u();
    };
    this.m.rS !== p && (this.Jn(),
    D.aq('cus.fire', 'count', 'z_loadpanoramacount'));
    this.jT(this.R);
    this.addEventListener('id_changed', () => {
      Ra(Da, {
        from: b.Se,
      });
    });
    this.BP();
    this.addEventListener('indoorexit_options_changed', c);
    this.addEventListener('scene_type_changed', c);
    this.addEventListener('onclose_options_changed', c);
    this.addEventListener('onvisible_changed', c);
  }
  let hf = 4;
  const jf = 1;
  let kf = 5;
  var gf = 0;
  A.lang.xa(Pa, A.lang.Ha, 'Panorama');
  A.extend(Pa.prototype, {
    BP() {
      const a = this;
      const b = this.Af = L('div');
      b.className = 'pano_close';
      b.style.cssText = 'z-index: 1201;display: none';
      b.title = '\u9000\u51fa\u5168\u666f';
      b.onclick = function () {
        a.$();
      };
      this.R.appendChild(b);
      const c = this.Iq = L('a');
      c.className = 'pano_pc_indoor_exit';
      c.style.cssText = 'z-index: 1201;display: none';
      c.innerHTML = '<span style="float:right;margin-right:12px;">\u51fa\u53e3</span>';
      c.title = '\u9000\u51fa\u5ba4\u5185\u666f';
      c.onclick = function () {
        a.Io();
      };
      this.R.appendChild(c);
      window.ActiveXObject && !document.addEventListener && (b.style.backgroundColor = 'rgb(37,37,37)',
      c.style.backgroundColor = 'rgb(37,37,37)');
    },
    Io: u(),
    jT(a) {
      let b; let
        c;
      b = a.style;
      c = Xa(a).position;
      c != 'absolute' && c != 'relative' && (b.position = 'relative',
      b.zIndex = 0);
      if (c === 'absolute' || c === 'relative') {
        if (a = Xa(a).zIndex,
        !a || a === 'auto') b.zIndex = 0;
      }
    },
    mX: x('In'),
    Wb: x('fb'),
    MX: x('Iv'),
    PN: x('Iv'),
    la: x('Jb'),
    Ja: x('Ka'),
    ja: x('Lc'),
    gj: x('fl'),
    D3() {
      return this.L1 || [];
    },
    x3: x('ES'),
    Es: x('Je'),
    hy(a) {
      a !== this.Je && (this.Je = a,
      this.dispatchEvent(new P('onscene_type_changed')));
    },
    ON(a) {
      a !== kf && (kf = a);
    },
    JN(a) {
      a !== hf && (hf = a);
    },
    Cc(a, b, c) {
      typeof b === 'object' && (c = b,
      b = l);
      a != this.fb && (this.ql = this.fb,
      this.rl = this.Jb,
      this.fb = a,
      this.Je = b || 'street',
      this.Jb = q,
      c && c.pov && this.rd(c.pov));
    },
    va(a) {
      a.Sb(this.Jb) || (this.ql = this.fb,
      this.rl = this.Jb,
      this.Jb = a,
      this.fb = q);
    },
    rd(a) {
      if (a) {
        var a = this.Ka.pitch;
        var b = this.Ka.heading;
        var b = this.fC(b);
        a > this.Sj ? a = this.Sj : a < this.Uj && (a = this.Uj);
        this.cr = p;
        this.Ka.pitch = a;
        this.Ka.heading = b;
      }
    },
    u_(a, b) {
      this.Uj = a >= 0 ? 0 : a;
      this.Sj = b <= 0 ? 0 : b;
    },
    fC(a) {
      return a - 360 * Math.floor(a / 360);
    },
    Qc(a) {
      a != this.Lc && (a > hf && (a = hf),
      a < jf && (a = jf),
      a != this.Lc && (this.Lc = a),
      this.$j === 'cssRender' && this.rd(this.Ka));
    },
    aB() {
      if (this.P) for (let a = this.P.Zw(), b = 0; b < a.length; b++) (a[b] instanceof W || a[b] instanceof cd) && a[b].point && this.Ba.push(a[b]);
    },
    XE: ba('P'),
    Dt(a) {
      this.Mf = a || 'none';
    },
    wj(a) {
      for (const b in a) {
        if (typeof a[b] === 'object') for (const c in a[b]) this.m[b][c] = a[b][c];
        else this.m[b] = a[b];
        a.closeControl === p && (this.m.forceCloseControl = p);
        a.closeControl === t && (this.m.forceCloseControl = t);
        switch (b) {
          case 'linksControl':
            this.dispatchEvent(new P('onlinks_visible_changed'));
            break;
          case 'clickOnRoad':
            this.dispatchEvent(new P('onclickonroad_changed'));
            break;
          case 'navigationControl':
            this.dispatchEvent(new P('onnavigation_visible_changed'));
            break;
          case 'indoorSceneSwitchControl':
            this.dispatchEvent(new P('onindoor_default_switch_mode_changed'));
            break;
          case 'albumsControl':
            this.dispatchEvent(new P('onalbums_visible_changed'));
            break;
          case 'albumsControlOptions':
            this.dispatchEvent(new P('onalbums_options_changed'));
            break;
          case 'copyrightControlOptions':
            this.dispatchEvent(new P('oncopyright_options_changed'));
            break;
          case 'closeControl':
            this.dispatchEvent(new P('onclose_options_changed'));
            break;
          case 'indoorExitControl':
            this.dispatchEvent(new P('onindoorexit_options_changed'));
            break;
          case 'indoorFloorControl':
            this.dispatchEvent(new P('onindoorfloor_options_changed'));
        }
      }
    },
    Bk() {
      this.zl.style.visibility = 'hidden';
    },
    ly() {
      this.zl.style.visibility = 'visible';
    },
    tW() {
      this.m.enableScrollWheelZoom = p;
    },
    VV() {
      this.m.enableScrollWheelZoom = t;
    },
    show() {
      this.m.visible = p;
    },
    $() {
      this.m.visible = t;
    },
    Fq() {
      return Wa() && !I() && this.m.panoramaRenderer != 'javascript' ? 'flashRender' : !I() && Qb() ? 'cvsRender' : 'cssRender';
    },
    Pa(a) {
      this.Ie[a.jd] = a;
    },
    Ob(a) {
      delete this.Ie[a];
    },
    ex() {
      return this.m.visible;
    },
    gh() {
      return new N(this.R.clientWidth, this.R.clientHeight);
    },
    Ra: x('R'),
    QK() {
      let a = D.di('baidumap', '?');
      var b = this.Wb();
      if (b) {
        var b = {
          panotype: this.Es(),
          heading: this.Ja().heading,
          pitch: this.Ja().pitch,
          pid: b,
          panoid: b,
          from: 'api',
        }; let
          c;
        for (c in b) a += `${c}=${b[c]}&`;
      }
      return a.slice(0, -1);
    },
    jx() {
      this.wj({
        copyrightControlOptions: {
          logoVisible: t,
        },
      });
    },
    eF() {
      this.wj({
        copyrightControlOptions: {
          logoVisible: p,
        },
      });
    },
    yB(a) {
      function b(a, b) {
        return function () {
          a.Yq.push({
            yM: b,
            xM: arguments,
          });
        };
      }
      for (let c = a.getPanoMethodList(), e = '', f = 0, g = c.length; f < g; f++) {
        e = c[f],
        this[e] = b(this, e);
      }
      this.Ug.push(a);
    },
    IE(a) {
      for (let b = this.Ug.length; b--;) this.Ug[b] === a && this.Ug.splice(b, 1);
    },
    WE: u(),
  });
  const lf = Pa.prototype;
  V(lf, {
    setId: lf.Cc,
    setPosition: lf.va,
    setPov: lf.rd,
    setZoom: lf.Qc,
    setOptions: lf.wj,
    getId: lf.Wb,
    getPosition: lf.la,
    getPov: lf.Ja,
    getZoom: lf.ja,
    getLinks: lf.mX,
    getBaiduMapUrl: lf.QK,
    hideMapLogo: lf.jx,
    showMapLogo: lf.eF,
    enableDoubleClickZoom: lf.N2,
    disableDoubleClickZoom: lf.E2,
    enableScrollWheelZoom: lf.tW,
    disableScrollWheelZoom: lf.VV,
    show: lf.show,
    hide: lf.$,
    addPlugin: lf.yB,
    removePlugin: lf.IE,
    getVisible: lf.ex,
    addOverlay: lf.Pa,
    removeOverlay: lf.Ob,
    getSceneType: lf.Es,
    setPanoramaPOIType: lf.Dt,
    exitInter: lf.Io,
    setInteractiveState: lf.WE,
  });
  V(window, {
    BMAP_PANORAMA_POI_HOTEL: 'hotel',
    BMAP_PANORAMA_POI_CATERING: 'catering',
    BMAP_PANORAMA_POI_MOVIE: 'movie',
    BMAP_PANORAMA_POI_TRANSIT: 'transit',
    BMAP_PANORAMA_POI_INDOOR_SCENE: 'indoor_scene',
    BMAP_PANORAMA_POI_NONE: 'none',
    BMAP_PANORAMA_INDOOR_SCENE: 'inter',
    BMAP_PANORAMA_STREET_SCENE: 'street',
  });
  function mf() {
    A.lang.Ha.call(this);
    this.jd = `PanoramaOverlay_${this.ca}`;
    this.W = q;
    this.Ua = p;
  }
  A.lang.xa(mf, A.lang.Ha, 'PanoramaOverlayBase');
  A.extend(mf.prototype, {
    z3: x('jd'),
    ya() {
      aa('initialize\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    remove() {
      aa('remove\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    Lf() {
      aa('_setOverlayProperty\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
  });
  function nf(a, b) {
    mf.call(this);
    const c = {
      position: q,
      altitude: 2,
      displayDistance: p,
    }; var b = b || {}; let
      e;
    for (e in b) c[e] = b[e];
    this.Jb = c.position;
    this.Gj = a;
    this.bq = c.altitude;
    this.MQ = c.displayDistance;
    this.nF = c.color;
    this.DL = c.hoverColor;
    this.backgroundColor = c.backgroundColor;
    this.DJ = c.backgroundHoverColor;
    this.borderColor = c.borderColor;
    this.HJ = c.borderHoverColor;
    this.fontSize = c.fontSize;
    this.padding = c.padding;
    this.LD = c.imageUrl;
    this.size = c.size;
    this.we = c.image;
    this.width = c.width;
    this.height = c.height;
    this.eY = c.imageData;
    this.borderWidth = c.borderWidth;
  }
  A.lang.xa(nf, mf, 'PanoramaLabel');
  A.extend(nf.prototype, {
    d3: x('borderWidth'),
    getImageData: x('eY'),
    pm: x('nF'),
    s3: x('DL'),
    Z2: x('backgroundColor'),
    a3: x('DJ'),
    b3: x('borderColor'),
    c3: x('HJ'),
    q3: x('fontSize'),
    A3: x('padding'),
    t3: x('LD'),
    xb: x('size'),
    Tw: x('we'),
    va(a) {
      this.Jb = a;
      this.Lf('position', a);
    },
    la: x('Jb'),
    bd(a) {
      this.Gj = a;
      this.Lf('content', a);
    },
    tk: x('Gj'),
    QE(a) {
      this.bq = a;
      this.Lf('altitude', a);
    },
    Mo: x('bq'),
    Ja() {
      var a = this.la();
      let b = q;
      var c = q;
      this.W && (c = this.W.la());
      if (a && c) {
        if (a.Sb(c)) b = this.W.Ja();
        else {
          b = {};
          b.heading = of(a.lng - c.lng, a.lat - c.lat) || 0;
          var a = b;
          var c = this.Mo();
          const e = this.Dn();
          a.pitch = Math.round(180 * (Math.atan(c / e) / Math.PI)) || 0;
        }
      }
      return b;
    },
    Dn() {
      let a = 0; let b; let
        c;
      this.W && (b = this.W.la(),
      (c = this.la()) && !c.Sb(b) && (a = T.uk(b, c)));
      return a;
    },
    $() {
      aa('hide\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    show() {
      aa('show\u65b9\u6cd5\u672a\u5b9e\u73b0');
    },
    Lf: u(),
  });
  const pf = nf.prototype;
  V(pf, {
    setPosition: pf.va,
    getPosition: pf.la,
    setContent: pf.bd,
    getContent: pf.tk,
    setAltitude: pf.QE,
    getAltitude: pf.Mo,
    getPov: pf.Ja,
    show: pf.show,
    hide: pf.$,
  });
  function qf(a, b) {
    mf.call(this);
    const c = {
      icon: '',
      title: '',
      panoInfo: q,
      altitude: 2,
    }; var b = b || {}; let
      e;
    for (e in b) c[e] = b[e];
    this.Jb = a;
    this.EH = c.icon;
    this.XI = c.title;
    this.bq = c.altitude;
    this.WS = c.panoInfo;
    this.Ka = {
      heading: 0,
      pitch: 0,
    };
  }
  A.lang.xa(qf, mf, 'PanoramaMarker');
  A.extend(qf.prototype, {
    va(a) {
      this.Jb = a;
      this.Lf('position', a);
    },
    la: x('Jb'),
    Dc(a) {
      this.XI = a;
      this.Lf('title', a);
    },
    To: x('XI'),
    Ub(a) {
      this.EH = icon;
      this.Lf('icon', a);
    },
    Oo: x('EH'),
    QE(a) {
      this.bq = a;
      this.Lf('altitude', a);
    },
    Mo: x('bq'),
    uD: x('WS'),
    Ja() {
      var a = q;
      if (this.W) {
        var a = this.W.la();
        const b = this.la();
        var a = of(b.lng - a.lng, b.lat - a.lat);
        isNaN(a) && (a = 0);
        a = {
          heading: a,
          pitch: 0,
        };
      } else a = this.Ka;
      return a;
    },
    Lf: u(),
  });
  const rf = qf.prototype;
  V(rf, {
    setPosition: rf.va,
    getPosition: rf.la,
    setTitle: rf.Dc,
    getTitle: rf.To,
    setAltitude: rf.QE,
    getAltitude: rf.Mo,
    getPanoInfo: rf.uD,
    getIcon: rf.Oo,
    setIcon: rf.Ub,
    getPov: rf.Ja,
  });
  function of(a, b) {
    var c = 0;
    if (a !== 0 && b !== 0) {
      var c = 180 * (Math.atan(a / b) / Math.PI);
      let e = 0;
      a > 0 && b < 0 && (e = 90);
      a < 0 && b < 0 && (e = 180);
      a < 0 && b > 0 && (e = 270);
      c = (c + 90) % 90 + e;
    } else a === 0 ? c = b < 0 ? 180 : 0 : b === 0 && (c = a > 0 ? 90 : 270);
    return Math.round(c);
  }
  function Oa(a) {
    if (typeof sf === 'boolean') return sf;
    if (a === t || !window.WebGLRenderingContext) return sf = t;
    if (A.platform.pj) {
      a = 0;
      try {
        let b = q;
        var c = navigator.userAgent.toLowerCase();
        c.indexOf('android') > 0 && (b = (`${c.match(/android [\d._]+/gi)}`).replace(/[^0-9|_.]/gi, '').replace(/_/gi, '.'),
        b = parseInt(b.split('.')[0], 10));
        a = b;
      } catch (e) {
        console.error(`\u83b7\u53d6\u5b89\u5353\u7248\u672c\u5931\u8d25 => ${e}`);
      }
      if (a < 5) return sf = t;
    }
    c = document.createElement('canvas');
    a = q;
    try {
      a = c.getContext('webgl');
    } catch (f) {
      sf = t;
    }
    return sf = a === q ? t : p;
  }
  let sf;
  function tf() {
    if (typeof uf === 'boolean') return uf;
    uf = p;
    if (A.platform.WD) return p;
    const a = navigator.userAgent;
    return a.indexOf('Chrome') > -1 || a.indexOf('SAMSUNG-GT-I9508') > -1 ? p : uf = t;
  }
  let uf;
  function Mc(a, b) {
    this.W = a || q;
    const c = this;
    c.W && c.ga();
    Ta.load('pservice', () => {
      c.gQ();
    });
    (b || {}).Se == 'api' ? Ra(Ha) : Ra(Ia);
    this.yd = {
      getPanoramaById: [],
      getPanoramaByLocation: [],
      getVisiblePOIs: [],
      getRecommendPanosById: [],
      getPanoramaVersions: [],
      checkPanoSupportByCityCode: [],
      getPanoramaByPOIId: [],
      getCopyrightProviders: [],
    };
  }
  D.Gk((a) => {
    a.Fq() !== 'flashRender' && new Mc(a, {
      Se: 'api',
    });
  });
  A.extend(Mc.prototype, {
    ga() {
      function a(a) {
        if (a) {
          if (a.id != b.Iv) {
            b.PN(a.id);
            b.ha = a;
            tf() || b.dispatchEvent(new P('onthumbnail_complete'));
            b.fb != q && (b.rl = b._position);
            for (var c in a) {
              if (a.hasOwnProperty(c)) {
                switch (b[`_${c}`] = a[c],
                c) {
                  case 'position':
                    b.Jb = a[c];
                    break;
                  case 'id':
                    b.fb = a[c];
                    break;
                  case 'links':
                    b.In = a[c];
                    break;
                  case 'zoom':
                    b.Lc = a[c];
                }
              }
            }
            if (b.rl) {
              var g = b.rl;
              const i = b._position;
              c = g.lat;
              const k = i.lat;
              const m = U(k - c);
              var g = U(i.lng - g.lng);
              c = Math.sin(m / 2) * Math.sin(m / 2) + Math.cos(U(c)) * Math.cos(U(k)) * Math.sin(g / 2) * Math.sin(g / 2);
              b.TG = 6371E3 * 2 * Math.atan2(Math.sqrt(c), Math.sqrt(1 - c));
            }
            c = new P('ondataload');
            b.show();
            c.data = a;
            b.dispatchEvent(c);
            b.dispatchEvent(new P('onposition_changed'));
            b.dispatchEvent(new P('onlinks_changed'));
            b.dispatchEvent(new P('oncopyright_changed'), {
              copyright: a.copyright,
            });
            a.Vl ? (b.wj({
              haveBreakId: p,
            }),
            Wa() && b.m.closeControl && A.U.show(b.Iq)) : A.U.$(b.Iq);
          }
        } else {
          b.fb = b.ql,
          b.Jb = b.rl,
          b.dispatchEvent(new P('onnoresult'));
        }
      }
      var b = this.W;
      const c = this;
      b.addEventListener('id_changed', () => {
        c.Ro(b.Wb(), a);
      });
      b.addEventListener('iid_changed', () => {
        c.Vg(`${Mc.al}qt=idata&iid=${b.Vz}&fn=`, (b) => {
          if (b && b.result && b.result.error == 0) {
            var b = b.content[0].interinfo;
            const f = {};
            f.Vl = b.BreakID;
            for (var g = b.Defaultfloor, i = q, k = 0; k < b.Floors.length; k++) {
              if (b.Floors[k].Floor == g) {
                i = b.Floors[k];
                break;
              }
            }
            f.id = i.StartID || i.Points[0].PID;
            c.Ro(f.id, a, f);
          }
        });
      });
      b.addEventListener('position_changed_inner', () => {
        c.ij(b.la(), a);
      });
    },
    Ro(a, b) {
      this.yd.getPanoramaById.push(arguments);
    },
    ij(a, b, c) {
      this.yd.getPanoramaByLocation.push(arguments);
    },
    FD(a, b, c, e) {
      this.yd.getVisiblePOIs.push(arguments);
    },
    bx(a, b) {
      this.yd.getRecommendPanosById.push(arguments);
    },
    ax(a) {
      this.yd.getPanoramaVersions.push(arguments);
    },
    LB(a, b) {
      this.yd.checkPanoSupportByCityCode.push(arguments);
    },
    $w(a, b) {
      this.yd.getPanoramaByPOIId.push(arguments);
    },
    UK(a) {
      this.yd.getCopyrightProviders.push(arguments);
    },
  });
  const vf = Mc.prototype;
  V(vf, {
    getPanoramaById: vf.Ro,
    getPanoramaByLocation: vf.ij,
    getPanoramaByPOIId: vf.$w,
  });
  function Lc(a) {
    ud.call(this);
    (a || {}).Se == 'api' ? Ra(Ba) : Ra(Ca);
  }
  Lc.mG = D.di('pano', 'tile/');
  Lc.prototype = new ud();
  Lc.prototype.getTilesUrl = function (a, b) {
    let c = `${Lc.mG[(a.x + a.y) % Lc.mG.length]}?udt=20150114&qt=tile&styles=pl&x=${a.x}&y=${a.y}&z=${b}`;
    A.fa.na && A.fa.na <= 6 && (c += '&color_dep=32');
    return c;
  };
  Lc.prototype.Vs = da(p);
  wf.Vd = new T();
  function wf() {}
  A.extend(wf, {
    WV(a, b, c) {
      c = A.lang.Nc(c);
      b = {
        data: b,
      };
      a == 'position_changed' && (b.data = wf.Vd.vj(new R(b.data.mercatorX, b.data.mercatorY)));
      c.dispatchEvent(new P(`on${a}`), b);
    },
  });
  const xf = wf;
  V(xf, {
    dispatchFlashEvent: xf.WV,
  });
  const yf = {
    dP: 50,
  };
  yf.ou = D.di('pano')[0];
  yf.mu = {
    width: 220,
    height: 60,
  };
  A.extend(yf, {
    ML(a, b, c, e) {
      if (!b || !c || !c.lngLat || !c.panoInstance) e();
      else {
        this.Pn === l && (this.Pn = new Mc(q, {
          Se: 'api',
        }));
        const f = this;
        this.Pn.LB(b, (b) => {
          b ? f.Pn.ij(c.lngLat, yf.dP, (b) => {
            if (b && b.id) {
              const g = b.id;
              var m = b.ph;
              var b = b.qh;
              const n = Mc.Vd.zg(c.lngLat);
              const o = f.JR(n, {
                x: m,
                y: b,
              });
              var m = f.eL(g, o, 0, yf.mu.width, yf.mu.height);
              a.content = f.KR(a.content, m, c.titleTip, c.beforeDomId);
              a.addEventListener('open', () => {
                ia.V(A.Ec('infoWndPano'), 'click', () => {
                  c.panoInstance.Cc(g);
                  c.panoInstance.show();
                  c.panoInstance.rd({
                    heading: o,
                    pitch: 0,
                  });
                });
              });
            }
            e();
          }) : e();
        });
      }
    },
    KR(a, b, c, e) {
      var c = c || '';
      let f;
      !e || !a.split(e)[0] ? (e = a,
      a = '') : (e = a.split(e)[0],
      f = e.lastIndexOf('<'),
      e = a.substring(0, f),
      a = a.substring(f));
      f = [];
      const g = yf.mu.width;
      const i = yf.mu.height;
      f.push(e);
      f.push(`<div id='infoWndPano' class='panoInfoBox' style='height:${i}px;width:${g}px; margin-top: -19px;'>`);
      f.push(`<img class='pano_thumnail_img' width='${g}' height='${i}' border='0' alt='${c}\u5916\u666f' title='${c}\u5916\u666f' src='${b}' onerror='Pano.PanoEntranceUtil.thumbnailNotFound(this, ${g}, ${i});' />`);
      f.push(`<div class='panoInfoBoxTitleBg' style='width:${g}px;'></div><a href='javascript:void(0)' class='panoInfoBoxTitleContent' >\u8fdb\u5165\u5168\u666f&gt;&gt;</a>`);
      f.push('</div>');
      f.push(a);
      return f.join('');
    },
    JR(a, b) {
      let c = 90 - 180 * Math.atan2(a.y - b.y, a.x - b.x) / Math.PI;
      c < 0 && (c += 360);
      return c;
    },
    eL(a, b, c, e, f) {
      const g = {
        panoId: a,
        panoHeading: b || 0,
        panoPitch: c || 0,
        width: e,
        height: f,
      };
      return (`${yf.ou}?qt=pr3d&fovy=75&quality=80&panoid={panoId}&heading={panoHeading}&pitch={panoPitch}&width={width}&height={height}`).replace(/\{(.*?)\}/g, (a, b) => g[b]);
    },
  });
  const zf = document; const Af = Math; let Bf = zf.createElement('div').style; let
    Cf;
  a: {
    for (var Df = ['t', 'webkitT', 'MozT', 'msT', 'OT'], Ef, Ff = 0, Gf = Df.length; Ff < Gf; Ff++) {
      if (Ef = `${Df[Ff]}ransform`,
      Ef in Bf) {
        Cf = Df[Ff].substr(0, Df[Ff].length - 1);
        break a;
      }
    }
    Cf = t;
  }
  const Hf = Cf ? `-${Cf.toLowerCase()}-` : '';
  const Jf = If('transform');
  const Kf = If('transitionProperty');
  const Lf = If('transitionDuration');
  const Mf = If('transformOrigin');
  const Nf = If('transitionTimingFunction');
  const Of = If('transitionDelay');
  var Ze = /android/gi.test(navigator.appVersion);
  const Pf = /iphone|ipad/gi.test(navigator.appVersion);
  const Qf = /hp-tablet/gi.test(navigator.appVersion);
  const Rf = If('perspective') in Bf;
  const Sf = 'ontouchstart' in window && !Qf;
  const Tf = Cf !== t;
  const Uf = If('transition') in Bf;
  const Vf = 'onorientationchange' in window ? 'orientationchange' : 'resize';
  const Wf = Sf ? 'touchstart' : 'mousedown';
  const Xf = Sf ? 'touchmove' : 'mousemove';
  const Yf = Sf ? 'touchend' : 'mouseup';
  const Zf = Sf ? 'touchcancel' : 'mouseup';
  const $f = Cf === t ? t : {
    '': 'transitionend',
    webkit: 'webkitTransitionEnd',
    Moz: 'transitionend',
    O: 'otransitionend',
    ms: 'MSTransitionEnd',
  }[Cf];
  const ag = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function (a) {
    return setTimeout(a, 1);
  };
  const cg = window.cancelRequestAnimationFrame || window.j6 || window.webkitCancelRequestAnimationFrame || window.mozCancelRequestAnimationFrame || window.oCancelRequestAnimationFrame || window.msCancelRequestAnimationFrame || clearTimeout;
  let dg = Rf ? ' translateZ(0)' : '';
  function eg(a, b) {
    const c = this; let
      e;
    c.Ym = typeof a === 'object' ? a : zf.getElementById(a);
    c.Ym.style.overflow = 'hidden';
    c.Pb = c.Ym.children[0];
    c.options = {
      Xo: p,
      Vm: p,
      x: 0,
      y: 0,
      so: p,
      RU: t,
      Ex: p,
      jE: p,
      Uk: p,
      wi: t,
      c0: 0,
      lw: t,
      gx: p,
      ei: p,
      xi: p,
      UC: Ze,
      kx: Pf,
      BW: Pf && Rf,
      NE: '',
      zoom: t,
      Wk: 1,
      Lp: 4,
      YV: 2,
      JO: 'scroll',
      Mt: t,
      oy: 1,
      QM: q,
      IM(a) {
        a.preventDefault();
      },
      TM: q,
      HM: q,
      SM: q,
      GM: q,
      Kx: q,
      UM: q,
      LM: q,
      jp: q,
      VM: q,
      ip: q,
    };
    for (e in b) c.options[e] = b[e];
    c.x = c.options.x;
    c.y = c.options.y;
    c.options.Uk = Tf && c.options.Uk;
    c.options.ei = c.options.Xo && c.options.ei;
    c.options.xi = c.options.Vm && c.options.xi;
    c.options.zoom = c.options.Uk && c.options.zoom;
    c.options.wi = Uf && c.options.wi;
    c.options.zoom && Ze && (dg = '');
    c.Pb.style[Kf] = c.options.Uk ? `${Hf}transform` : 'top left';
    c.Pb.style[Lf] = '0';
    c.Pb.style[Mf] = '0 0';
    c.options.wi && (c.Pb.style[Nf] = 'cubic-bezier(0.33,0.66,0.66,1)');
    c.options.Uk ? c.Pb.style[Jf] = `translate(${c.x}px,${c.y}px)${dg}` : c.Pb.style.cssText += `;position:absolute;top:${c.y}px;left:${c.x}px`;
    c.options.wi && (c.options.UC = p);
    c.refresh();
    c.ga(Vf, window);
    c.ga(Wf);
    !Sf && c.options.JO != 'none' && (c.ga('DOMMouseScroll'),
    c.ga('mousewheel'));
    c.options.lw && (c.dV = setInterval(() => {
      c.eQ();
    }, 500));
    this.options.gx && (Event.prototype.stopImmediatePropagation || (document.body.removeEventListener = function (a, b, c) {
      const e = Node.prototype.removeEventListener;
      a === 'click' ? e.call(document.body, a, b.CL || b, c) : e.call(document.body, a, b, c);
    }
    ,
    document.body.addEventListener = function (a, b, c) {
      const e = Node.prototype.addEventListener;
      a === 'click' ? e.call(document.body, a, b.CL || (b.CL = function (a) {
        a.GZ || b(a);
      }
      ), c) : e.call(document.body, a, b, c);
    }
    ),
    c.ga('click', document.body, p));
  }
  eg.prototype = {
    enabled: p,
    x: 0,
    y: 0,
    xj: [],
    scale: 1,
    aC: 0,
    bC: 0,
    Xe: [],
    rf: [],
    FB: q,
    Ay: 0,
    handleEvent(a) {
      switch (a.type) {
        case Wf:
          if (!Sf && a.button !== 0) break;
          this.Bv(a);
          break;
        case Xf:
          this.GS(a);
          break;
        case Yf:
        case Zf:
          this.Lu(a);
          break;
        case Vf:
          this.UA();
          break;
        case 'DOMMouseScroll':
        case 'mousewheel':
          this.kU(a);
          break;
        case $f:
          this.hU(a);
          break;
        case 'click':
          this.oQ(a);
      }
    },
    eQ() {
      !this.oh && (!this.Xk && !(this.Sl || this.dy == this.Pb.offsetWidth * this.scale && this.sp == this.Pb.offsetHeight * this.scale)) && this.refresh();
    },
    sv(a) {
      let b;
      this[`${a}Scrollbar`] ? (this[`${a}ScrollbarWrapper`] || (b = zf.createElement('div'),
      this.options.NE ? b.className = this.options.NE + a.toUpperCase() : b.style.cssText = `position:absolute;z-index:100;${a == 'h' ? `height:7px;bottom:1px;left:2px;right:${this.xi ? '7' : '2'}px` : `width:7px;bottom:${this.ei ? '7' : '2'}px;top:2px;right:1px`}`,
      b.style.cssText += `;pointer-events:none;${Hf}transition-property:opacity;${Hf}transition-duration:${this.options.BW ? '350ms' : '0'};overflow:hidden;opacity:${this.options.kx ? '0' : '1'}`,
      this.Ym.appendChild(b),
      this[`${a}ScrollbarWrapper`] = b,
      b = zf.createElement('div'),
      this.options.NE || (b.style.cssText = `position:absolute;z-index:100;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);${Hf}background-clip:padding-box;${Hf}box-sizing:border-box;${a == 'h' ? 'height:100%' : 'width:100%'};${Hf}border-radius:3px;border-radius:3px`),
      b.style.cssText += `;pointer-events:none;${Hf}transition-property:${Hf}transform;${Hf}transition-timing-function:cubic-bezier(0.33,0.66,0.66,1);${Hf}transition-duration:0;${Hf}transform: translate(0,0)${dg}`,
      this.options.wi && (b.style.cssText += `;${Hf}transition-timing-function:cubic-bezier(0.33,0.66,0.66,1)`),
      this[`${a}ScrollbarWrapper`].appendChild(b),
      this[`${a}ScrollbarIndicator`] = b),
      a == 'h' ? (this.yL = this.zL.clientWidth,
      this.WX = Af.max(Af.round(this.yL * this.yL / this.dy), 8),
      this.VX.style.width = `${this.WX}px`) : (this.BO = this.CO.clientHeight,
      this.y0 = Af.max(Af.round(this.BO * this.BO / this.sp), 8),
      this.x0.style.height = `${this.y0}px`),
      this.VA(a, p)) : this[`${a}ScrollbarWrapper`] && (Tf && (this[`${a}ScrollbarIndicator`].style[Jf] = ''),
      this[`${a}ScrollbarWrapper`].parentNode.removeChild(this[`${a}ScrollbarWrapper`]),
      this[`${a}ScrollbarWrapper`] = q,
      this[`${a}ScrollbarIndicator`] = q);
    },
    UA() {
      const a = this;
      setTimeout(() => {
        a.refresh();
      }, Ze ? 200 : 0);
    },
    br(a, b) {
      this.Xk || (a = this.Xo ? a : 0,
      b = this.Vm ? b : 0,
      this.options.Uk ? this.Pb.style[Jf] = `translate(${a}px,${b}px) scale(${this.scale})${dg}` : (a = Af.round(a),
      b = Af.round(b),
      this.Pb.style.left = `${a}px`,
      this.Pb.style.top = `${b}px`),
      this.x = a,
      this.y = b,
      this.VA('h'),
      this.VA('v'));
    },
    VA(a, b) {
      let c = a == 'h' ? this.x : this.y;
      this[`${a}Scrollbar`] && (c *= this[`${a}ScrollbarProp`],
      c < 0 ? (this.options.UC || (c = this[`${a}ScrollbarIndicatorSize`] + Af.round(3 * c),
      c < 8 && (c = 8),
      this[`${a}ScrollbarIndicator`].style[a == 'h' ? 'width' : 'height'] = `${c}px`),
      c = 0) : c > this[`${a}ScrollbarMaxScroll`] && (this.options.UC ? c = this[`${a}ScrollbarMaxScroll`] : (c = this[`${a}ScrollbarIndicatorSize`] - Af.round(3 * (c - this[`${a}ScrollbarMaxScroll`])),
      c < 8 && (c = 8),
      this[`${a}ScrollbarIndicator`].style[a == 'h' ? 'width' : 'height'] = `${c}px`,
      c = this[`${a}ScrollbarMaxScroll`] + (this[`${a}ScrollbarIndicatorSize`] - c))),
      this[`${a}ScrollbarWrapper`].style[Of] = '0',
      this[`${a}ScrollbarWrapper`].style.opacity = b && this.options.kx ? '0' : '1',
      this[`${a}ScrollbarIndicator`].style[Jf] = `translate(${a == 'h' ? `${c}px,0)` : `0,${c}px)`}${dg}`);
    },
    oQ(a) {
      if (a.eR === p) {
        return this.uB = a.target,
        this.Lw = Date.now(),
        p;
      }
      if (this.uB && this.Lw) {
        if (Date.now() - this.Lw > 600) {
          return this.Lw = this.uB = q,
          p;
        }
      } else {
        for (var b = a.target; b != this.Pb && b != document.body;) b = b.parentNode;
        if (b == document.body) return p;
      }
      for (b = a.target; b.nodeType != 1;) b = b.parentNode;
      b = b.tagName.toLowerCase();
      if (b != 'select' && b != 'input' && b != 'textarea') {
        return a.stopImmediatePropagation ? a.stopImmediatePropagation() : a.GZ = p,
        a.stopPropagation(),
        a.preventDefault(),
        this.Lw = this.uB = q,
        t;
      }
    },
    Bv(a) {
      const b = Sf ? a.touches[0] : a; let c; let
        e;
      if (this.enabled) {
        this.options.IM && this.options.IM.call(this, a);
        (this.options.wi || this.options.zoom) && this.ZI(0);
        this.Xk = this.Sl = this.oh = t;
        this.kC = this.jC = this.Uv = this.Tv = this.qC = this.pC = 0;
        this.options.zoom && (Sf && a.touches.length > 1) && (e = Af.abs(a.touches[0].pageX - a.touches[1].pageX),
        c = Af.abs(a.touches[0].pageY - a.touches[1].pageY),
        this.e0 = Af.sqrt(e * e + c * c),
        this.Mx = Af.abs(a.touches[0].pageX + a.touches[1].pageX - 2 * this.FF) / 2 - this.x,
        this.Nx = Af.abs(a.touches[0].pageY + a.touches[1].pageY - 2 * this.GF) / 2 - this.y,
        this.options.jp && this.options.jp.call(this, a));
        if (this.options.Ex && (this.options.Uk ? (c = getComputedStyle(this.Pb, q)[Jf].replace(/[^0-9\-.,]/g, '').split(','),
        e = +(c[12] || c[4]),
        c = +(c[13] || c[5])) : (e = +getComputedStyle(this.Pb, q).left.replace(/[^0-9-]/g, ''),
        c = +getComputedStyle(this.Pb, q).top.replace(/[^0-9-]/g, '')),
        e != this.x || c != this.y)) {
          this.options.wi ? this.$d($f) : cg(this.FB),
          this.xj = [],
          this.br(e, c),
          this.options.Kx && this.options.Kx.call(this);
        }
        this.Vv = this.x;
        this.Wv = this.y;
        this.Qt = this.x;
        this.Rt = this.y;
        this.ph = b.pageX;
        this.qh = b.pageY;
        this.startTime = a.timeStamp || Date.now();
        this.options.TM && this.options.TM.call(this, a);
        this.ga(Xf, window);
        this.ga(Yf, window);
        this.ga(Zf, window);
      }
    },
    GS(a) {
      let b = Sf ? a.touches[0] : a;
      let c = b.pageX - this.ph;
      let e = b.pageY - this.qh;
      let f = this.x + c;
      let g = this.y + e;
      const i = a.timeStamp || Date.now();
      this.options.HM && this.options.HM.call(this, a);
      if (this.options.zoom && Sf && a.touches.length > 1) {
        f = Af.abs(a.touches[0].pageX - a.touches[1].pageX),
        g = Af.abs(a.touches[0].pageY - a.touches[1].pageY),
        this.d0 = Af.sqrt(f * f + g * g),
        this.Xk = p,
        b = 1 / this.e0 * this.d0 * this.scale,
        b < this.options.Wk ? b = 0.5 * this.options.Wk * Math.pow(2, b / this.options.Wk) : b > this.options.Lp && (b = 2 * this.options.Lp * Math.pow(0.5, this.options.Lp / b)),
        this.cp = b / this.scale,
        f = this.Mx - this.Mx * this.cp + this.x,
        g = this.Nx - this.Nx * this.cp + this.y,
        this.Pb.style[Jf] = `translate(${f}px,${g}px) scale(${b})${dg}`,
        this.options.VM && this.options.VM.call(this, a);
      } else {
        this.ph = b.pageX;
        this.qh = b.pageY;
        if (f > 0 || f < this.ie) f = this.options.so ? this.x + c / 2 : f >= 0 || this.ie >= 0 ? 0 : this.ie;
        if (g > this.pf || g < this.qd) g = this.options.so ? this.y + e / 2 : g >= this.pf || this.qd >= 0 ? this.pf : this.qd;
        this.pC += c;
        this.qC += e;
        this.Tv = Af.abs(this.pC);
        this.Uv = Af.abs(this.qC);
        this.Tv < 6 && this.Uv < 6 || (this.options.jE && (this.Tv > this.Uv + 5 ? (g = this.y,
        e = 0) : this.Uv > this.Tv + 5 && (f = this.x,
        c = 0)),
        this.oh = p,
        this.br(f, g),
        this.jC = c > 0 ? -1 : c < 0 ? 1 : 0,
        this.kC = e > 0 ? -1 : e < 0 ? 1 : 0,
        i - this.startTime > 300 && (this.startTime = i,
        this.Qt = this.x,
        this.Rt = this.y),
        this.options.SM && this.options.SM.call(this, a));
      }
    },
    Lu(a) {
      if (!(Sf && a.touches.length !== 0)) {
        const b = this; let c = Sf ? a.changedTouches[0] : a; let e; let f; let g = {
          Ga: 0,
          time: 0,
        }; let i = {
          Ga: 0,
          time: 0,
        }; const
          k = (a.timeStamp || Date.now()) - b.startTime;
        e = b.x;
        f = b.y;
        b.$d(Xf, window);
        b.$d(Yf, window);
        b.$d(Zf, window);
        b.options.GM && b.options.GM.call(b, a);
        if (b.Xk) {
          e = b.scale * b.cp,
          e = Math.max(b.options.Wk, e),
          e = Math.min(b.options.Lp, e),
          b.cp = e / b.scale,
          b.scale = e,
          b.x = b.Mx - b.Mx * b.cp + b.x,
          b.y = b.Nx - b.Nx * b.cp + b.y,
          b.Pb.style[Lf] = '200ms',
          b.Pb.style[Jf] = `translate(${b.x}px,${b.y}px) scale(${b.scale})${dg}`,
          b.Xk = t,
          b.refresh(),
          b.options.ip && b.options.ip.call(b, a);
        } else {
          if (b.oh) {
            if (k < 300 && b.options.Ex) {
              g = e ? b.UH(e - b.Qt, k, -b.x, b.dy - b.du + b.x, b.options.so ? b.du : 0) : g;
              i = f ? b.UH(f - b.Rt, k, -b.y, b.qd < 0 ? b.sp - b.Zm + b.y - b.pf : 0, b.options.so ? b.Zm : 0) : i;
              e = b.x + g.Ga;
              f = b.y + i.Ga;
              if (b.x > 0 && e > 0 || b.x < b.ie && e < b.ie) {
                g = {
                  Ga: 0,
                  time: 0,
                };
              }
              if (b.y > b.pf && f > b.pf || b.y < b.qd && f < b.qd) {
                i = {
                  Ga: 0,
                  time: 0,
                };
              }
            }
            g.Ga || i.Ga ? (c = Af.max(Af.max(g.time, i.time), 10),
            b.options.Mt && (g = e - b.Vv,
            i = f - b.Wv,
            Af.abs(g) < b.options.oy && Af.abs(i) < b.options.oy ? b.scrollTo(b.Vv, b.Wv, 200) : (g = b.OI(e, f),
            e = g.x,
            f = g.y,
            c = Af.max(g.time, c))),
            b.scrollTo(Af.round(e), Af.round(f), c)) : b.options.Mt ? (g = e - b.Vv,
            i = f - b.Wv,
            Af.abs(g) < b.options.oy && Af.abs(i) < b.options.oy ? b.scrollTo(b.Vv, b.Wv, 200) : (g = b.OI(b.x, b.y),
            (g.x != b.x || g.y != b.y) && b.scrollTo(g.x, g.y, g.time))) : b.Sn(200);
          } else {
            if (Sf) {
              if (b.lK && b.options.zoom) {
                clearTimeout(b.lK),
                b.lK = q,
                b.options.jp && b.options.jp.call(b, a),
                b.zoom(b.ph, b.qh, b.scale == 1 ? b.options.YV : 1),
                b.options.ip && setTimeout(() => {
                  b.options.ip.call(b, a);
                }, 200);
              } else if (this.options.gx) {
                for (e = c.target; e.nodeType != 1;) e = e.parentNode;
                f = e.tagName.toLowerCase();
                f != 'select' && f != 'input' && f != 'textarea' ? (f = zf.createEvent('MouseEvents'),
                f.initMouseEvent('click', p, p, a.view, 1, c.screenX, c.screenY, c.clientX, c.clientY, a.ctrlKey, a.altKey, a.shiftKey, a.metaKey, 0, q),
                f.eR = p,
                e.dispatchEvent(f)) : e.focus();
              }
            }
            b.Sn(400);
          }
          b.options.UM && b.options.UM.call(b, a);
        }
      }
    },
    Sn(a) {
      const b = this.x >= 0 ? 0 : this.x < this.ie ? this.ie : this.x;
      const c = this.y >= this.pf || this.qd > 0 ? this.pf : this.y < this.qd ? this.qd : this.y;
      if (b == this.x && c == this.y) {
        if (this.oh && (this.oh = t,
        this.options.Kx && this.options.Kx.call(this)),
        this.ei && this.options.kx && (Cf == 'webkit' && (this.zL.style[Of] = '300ms'),
        this.zL.style.opacity = '0'),
        this.xi && this.options.kx) {
          Cf == 'webkit' && (this.CO.style[Of] = '300ms'),
          this.CO.style.opacity = '0';
        }
      } else this.scrollTo(b, c, a || 0);
    },
    kU(a) {
      const b = this; let c; let
        e;
      if ('wheelDeltaX' in a) {
        c = a.wheelDeltaX / 12,
        e = a.wheelDeltaY / 12;
      } else if ('wheelDelta' in a) c = e = a.wheelDelta / 12;
      else if ('detail' in a) c = e = 3 * -a.detail;
      else return;
      if (b.options.JO == 'zoom') {
        if (e = b.scale * Math.pow(2, 1 / 3 * (e ? e / Math.abs(e) : 0)),
        e < b.options.Wk && (e = b.options.Wk),
        e > b.options.Lp && (e = b.options.Lp),
        e != b.scale) {
          !b.Ay && b.options.jp && b.options.jp.call(b, a),
          b.Ay++,
          b.zoom(a.pageX, a.pageY, e, 400),
          setTimeout(() => {
            b.Ay--;
            !b.Ay && b.options.ip && b.options.ip.call(b, a);
          }, 400);
        }
      } else {
        c = b.x + c,
        e = b.y + e,
        c > 0 ? c = 0 : c < b.ie && (c = b.ie),
        e > b.pf ? e = b.pf : e < b.qd && (e = b.qd),
        b.qd < 0 && b.scrollTo(c, e, 0);
      }
    },
    hU(a) {
      a.target == this.Pb && (this.$d($f),
      this.gB());
    },
    gB() {
      const a = this; const b = a.x; const c = a.y; const e = Date.now(); let f; let g; let
        i;
      a.Sl || (a.xj.length ? (f = a.xj.shift(),
      f.x == b && f.y == c && (f.time = 0),
      a.Sl = p,
      a.oh = p,
      a.options.wi) ? (a.ZI(f.time),
        a.br(f.x, f.y),
        a.Sl = t,
        f.time ? a.ga($f) : a.Sn(0)) : (i = function () {
          let k = Date.now(); let
            m;
          if (k >= e + f.time) {
            a.br(f.x, f.y);
            a.Sl = t;
            a.options.gZ && a.options.gZ.call(a);
            a.gB();
          } else {
            k = (k - e) / f.time - 1;
            g = Af.sqrt(1 - k * k);
            k = (f.x - b) * g + b;
            m = (f.y - c) * g + c;
            a.br(k, m);
            if (a.Sl) a.FB = ag(i);
          }
        }
        ,
        i()) : a.Sn(400));
    },
    ZI(a) {
      a += 'ms';
      this.Pb.style[Lf] = a;
      this.ei && (this.VX.style[Lf] = a);
      this.xi && (this.x0.style[Lf] = a);
    },
    UH(a, b, c, e, f) {
      var b = Af.abs(a) / b;
      let g = b * b / 0.0012;
      a > 0 && g > c ? (c += f / (6 / (6.0E-4 * (g / b))),
      b = b * c / g,
      g = c) : a < 0 && g > e && (e += f / (6 / (6.0E-4 * (g / b))),
      b = b * e / g,
      g = e);
      return {
        Ga: g * (a < 0 ? -1 : 1),
        time: Af.round(b / 6.0E-4),
      };
    },
    Wj(a) {
      for (var b = -a.offsetLeft, c = -a.offsetTop; a = a.offsetParent;) {
        b -= a.offsetLeft,
        c -= a.offsetTop;
      }
      a != this.Ym && (b *= this.scale,
      c *= this.scale);
      return {
        left: b,
        top: c,
      };
    },
    OI(a, b) {
      let c; let e; let
        f;
      f = this.Xe.length - 1;
      c = 0;
      for (e = this.Xe.length; c < e; c++) {
        if (a >= this.Xe[c]) {
          f = c;
          break;
        }
      }
      f == this.aC && (f > 0 && this.jC < 0) && f--;
      a = this.Xe[f];
      e = (e = Af.abs(a - this.Xe[this.aC])) ? 500 * (Af.abs(this.x - a) / e) : 0;
      this.aC = f;
      f = this.rf.length - 1;
      for (c = 0; c < f; c++) {
        if (b >= this.rf[c]) {
          f = c;
          break;
        }
      }
      f == this.bC && (f > 0 && this.kC < 0) && f--;
      b = this.rf[f];
      c = (c = Af.abs(b - this.rf[this.bC])) ? 500 * (Af.abs(this.y - b) / c) : 0;
      this.bC = f;
      f = Af.round(Af.max(e, c)) || 200;
      return {
        x: a,
        y: b,
        time: f,
      };
    },
    ga(a, b, c) {
      (b || this.Pb).addEventListener(a, this, !!c);
    },
    $d(a, b, c) {
      (b || this.Pb).removeEventListener(a, this, !!c);
    },
    hC: ga(2),
    refresh() {
      let a; let b; let c; let
        e = 0;
      b = 0;
      this.scale < this.options.Wk && (this.scale = this.options.Wk);
      this.du = this.Ym.clientWidth || 1;
      this.Zm = this.Ym.clientHeight || 1;
      this.pf = -this.options.c0 || 0;
      this.dy = Af.round(this.Pb.offsetWidth * this.scale);
      this.sp = Af.round((this.Pb.offsetHeight + this.pf) * this.scale);
      this.ie = this.du - this.dy;
      this.qd = this.Zm - this.sp + this.pf;
      this.kC = this.jC = 0;
      this.options.QM && this.options.QM.call(this);
      this.Xo = this.options.Xo && this.ie < 0;
      this.Vm = this.options.Vm && (!this.options.RU && !this.Xo || this.sp > this.Zm);
      this.ei = this.Xo && this.options.ei;
      this.xi = this.Vm && this.options.xi && this.sp > this.Zm;
      a = this.Wj(this.Ym);
      this.FF = -a.left;
      this.GF = -a.top;
      if (typeof this.options.Mt === 'string') {
        this.Xe = [];
        this.rf = [];
        c = this.Pb.querySelectorAll(this.options.Mt);
        a = 0;
        for (b = c.length; a < b; a++) {
          e = this.Wj(c[a]),
          e.left += this.FF,
          e.top += this.GF,
          this.Xe[a] = e.left < this.ie ? this.ie : e.left * this.scale,
          this.rf[a] = e.top < this.qd ? this.qd : e.top * this.scale;
        }
      } else if (this.options.Mt) {
        for (this.Xe = []; e >= this.ie;) {
          this.Xe[b] = e,
          e -= this.du,
          b++;
        }
        this.ie % this.du && (this.Xe[this.Xe.length] = this.ie - this.Xe[this.Xe.length - 1] + this.Xe[this.Xe.length - 1]);
        b = e = 0;
        for (this.rf = []; e >= this.qd;) {
          this.rf[b] = e,
          e -= this.Zm,
          b++;
        }
        this.qd % this.Zm && (this.rf[this.rf.length] = this.qd - this.rf[this.rf.length - 1] + this.rf[this.rf.length - 1]);
      }
      this.sv('h');
      this.sv('v');
      this.Xk || (this.Pb.style[Lf] = '0',
      this.Sn(400));
    },
    scrollTo(a, b, c, e) {
      let f = a;
      this.stop();
      f.length || (f = [{
        x: a,
        y: b,
        time: c,
        IZ: e,
      }]);
      a = 0;
      for (b = f.length; a < b; a++) {
        f[a].IZ && (f[a].x = this.x - f[a].x,
        f[a].y = this.y - f[a].y),
        this.xj.push({
          x: f[a].x,
          y: f[a].y,
          time: f[a].time || 0,
        });
      }
      this.gB();
    },
    disable() {
      this.stop();
      this.Sn(0);
      this.enabled = t;
      this.$d(Xf, window);
      this.$d(Yf, window);
      this.$d(Zf, window);
    },
    enable() {
      this.enabled = p;
    },
    stop() {
      this.options.wi ? this.$d($f) : cg(this.FB);
      this.xj = [];
      this.Sl = this.oh = t;
    },
    zoom(a, b, c, e) {
      const f = c / this.scale;
      this.options.Uk && (this.Xk = p,
      e = e === l ? 200 : e,
      a = a - this.FF - this.x,
      b = b - this.GF - this.y,
      this.x = a - a * f + this.x,
      this.y = b - b * f + this.y,
      this.scale = c,
      this.refresh(),
      this.x = this.x > 0 ? 0 : this.x < this.ie ? this.ie : this.x,
      this.y = this.y > this.pf ? this.pf : this.y < this.qd ? this.qd : this.y,
      this.Pb.style[Lf] = `${e}ms`,
      this.Pb.style[Jf] = `translate(${this.x}px,${this.y}px) scale(${c})${dg}`,
      this.Xk = t);
    },
  };
  function If(a) {
    if (Cf === '') return a;
    a = a.charAt(0).toUpperCase() + a.substr(1);
    return Cf + a;
  }
  Bf = q;
  function fg(a) {
    this.m = {
      anchor: Fc,
      offset: new N(0, 0),
      maxWidth: '100%',
      imageHeight: 80,
    };
    var a = a || {}; let
      b;
    for (b in a) this.m[b] = a[b];
    this.Hl = new Mc(q, {
      Se: 'api',
    });
    this.Yj = [];
    this.W = q;
    this.fg = {
      height: this.m.imageHeight,
      width: this.m.imageHeight * gg,
    };
    this.Rc = this.WA = this.Vl = this.Xc = q;
  }
  const hg = [0, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4, 5, 5, 5, 6, 6, 7, 8, 8, 8, 9, 10];
  const ig = '\u5176\u4ed6 \u6b63\u95e8 \u623f\u578b \u8bbe\u65bd \u6b63\u95e8 \u9910\u996e\u8bbe\u65bd \u5176\u4ed6\u8bbe\u65bd \u6b63\u95e8 \u8bbe\u65bd \u89c2\u5f71\u5385 \u5176\u4ed6\u8bbe\u65bd'.split(' ');
  D.Gk((a) => {
    let b = q;
    a.addEventListener('position_changed', () => {
      a.m.visible && a.m.albumsControl === p && (b ? b.Yx(a.Wb()) : (b = new fg(a.m.albumsControlOptions),
      b.ya(a)));
    });
    a.addEventListener('albums_visible_changed', () => {
      a.m.albumsControl === p ? (b ? b.Yx(a.Wb()) : (b = new fg(a.m.albumsControlOptions),
      b.ya(a)),
      b.show()) : b.$();
    });
    a.addEventListener('albums_options_changed', () => {
      b && b.wj(a.m.albumsControlOptions);
    });
    a.addEventListener('visible_changed', () => {
      b && (a.ex() ? a.m.albumsControl === p && (b.R.style.visibility = 'visible') : b.R.style.visibility = 'hidden');
    });
  });
  var gg = 1.8;
  I() && (gg = 1);
  A.extend(fg.prototype, {
    wj(a) {
      for (const b in a) this.m[b] = a[b];
      a = `${this.m.imageHeight}px`;
      this.rc(this.m.anchor);
      this.R.style.width = isNaN(Number(this.m.maxWidth)) === p ? this.m.maxWidth : `${this.m.maxWidth}px`;
      this.R.style.height = a;
      this.dk.style.height = a;
      this.Oh.style.height = a;
      this.fg = {
        height: this.m.imageHeight,
        width: this.m.imageHeight * gg,
      };
      this.ck.style.height = `${this.fg.height - 6}px`;
      this.ck.style.width = `${this.fg.width - 6}px`;
      this.Yx(this.W.Wb(), p);
    },
    ya(a) {
      this.W = a;
      this.Or();
      this.NP();
      this.mY();
      this.Yx(a.Wb());
    },
    Or() {
      const a = `${this.m.imageHeight}px`;
      this.R = L('div');
      let b = this.R.style;
      b.cssText = 'background:rgb(37,37,37);background:rgba(37,37,37,0.9);';
      b.position = 'absolute';
      b.zIndex = '2000';
      b.width = isNaN(Number(this.m.maxWidth)) === p ? this.m.maxWidth : `${this.m.maxWidth}px`;
      b.padding = '8px 0';
      b.visibility = 'hidden';
      b.height = a;
      this.dk = L('div');
      b = this.dk.style;
      b.position = 'absolute';
      b.overflow = 'hidden';
      b.width = '100%';
      b.height = a;
      this.Oh = L('div');
      b = this.Oh.style;
      b.height = a;
      this.dk.appendChild(this.Oh);
      this.R.appendChild(this.dk);
      this.W.R.appendChild(this.R);
      this.ck = L('div', {
        class: 'pano_photo_item_seleted',
      });
      this.ck.style.height = `${this.fg.height - 6}px`;
      this.ck.style.width = `${this.fg.width - 6}px`;
      this.rc(this.m.anchor);
    },
    oH(a) {
      for (let b = this.Yj, c = b.length - 1; c >= 0; c--) if (b[c].panoId == a) return c;
      return -1;
    },
    Yx(a, b) {
      if (b || !this.Yj[this.Xc] || !(this.Yj[this.Xc].panoId == a && this.Yj[this.Xc].recoType !== 3)) {
        const c = this;
        const e = this.oH(a);
        !b && e !== -1 && this.Yj[e] && this.Yj[e].recoType !== 3 ? this.wp(e) : this.BX((a) => {
          for (var b = {}, e, k, m = t, n = [], o = 0, s = a.length; o < s; o++) {
            e = a[o].catlog,
            k = a[o].floor,
            l !== e && (e === '' && l !== k ? (m = p,
            b[k] || (b[k] = []),
            b[k].push(a[o])) : (b[hg[e]] || (b[hg[e]] = []),
            b[hg[e]].push(a[o])));
          }
          for (const v in b) {
            m ? n.push({
              data: `${v}F`,
              index: v,
            }) : n.push({
              data: ig[v],
              index: v,
            });
          }
          c.HG = b;
          c.Ki = n;
          c.El(a);
          a.length == 0 ? c.$() : c.show();
        });
      }
    },
    EV() {
      if (!this.Hi) {
        let a = this.pX(this.Ki);
        let b = L('div');
        b.style.cssText = [`width:${134 * this.Ki.length}px;`, 'overflow:hidden;-ms-user-select:none;-moz-user-select:none;-webkit-user-select:none;'].join('');
        b.innerHTML = a;
        a = L('div');
        a.appendChild(b);
        a.style.cssText = 'position:absolute;top:-25px;background:rgb(37,37,37);background:rgba(37,37,37,0.9);border-bottom:1px solid #4e596a;width:100%;line-height:25px;height:25px;overflow:scroll;outline:0';
        new eg(a, {
          so: t,
          Ex: p,
          ei: t,
          xi: t,
          Vm: t,
          jE: p,
          lw: p,
          gx: p,
        });
        this.R.appendChild(a);
        for (var c = this, e = b.getElementsByTagName('span'), f = 0, g = e.length; f < g; f++) {
          b = e[f],
          A.V(b, 'click', function () {
            if (this.getAttribute('dataindex')) {
              c.El(c.HG[this.getAttribute('dataindex')]);
              for (let a = 0, b = e.length; a < b; a++) e[a].style.color = '#FFFFFF';
              this.style.color = '#3383FF';
            }
          });
        }
        this.Hi = a;
      }
    },
    BV() {
      if (this.Hi) {
        a = this.SK(this.Ki),
        this.cQ.innerHTML = a;
      } else {
        var a = this.SK(this.Ki);
        const b = L('ul');
        const c = this;
        b.style.cssText = 'list-style: none;padding:0px;margin:0px;display:block;width:60px;position:absolute;top:7px';
        b.innerHTML = a;
        A.V(b, 'click', (a) => {
          if (a = (a.srcElement || a.target).getAttribute('dataindex')) {
            c.El(c.HG[a]);
            for (let e = b.getElementsByTagName('li'), f = 0, g = e.length; f < g; f++) e[f].childNodes[0].getAttribute('dataindex') === a ? A.U.hb(e[f], 'pano_catlogLiActive') : A.U.qc(e[f], 'pano_catlogLiActive');
          }
        });
        var a = L('div');
        let e = L('a');
        const f = L('span');
        const g = L('a');
        const i = L('span');
        const k = [`background:url(${H.sa}panorama/catlog_icon.png) no-repeat;`, 'display:block;width:10px;height:7px;margin:0 auto;'].join('');
        f.style.cssText = `${k}background-position:-18px 0;`;
        e.style.cssText = 'background:#1C1C1C;display:block;position:absolute;width:58px;';
        i.style.cssText = `${k}background-position:0 0;`;
        g.style.cssText = 'background:#1C1C1C;display:block;position:absolute;width:58px;';
        g.style.top = `${this.m.imageHeight - 7}px`;
        a.style.cssText = 'position:absolute;top:0px;left:0px;width:60px;';
        e.appendChild(f);
        g.appendChild(i);
        A.V(e, 'mouseover', () => {
          const a = parseInt(b.style.top, 10);
          a !== 7 && (f.style.backgroundPosition = '-27px 0');
          new wb({
            Ic: 60,
            ac: xb.gs,
            duration: 300,
            za(c) {
              b.style.top = `${a + (7 - a) * c}px`;
            },
          });
        });
        A.V(e, 'mouseout', () => {
          f.style.backgroundPosition = '-18px 0';
        });
        A.V(g, 'mouseover', () => {
          const a = parseInt(b.style.top, 10);
          const e = c.m.imageHeight - 14;
          if (!(parseInt(b.offsetHeight, 10) < e)) {
            const f = e - parseInt(b.offsetHeight, 10) + 7;
            f !== a && (i.style.backgroundPosition = '-9px 0');
            new wb({
              Ic: 60,
              ac: xb.gs,
              duration: 300,
              za(c) {
                b.style.top = `${a + (f - a) * c}px`;
              },
            });
          }
        });
        A.V(g, 'mouseout', () => {
          i.style.backgroundPosition = '0 0';
        });
        a.appendChild(e);
        a.appendChild(g);
        e = L('div');
        e.style.cssText = ['position:absolute;z-index:2001;left:20px;', `height:${this.m.imageHeight}px;`, 'width:62px;overflow:hidden;background:rgb(37,37,37);background:rgba(37,37,37,0.9);'].join('');
        e.appendChild(b);
        e.appendChild(a);
        this.Hi = e;
        this.cQ = b;
        this.R.appendChild(e);
      }
    },
    CV() {
      if (this.Ki && !(this.Ki.length <= 0)) {
        const a = L('div');
        a.innerHTML = this.zz;
        a.style.cssText = 'position:absolute;background:#252525';
        this.R.appendChild(a);
        this.js = a;
        this.Rc.hg.style.left = `${this.fg.width + 8}px`;
        this.Hi && (this.Hi.style.left = `${parseInt(this.Hi.style.left, 10) + this.fg.width + 8}px`);
        const b = this;
        A.V(a, 'click', () => {
          b.W.Cc(b.xW);
        });
      }
    },
    El(a) {
      this.Yj = a;
      this.m.showCatalog && (this.Ki.length > 0 ? (Wa() ? this.BV() : this.EV(),
      this.Rc.offsetLeft = 60) : (this.js && (this.R.removeChild(this.js),
      this.js = q,
      this.Rc.hg.style.left = '0px'),
      this.Hi && (this.R.removeChild(this.Hi),
      this.Hi = q),
      this.Rc.offsetLeft = 0));
      let b = this.iX(a);
      Wa() && (this.Ki && this.Ki.length > 0 && this.m.showExit && this.zz) && (this.Rc.offsetLeft += this.fg.width + 8,
      this.js ? this.js.innerHTML = this.zz : this.CV());
      this.Oh.innerHTML = b;
      this.Oh.style.width = `${(this.fg.width + 8) * a.length + 8}px`;
      a = this.R.offsetWidth;
      b = this.Oh.offsetWidth;
      this.Rc.ss && (b += this.Rc.ss());
      b < a - 2 * this.Rc.Ai - this.Rc.offsetLeft ? this.R.style.width = `${b + this.Rc.offsetLeft}px` : (this.R.style.width = isNaN(Number(this.m.maxWidth)) === p ? this.m.maxWidth : `${this.m.maxWidth}px`,
      b < this.R.offsetWidth - 2 * this.Rc.Ai - this.Rc.offsetLeft && (this.R.style.width = `${b + this.Rc.offsetLeft}px`));
      this.Rc.refresh();
      this.WA = this.Oh.children;
      this.Oh.appendChild(this.ck);
      this.ck.style.left = '-100000px';
      a = this.oH(this.W.Wb(), this.P1);
      a !== -1 && this.wp(a);
    },
    pX(a) {
      for (var b = '', c, e = 0, f = a.length; e < f; e++) {
        c = `<div style="color:white;opacity:0.5;margin:0 35px;float:left;text-align: center"><span  dataIndex="${a[e].index}">${a[e].data}</span></div>`,
        b += c;
      }
      return b;
    },
    SK(a) {
      for (var b = '', c, e = 0, f = a.length; e < f; e++) {
        c = `<li class="pano_catlogLi"><span style="display:block;width:100%;" dataIndex="${a[e].index}">${a[e].data}</span></li>`,
        b += c;
      }
      return b;
    },
    iX(a) {
      for (var b, c, e, f, g = [], i = this.fg.height, k = this.fg.width, m = 0; m < a.length; m++) {
        b = a[m],
        recoType = b.recoType,
        e = b.panoId,
        f = b.name,
        c = b.heading,
        b = b.pitch,
        c = yf.eL(e, c, b, 198, 108),
        b = `<a href="javascript:void(0);" class="pano_photo_item" data-index="${m}"><img style="width:${k - 2}px;height:${i - 2}px;" data-index="${m}" name="${f}" src="${c}" alt="${f}"/><span class="pano_photo_decs" data-index="${m}" style="width:${k}px;font-size:${Math.floor(i / 6)}px; line-height:${Math.floor(i / 6)}px;"><em class="pano_poi_${recoType}"></em>${f}</span></a>`,
        recoType === 3 ? Wa() ? (this.zz = b,
        this.xW = e,
        a.splice(m, 1),
        m--) : (b = `<a href="javascript:void(0);" class="pano_photo_item" data-index="${m}"><img style="width:${k - 2}px;height:${i - 2}px;" data-index="${m}" name="${f}" src="${c}" alt="${f}"/><div style="background:rgba(37,37,37,0.5);position:absolute;top:0px;left:0px;width:100%;height:100%;text-align: center;line-height:${this.m.imageHeight}px;" data-index="${m}"><img src="${H.sa}panorama/photoexit.png" style="border:none;vertical-align:middle;" data-index="${m}" alt=""/></div></a>`,
        g.push(b)) : g.push(b);
      }
      return g.join('');
    },
    BX(a) {
      const b = this;
      const c = this.W.Wb();
      c && this.Hl.bx(c, (e) => {
        b.W.Wb() === c && a(e);
      });
    },
    rc(a) {
      if (!Za(a) || isNaN(a) || a < Dc || a > 3) a = this.defaultAnchor;
      const b = this.R;
      const c = this.m.offset.width;
      const e = this.m.offset.height;
      b.style.left = b.style.top = b.style.right = b.style.bottom = 'auto';
      switch (a) {
        case Dc:
          b.style.top = `${e}px`;
          b.style.left = `${c}px`;
          break;
        case Ec:
          b.style.top = `${e}px`;
          b.style.right = `${c}px`;
          break;
        case Fc:
          b.style.bottom = `${e}px`;
          b.style.left = `${c}px`;
          break;
        case 3:
          b.style.bottom = `${e}px`,
          b.style.right = `${c}px`;
      }
    },
    NP() {
      this.LP();
    },
    LP() {
      const a = this;
      A.V(this.R, 'touchstart', (a) => {
        a.stopPropagation();
      });
      A.V(this.dk, 'click', (b) => {
        if ((b = (b.srcElement || b.target).getAttribute('data-index')) && b != a.Xc) {
          a.wp(b),
          a.W.Cc(a.Yj[b].panoId);
        }
      });
      A.V(this.Oh, 'mouseover', (b) => {
        b = (b.srcElement || b.target).getAttribute('data-index');
        b !== q && a.VJ(b, p);
      });
      this.W.addEventListener('size_changed', () => {
        isNaN(Number(a.m.maxWidth)) && a.wj({
          maxWidth: a.m.maxWidth,
        });
      });
    },
    wp(a) {
      this.ck.style.left = `${this.WA[a].offsetLeft + 8}px`;
      this.ck.setAttribute('data-index', this.WA[a].getAttribute('data-index'));
      this.Xc = a;
      this.VJ(a);
    },
    VJ(a, b) {
      let c = this.fg.width + 8;
      let e = 0;
      this.Rc.ss && (e = this.Rc.ss() / 2);
      const f = this.dk.offsetWidth - 2 * e;
      var g = this.Oh.offsetLeft || this.Rc.x;
      var g = g - e;
      const i = -a * c;
      i > g && this.Rc.scrollTo(i + e);
      c = i - c;
      g -= f;
      c < g && (!b || b && i - g > 8) && this.Rc.scrollTo(c + f + e);
    },
    mY() {
      this.Rc = I() ? new eg(this.dk, {
        so: t,
        Ex: p,
        ei: t,
        xi: t,
        Vm: t,
        jE: p,
        lw: p,
        gx: p,
      }) : new jg(this.dk);
    },
    $() {
      this.R.style.visibility = 'hidden';
    },
    show() {
      this.R.style.visibility = 'visible';
    },
  });
  function jg(a) {
    this.R = a;
    this.Xg = a.children[0];
    this.rr = q;
    this.Ai = 20;
    this.offsetLeft = 0;
    this.ya();
  }
  jg.prototype = {
    ya() {
      this.Xg.style.position = 'relative';
      this.refresh();
      this.Or();
      this.HB();
    },
    refresh() {
      this.Nn = this.R.offsetWidth - this.ss();
      this.tA = -(this.Xg.offsetWidth - this.Nn - this.Ai);
      this.ev = this.Ai + this.offsetLeft;
      this.Xg.style.left = `${this.ev}px`;
      this.Xg.children[0] && (this.rr = this.Xg.children[0].offsetWidth);
      this.hg && (this.hg.children[0].style.marginTop = this.jr.children[0].style.marginTop = `${this.hg.offsetHeight / 2 - this.hg.children[0].offsetHeight / 2}px`);
    },
    ss() {
      return 2 * this.Ai;
    },
    Or() {
      this.tv = L('div');
      this.tv.innerHTML = '<a class="pano_photo_arrow_l" style="background:rgb(37,37,37);background:rgba(37,37,37,0.9);" href="javascript:void(0)" title="\u4e0a\u4e00\u9875"><span class="pano_arrow_l"></span></a><a class="pano_photo_arrow_r" style="background:rgb(37,37,37);background:rgba(37,37,37,0.9);" href="javascript:void(0)" title="\u4e0b\u4e00\u9875"><span class="pano_arrow_r"></span></a>';
      this.hg = this.tv.children[0];
      this.jr = this.tv.children[1];
      this.R.appendChild(this.tv);
      this.hg.children[0].style.marginTop = this.jr.children[0].style.marginTop = `${this.hg.offsetHeight / 2 - this.hg.children[0].offsetHeight / 2}px`;
    },
    HB() {
      const a = this;
      A.V(this.hg, 'click', () => {
        a.scrollTo(a.Xg.offsetLeft + a.Nn);
      });
      A.V(this.jr, 'click', () => {
        a.scrollTo(a.Xg.offsetLeft - a.Nn);
      });
    },
    iU() {
      A.U.qc(this.hg, 'pano_arrow_disable');
      A.U.qc(this.jr, 'pano_arrow_disable');
      const a = this.Xg.offsetLeft;
      a >= this.ev && A.U.hb(this.hg, 'pano_arrow_disable');
      a - this.Nn <= this.tA && A.U.hb(this.jr, 'pano_arrow_disable');
    },
    scrollTo(a) {
      a = a < this.Xg.offsetLeft ? Math.ceil((a - this.Ai - this.Nn) / this.rr) * this.rr + this.Nn + this.Ai - 8 : Math.ceil((a - this.Ai) / this.rr) * this.rr + this.Ai;
      a < this.tA ? a = this.tA : a > this.ev && (a = this.ev);
      const b = this.Xg.offsetLeft;
      const c = this;
      new wb({
        Ic: 60,
        ac: xb.gs,
        duration: 300,
        za(e) {
          c.Xg.style.left = `${b + (a - b) * e}px`;
        },
        finish() {
          c.iU();
        },
      });
    },
  };
  D.Map = Ma;
  D.Hotspot = kb;
  D.MapType = ke;
  D.Point = Q;
  D.Pixel = R;
  D.Size = N;
  D.Bounds = hb;
  D.TileLayer = ud;
  D.Projection = Rc;
  D.MercatorProjection = T;
  D.PerspectiveProjection = jb;
  D.Copyright = function (a, b, c) {
    this.id = a;
    this.ib = b;
    this.content = c;
  };
  D.Overlay = Vc;
  D.Label = cd;
  D.GroundOverlay = dd;
  D.PointCollection = hd;
  D.Marker = W;
  D.CanvasLayer = kd;
  D.Icon = Zc;
  D.IconSequence = ad;
  D.Symbol = $c;
  D.Polyline = od;
  D.Polygon = nd;
  D.InfoWindow = bd;
  D.Circle = pd;
  D.Control = Cc;
  D.NavigationControl = mb;
  D.GeolocationControl = Gc;
  D.OverviewMapControl = ob;
  D.CopyrightControl = Hc;
  D.ScaleControl = nb;
  D.MapTypeControl = pb;
  D.CityListControl = Ic;
  D.PanoramaControl = Kc;
  D.TrafficLayer = Bd;
  D.CustomLayer = qb;
  D.ContextMenu = Nc;
  D.MenuItem = Qc;
  D.LocalSearch = fb;
  D.TransitRoute = Re;
  D.DrivingRoute = Ue;
  D.WalkingRoute = Ve;
  D.RidingRoute = We;
  D.Autocomplete = ff;
  D.RouteSearch = $e;
  D.Geocoder = af;
  D.LocalCity = cf;
  D.Geolocation = Geolocation;
  D.Convertor = Tc;
  D.BusLineSearch = ef;
  D.Boundary = df;
  D.Panorama = Pa;
  D.PanoramaLabel = nf;
  D.PanoramaService = Mc;
  D.PanoramaCoverageLayer = Lc;
  D.PanoramaFlashInterface = wf;
  function V(a, b) {
    for (const c in b) a[c] = b[c];
  }
  V(window, {
    BMap: D,
    _jsload2(a, b) {
      ia.py.AY && ia.py.set(a, b);
      Ta.cV(a, b);
    },
    BMAP_API_VERSION: '2.0',
  });
  const kg = Ma.prototype;
  V(kg, {
    getBounds: kg.te,
    getCenter: kg.Nb,
    getMapType: kg.wa,
    getSize: kg.xb,
    setSize: kg.Be,
    getViewport: kg.Gs,
    getZoom: kg.ja,
    centerAndZoom: kg.od,
    panTo: kg.qi,
    panBy: kg.Cg,
    setCenter: kg.tf,
    setCurrentCity: kg.UE,
    setMapType: kg.Gg,
    setViewport: kg.vh,
    setZoom: kg.Qc,
    highResolutionEnabled: kg.mx,
    zoomTo: kg.Ig,
    zoomIn: kg.HF,
    zoomOut: kg.IF,
    addHotspot: kg.wB,
    removeHotspot: kg.KZ,
    clearHotspots: kg.qw,
    checkResize: kg.fV,
    addControl: kg.Fr,
    removeControl: kg.lN,
    getContainer: kg.Ra,
    addContextMenu: kg.jo,
    removeContextMenu: kg.mp,
    addOverlay: kg.Pa,
    removeOverlay: kg.Ob,
    clearOverlays: kg.SJ,
    openInfoWindow: kg.$c,
    closeInfoWindow: kg.Wc,
    pointToOverlayPixel: kg.Ye,
    overlayPixelToPoint: kg.XM,
    getInfoWindow: kg.ih,
    getOverlays: kg.Zw,
    getPanes() {
      return {
        floatPane: this.Xd.VC,
        markerMouseTarget: this.Xd.mE,
        floatShadow: this.Xd.JK,
        labelPane: this.Xd.eE,
        markerPane: this.Xd.vM,
        markerShadow: this.Xd.wM,
        mapPane: this.Xd.at,
        vertexPane: this.Xd.FO,
      };
    },
    addTileLayer: kg.Ne,
    removeTileLayer: kg.Yf,
    pixelToPoint: kg.Zb,
    pointToPixel: kg.yc,
    setFeatureStyle: kg.A5,
    selectBaseElement: kg.t5,
    setMapStyle: kg.Bt,
    enable3DBuilding: kg.Do,
    disable3DBuilding: kg.SV,
    getPanorama: kg.Cs,
    initIndoorLayer: kg.nY,
    setNormalMapDisplay: kg.fy,
    setMapStyleV2: kg.o_,
    setBMapCopyrightOffset: kg.TE,
    getVectorContainer: kg.QX,
  });
  V(window, {
    BMAP_COORD_BD09: 5,
    BMAP_COORD_GCJ02: 3,
  });
  const lg = ke.prototype;
  V(lg, {
    getTileLayer: lg.KX,
    getMinZoom: lg.mf,
    getMaxZoom: lg.Te,
    getProjection: lg.jj,
    getTextColor: lg.pm,
    getTips: lg.Fs,
  });
  V(window, {
    BMAP_NORMAL_MAP: Na,
    BMAP_PERSPECTIVE_MAP: Qa,
    BMAP_SATELLITE_MAP: ab,
    BMAP_HYBRID_MAP: Sa,
  });
  const mg = T.prototype;
  V(mg, {
    lngLatToPoint: mg.zg,
    pointToLngLat: mg.vj,
  });
  const ng = jb.prototype;
  V(ng, {
    lngLatToPoint: ng.zg,
    pointToLngLat: ng.vj,
  });
  const og = hb.prototype;
  V(og, {
    equals: og.Sb,
    containsPoint: og.Mr,
    containsBounds: og.rV,
    intersects: og.Os,
    extend: og.extend,
    getCenter: og.Nb,
    isEmpty: og.rj,
    getSouthWest: og.Ve,
    getNorthEast: og.Qf,
    toSpan: og.sF,
  });
  const pg = Vc.prototype;
  V(pg, {
    isVisible: pg.Oc,
    show: pg.show,
    hide: pg.$,
  });
  Vc.getZIndex = Vc.zk;
  const qg = ib.prototype;
  V(qg, {
    openInfoWindow: qg.$c,
    closeInfoWindow: qg.Wc,
    enableMassClear: qg.ej,
    disableMassClear: qg.UV,
    show: qg.show,
    hide: qg.$,
    getMap: qg.Vw,
    addContextMenu: qg.jo,
    removeContextMenu: qg.mp,
  });
  const rg = W.prototype;
  V(rg, {
    setIcon: rg.Ub,
    getIcon: rg.Oo,
    setPosition: rg.va,
    getPosition: rg.la,
    setOffset: rg.Ld,
    getOffset: rg.hj,
    getLabel: rg.oD,
    setLabel: rg.Mm,
    setTitle: rg.Dc,
    setTop: rg.ui,
    enableDragging: rg.pc,
    disableDragging: rg.mC,
    setZIndex: rg.Cp,
    getMap: rg.Vw,
    setAnimation: rg.Lm,
    setShadow: rg.iy,
    hide: rg.$,
    setRotation: rg.yp,
    getRotation: rg.iL,
  });
  V(window, {
    BMAP_ANIMATION_DROP: 1,
    BMAP_ANIMATION_BOUNCE: 2,
  });
  const sg = cd.prototype;
  V(sg, {
    setStyle: sg.Md,
    setStyles: sg.ti,
    setContent: sg.bd,
    setPosition: sg.va,
    getPosition: sg.la,
    setOffset: sg.Ld,
    getOffset: sg.hj,
    setTitle: sg.Dc,
    setZIndex: sg.Cp,
    getMap: sg.Vw,
    getContent: sg.tk,
  });
  const tg = Zc.prototype;
  V(tg, {
    setImageUrl: tg.DN,
    setSize: tg.Be,
    setAnchor: tg.rc,
    setImageOffset: tg.At,
    setImageSize: tg.i_,
    setInfoWindowAnchor: tg.l_,
    setPrintImageUrl: tg.x_,
  });
  const ug = bd.prototype;
  V(ug, {
    redraw: ug.ke,
    setTitle: ug.Dc,
    setContent: ug.bd,
    getContent: ug.tk,
    getPosition: ug.la,
    enableMaximize: ug.fh,
    disableMaximize: ug.Fw,
    isOpen: ug.bb,
    setMaxContent: ug.Ct,
    maximize: ug.Cx,
    enableAutoPan: ug.hs,
  });
  const vg = Xc.prototype;
  V(vg, {
    getPath: vg.Ue,
    setPath: vg.le,
    setPositionAt: vg.Om,
    getStrokeColor: vg.HX,
    setStrokeWeight: vg.Bp,
    getStrokeWeight: vg.lL,
    setStrokeOpacity: vg.zp,
    getStrokeOpacity: vg.IX,
    setFillOpacity: vg.zt,
    getFillOpacity: vg.bX,
    setStrokeStyle: vg.Ap,
    getStrokeStyle: vg.kL,
    getFillColor: vg.aX,
    getBounds: vg.te,
    enableEditing: vg.kf,
    disableEditing: vg.TV,
    getEditing: vg.YW,
    getGeodesicPath: vg.eX,
  });
  const wg = pd.prototype;
  V(wg, {
    setCenter: wg.tf,
    getCenter: wg.Nb,
    getRadius: wg.gL,
    setRadius: wg.uf,
  });
  const xg = nd.prototype;
  V(xg, {
    getPath: xg.Ue,
    setPath: xg.le,
    setPositionAt: xg.Om,
  });
  const yg = kb.prototype;
  V(yg, {
    getPosition: yg.la,
    setPosition: yg.va,
    getText: yg.zD,
    setText: yg.Gt,
  });
  Q.prototype.equals = Q.prototype.Sb;
  R.prototype.equals = R.prototype.Sb;
  N.prototype.equals = N.prototype.Sb;
  V(window, {
    BMAP_ANCHOR_TOP_LEFT: Dc,
    BMAP_ANCHOR_TOP_RIGHT: Ec,
    BMAP_ANCHOR_BOTTOM_LEFT: Fc,
    BMAP_ANCHOR_BOTTOM_RIGHT: 3,
  });
  const zg = Cc.prototype;
  V(zg, {
    setAnchor: zg.rc,
    getAnchor: zg.bD,
    setOffset: zg.Ld,
    getOffset: zg.hj,
    show: zg.show,
    hide: zg.$,
    isVisible: zg.Oc,
    toString: zg.toString,
  });
  const Ag = mb.prototype;
  V(Ag, {
    getType: Ag.Vo,
    setType: Ag.Pm,
  });
  V(window, {
    BMAP_NAVIGATION_CONTROL_LARGE: 0,
    BMAP_NAVIGATION_CONTROL_SMALL: 1,
    BMAP_NAVIGATION_CONTROL_PAN: 2,
    BMAP_NAVIGATION_CONTROL_ZOOM: 3,
  });
  const Bg = ob.prototype;
  V(Bg, {
    changeView: Bg.qe,
    setSize: Bg.Be,
    getSize: Bg.xb,
  });
  const Cg = nb.prototype;
  V(Cg, {
    getUnit: Cg.PX,
    setUnit: Cg.bF,
  });
  V(window, {
    BMAP_UNIT_METRIC: 'metric',
    BMAP_UNIT_IMPERIAL: 'us',
  });
  const Dg = Hc.prototype;
  V(Dg, {
    addCopyright: Dg.Zv,
    removeCopyright: Dg.HE,
    getCopyright: Dg.im,
    getCopyrightCollection: Dg.iD,
  });
  V(window, {
    BMAP_MAPTYPE_CONTROL_HORIZONTAL: Jc,
    BMAP_MAPTYPE_CONTROL_DROPDOWN: 1,
    BMAP_MAPTYPE_CONTROL_MAP: 2,
  });
  const Eg = ud.prototype;
  V(Eg, {
    getMapType: Eg.wa,
    getCopyright: Eg.im,
    isTransparentPng: Eg.Vs,
  });
  const Fg = Nc.prototype;
  V(Fg, {
    addItem: Fg.$v,
    addSeparator: Fg.zB,
    removeSeparator: Fg.JE,
  });
  const Gg = Qc.prototype;
  V(Gg, {
    setText: Gg.Gt,
  });
  const Hg = X.prototype;
  V(Hg, {
    getStatus: Hg.nm,
    setSearchCompleteCallback: Hg.Ft,
    getPageCapacity: Hg.nf,
    setPageCapacity: Hg.xp,
    setLocation: Hg.Nm,
    disableFirstResultSelection: Hg.nC,
    enableFirstResultSelection: Hg.HC,
    gotoPage: Hg.qm,
    searchNearby: Hg.up,
    searchInBounds: Hg.Km,
    search: Hg.search,
  });
  V(window, {
    BMAP_STATUS_SUCCESS: 0,
    BMAP_STATUS_CITY_LIST: 1,
    BMAP_STATUS_UNKNOWN_LOCATION: we,
    BMAP_STATUS_UNKNOWN_ROUTE: 3,
    BMAP_STATUS_INVALID_KEY: 4,
    BMAP_STATUS_INVALID_REQUEST: 5,
    BMAP_STATUS_PERMISSION_DENIED: xe,
    BMAP_STATUS_SERVICE_UNAVAILABLE: 7,
    BMAP_STATUS_TIMEOUT: ye,
  });
  V(window, {
    BMAP_POI_TYPE_NORMAL: 0,
    BMAP_POI_TYPE_BUSSTOP: 1,
    BMAP_POI_TYPE_BUSLINE: 2,
    BMAP_POI_TYPE_SUBSTOP: 3,
    BMAP_POI_TYPE_SUBLINE: 4,
  });
  V(window, {
    BMAP_TRANSIT_POLICY_RECOMMEND: 0,
    BMAP_TRANSIT_POLICY_LEAST_TIME: 4,
    BMAP_TRANSIT_POLICY_LEAST_TRANSFER: 1,
    BMAP_TRANSIT_POLICY_LEAST_WALKING: 2,
    BMAP_TRANSIT_POLICY_AVOID_SUBWAYS: 3,
    BMAP_TRANSIT_POLICY_FIRST_SUBWAYS: 5,
    BMAP_LINE_TYPE_BUS: 0,
    BMAP_LINE_TYPE_SUBWAY: 1,
    BMAP_LINE_TYPE_FERRY: 2,
    BMAP_LINE_TYPE_TRAIN: 3,
    BMAP_LINE_TYPE_AIRPLANE: 4,
    BMAP_LINE_TYPE_COACH: 5,
  });
  V(window, {
    BMAP_TRANSIT_TYPE_POLICY_TRAIN: 0,
    BMAP_TRANSIT_TYPE_POLICY_AIRPLANE: 1,
    BMAP_TRANSIT_TYPE_POLICY_COACH: 2,
  });
  V(window, {
    BMAP_INTERCITY_POLICY_LEAST_TIME: 0,
    BMAP_INTERCITY_POLICY_EARLY_START: 1,
    BMAP_INTERCITY_POLICY_CHEAP_PRICE: 2,
  });
  V(window, {
    BMAP_TRANSIT_TYPE_IN_CITY: 0,
    BMAP_TRANSIT_TYPE_CROSS_CITY: 1,
  });
  V(window, {
    BMAP_TRANSIT_PLAN_TYPE_ROUTE: 0,
    BMAP_TRANSIT_PLAN_TYPE_LINE: 1,
  });
  const Ig = Qe.prototype;
  V(Ig, {
    clearResults: Ig.Qe,
  });
  Se = Re.prototype;
  V(Se, {
    setPolicy: Se.Et,
    toString: Se.toString,
    setPageCapacity: Se.xp,
    setIntercityPolicy: Se.GN,
    setTransitTypePolicy: Se.QN,
  });
  V(window, {
    BMAP_DRIVING_POLICY_DEFAULT: 0,
    BMAP_DRIVING_POLICY_AVOID_HIGHWAYS: 3,
    BMAP_DRIVING_POLICY_AVOID_CONGESTION: 5,
    BMAP_DRIVING_POLICY_FIRST_HIGHWAYS: 4,
  });
  V(window, {
    BMAP_MODE_DRIVING: 'driving',
    BMAP_MODE_TRANSIT: 'transit',
    BMAP_MODE_WALKING: 'walking',
    BMAP_MODE_NAVIGATION: 'navigation',
  });
  const Jg = $e.prototype;
  V(Jg, {
    routeCall: Jg.xN,
  });
  V(window, {
    BMAP_HIGHLIGHT_STEP: 1,
    BMAP_HIGHLIGHT_ROUTE: 2,
  });
  V(window, {
    BMAP_ROUTE_TYPE_DRIVING: Ae,
    BMAP_ROUTE_TYPE_WALKING: ze,
    BMAP_ROUTE_TYPE_RIDING: Be,
  });
  V(window, {
    BMAP_ROUTE_STATUS_NORMAL: Ce,
    BMAP_ROUTE_STATUS_EMPTY: 1,
    BMAP_ROUTE_STATUS_ADDRESS: 2,
  });
  const Kg = Ue.prototype;
  V(Kg, {
    setPolicy: Kg.Et,
  });
  const Lg = ff.prototype;
  V(Lg, {
    show: Lg.show,
    hide: Lg.$,
    setTypes: Lg.aF,
    setLocation: Lg.Nm,
    search: Lg.search,
    setInputValue: Lg.ey,
  });
  V(qb.prototype, {});
  const Mg = df.prototype;
  V(Mg, {
    get: Mg.get,
  });
  V(Lc.prototype, {});
  V(window, {
    BMAP_POINT_DENSITY_HIGH: 200,
    BMAP_POINT_DENSITY_MEDIUM: Ed,
    BMAP_POINT_DENSITY_LOW: 50,
  });
  V(window, {
    BMAP_POINT_SHAPE_STAR: 1,
    BMAP_POINT_SHAPE_WATERDROP: 2,
    BMAP_POINT_SHAPE_CIRCLE: ed,
    BMAP_POINT_SHAPE_SQUARE: 4,
    BMAP_POINT_SHAPE_RHOMBUS: 5,
  });
  V(window, {
    BMAP_POINT_SIZE_TINY: 1,
    BMAP_POINT_SIZE_SMALLER: 2,
    BMAP_POINT_SIZE_SMALL: 3,
    BMAP_POINT_SIZE_NORMAL: fd,
    BMAP_POINT_SIZE_BIG: 5,
    BMAP_POINT_SIZE_BIGGER: 6,
    BMAP_POINT_SIZE_HUGE: 7,
  });
  V(window, {
    BMap_Symbol_SHAPE_CAMERA: 11,
    BMap_Symbol_SHAPE_WARNING: 12,
    BMap_Symbol_SHAPE_SMILE: 13,
    BMap_Symbol_SHAPE_CLOCK: 14,
    BMap_Symbol_SHAPE_POINT: 9,
    BMap_Symbol_SHAPE_PLANE: 10,
    BMap_Symbol_SHAPE_CIRCLE: 1,
    BMap_Symbol_SHAPE_RECTANGLE: 2,
    BMap_Symbol_SHAPE_RHOMBUS: 3,
    BMap_Symbol_SHAPE_STAR: 4,
    BMap_Symbol_SHAPE_BACKWARD_CLOSED_ARROW: 5,
    BMap_Symbol_SHAPE_FORWARD_CLOSED_ARROW: 6,
    BMap_Symbol_SHAPE_BACKWARD_OPEN_ARROW: 7,
    BMap_Symbol_SHAPE_FORWARD_OPEN_ARROW: 8,
  });
  V(window, {
    BMAP_CONTEXT_MENU_ICON_ZOOMIN: Oc,
    BMAP_CONTEXT_MENU_ICON_ZOOMOUT: Pc,
  });
  V(window, {
    BMAP_SYS_DRAWER: La,
    BMAP_SVG_DRAWER: 1,
    BMAP_VML_DRAWER: 2,
    BMAP_CANVAS_DRAWER: 3,
    BMAP_SVG_DRAWER_FIRST: 4,
  });
  D.zU();
  D.C0();
}());
