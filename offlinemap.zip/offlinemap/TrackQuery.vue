<!--
@file 百度离线地图-GPS轨迹回放
@author dhuang
@copyright NanJing Anshare Tech .Com
@createDate 2020年11月14日16:58:02
-->
<template>
  <div class="trackquery">
    <div v-loading.lock="isLoading"
         style="height:100%">
      <div id="container"
           class="map"></div>
      <div class="input-card"
           v-if="$route.name === 'TrackQueryDemo'">
        <h4>轨迹回放控制</h4>
        <div class="input-item">
          <input type="button"
                 class="btn"
                 value="开始动画"
                 id="start"
                 @click="clearMark()" />
          <input type="button"
                 class="btn"
                 value="暂停动画"
                 id="pause"
                 @click="pauseAnimation()" />
          <input type="button"
                 class="btn"
                 value="加速"
                 id="speed"
                 @click="speedAnimation(markerSpeed*2)" />
        </div>
        <div class="input-item">
          <input type="button"
                 class="btn"
                 value="停止动画"
                 id="stop"
                 @click="stopAnimation()" />
          <input type="button"
                 class="btn"
                 value="隐藏信息窗口"
                 id="hide"
                 @click="hideInfoWindow()" />
          <input type="button"
                 class="btn"
                 value="展示信息窗口"
                 id="show"
                 @click="showInfoWindow()" />
        </div>
        <div class="input-item">
          <input type="button"
                 class="btn"
                 value="前进"
                 id="going"
                 @click="goingAnimation()" />
          <input type="button"
                 class="btn"
                 value="后退"
                 id="back"
                 @click="backAnimation()" />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { DML, crud } from '@/api/public/crud';

export default {
  name: 'TrackQuery',
  data() {
    return {
      map: null,
      marker: null,
      blueCar: '',
      center: [116.004303, 29.736834],
      lineArr: [],
      lineArrDefault: [
        [119.831344, 32.205128000000002],
        [119.83906399999999, 32.204357999999999],
        [119.84292000000001, 32.177066000000003],
        [119.850032, 32.134487999999997],
        [119.864664, 32.124394000000002],
        [119.871928, 32.108851999999999],
        [119.902128, 32.074531999999998],
        [119.90580799999999, 32.074953999999998],
        [119.880728, 32.111975999999999],
        [119.87037599999999, 32.150385999999997],
        [119.87956800000001, 32.112403999999998],
      ],
      arrPois: [],
      // 路书的点
      arrLinePois: [],
      defaultContent: '从环岛公路到008乡道',
      isLoading: false,
    };
  },
  props: {
    markerSpeed: {
      type: Number,
      default: 2500,
    },
    license: {
      type: String,
      default: '',
    },
    datetime: {
      type: Array,
      default: () => [],
    },
  },
  watch: {
    markerSpeed(val) {
      if (this.blueCar) {
        this.speedAnimation(val);
      }
    },
    license(val) {
      if (val) {
        this.getlineArr();
      }
    },
    datetime(val, oldVal) {
      // 只切换时间才请求，车牌号变化时不请求
      if (!val.length) {
        this.$message({
          message: '请选择时间段',
          type: 'error',
        });
      } else if (this.lineArr.length && oldVal.length && val !== oldVal) {
        this.getlineArr();
      }
    },
  },
  methods: {
    // 获取路线
    getlineArr() {
      this.isLoading = true;
      if (this.blueCar) {
        this.blueCar.clear();
      }
      if (this.map) {
        const allOverlay = this.map.getOverlays();
        // 循坏所有点，删除已画好的路线，重新绘制路线
        allOverlay.forEach((item) => {
          this.map.removeOverlay(item);
        });
      }
      this.map = '';
      this.marker = '';
      this.blueCar = '';
      this.lineArr = [];
      this.arrPois = [];
      this.arrLinePois = [];
      const searchCondition = [
        { field: 'cph', operator: 'eq', value: this.license },
        { field: 'sj', operator: 'egt', value: this.datetime[0] },
        { field: 'sj', operator: 'elt', value: this.datetime[1] },
      ];
      crud(DML.SELECT, 'ss_select_task_gps', {
        orderCondition: 'sj asc',
        searchCondition,
      })
        .then((res) => {
          if (res.code === 200) {
            if (res.data.list.length) {
              this.lineArr = res.data.list.map(r => [r.jd * 1, r.wd * 1]);
              const [start] = res.data.list;
              const dest = res.data.list[res.data.list.length - 1];
              this.defaultContent = `从${start.wz}到${dest.wz}`;
              [this.center] = this.lineArr;
              this.initMap();
            } else {
              this.lineArr = this.lineArrDefault;
              this.defaultContent = '从环岛公路到008乡道';
            }
            this.isLoading = false;
          }
        })
        .catch(() => {
          this.$message({
            message: '请求失败',
            type: 'error',
          });
        });
    },
    // 坐标标注
    pointMarker(point, icon) {
      this.marker = new BMap.Marker(point, { icon });
      this.map.addOverlay(this.marker); // 将标记添加到地图中
      this.map.setCenter(point);
    },
    run() {
      // 单迎线路轨迹
      this.lineArr.forEach((r) => {
        // 真实经纬度转成百度坐标（离线）
        BMap.Convertor.translate(new BMap.Point(...r), 1, 9, (point) => {
          this.arrPois.push(point);
        });
      });
      this.map.setViewport(this.arrPois);
      // 标注起点
      this.pointMarker(this.arrPois[0], new BMap.Icon('offlinemap/images/dest_markers.png', new BMap.Size(42, 34), { offset: new BMap.Size(14, 32), imageOffset: new BMap.Size(0, 0 - 0 * 34) }));
      this.arrLinePois = this.arrPois;
      this.initLush();
      this.startAnimation();
    },
    // 初始化路书
    initLush() {
      this.blueCar = new BMapLib.LuShu(this.map, this.arrLinePois, {
        defaultContent: '', // "从环岛公路到008乡道"
        autoView: true, // 是否开启自动视野调整，如果开启那么路书在运动过程中会根据视野自动调整
        icon: new BMap.Icon('offlinemap/images/car.png', new BMap.Size(48, 32), {
          anchor: new BMap.Size(15, 15),
        }),
        speed: this.markerSpeed,
        follow: false, // 是否开启画面跟随，默认不开启
        walkingDraw: true, // 是否开启边走变化路线
        landmarkPois: [
          {
            lng: this.arrPois[this.arrPois.length - 1].lng,
            lat: this.arrPois[this.arrPois.length - 1].lat,
            html: '终点到了',
            pauseTime: 1,
          },
        ],
        enableRotation: true, // 是否设置marker随着道路的走向进行旋转
      });
    },
    // 清除掉上一次路书
    clearMark() {
      this.blueCar.clear();
      this.initLush();
      this.startAnimation();
    },
    // 前进
    goingAnimation() {
      this.arrLinePois = this.arrLinePois.slice(2);
      this.clearMark();
    },
    // 后退
    backAnimation() {
      this.arrLinePois = this.arrLinePois.slice(1);
      this.clearMark();
    },
    // 开始
    startAnimation() {
      if (this.arrLinePois.length !== this.arrPois.length) {
        this.arrLinePois = this.arrPois;
      }
      this.blueCar.start();
    },
    // 改变速度
    speedAnimation(speed) {
      this.blueCar.setSpeed(speed);
    },
    // 暂停
    pauseAnimation() {
      this.blueCar.pause();
    },
    // 停止
    stopAnimation() {
      this.blueCar.stop();
    },
    // 隐藏悬浮框
    hideInfoWindow() {
      this.blueCar.hideInfoWindow();
    },
    // 显示悬浮框
    showInfoWindow() {
      this.blueCar.showInfoWindow();
    },
    // 初始化地图
    initMap() {
      this.map = new BMap.Map('container', { enableMapClick: false, minZoom: 5, maxZoom: 18 });
      // 未转换的谷歌坐标
      const gpsPoint = new BMap.Point(...this.center);
      BMap.Convertor.translate(gpsPoint, 1, 9, (point) => {
        // 转换后的百度坐标
        this.map.centerAndZoom(point, 15);
      });
      this.map.enableScrollWheelZoom(); // 启用滚轮放大缩小。
      this.map.enableKeyboard(); // 启用键盘操作。
      this.map.enableContinuousZoom(); // 启用连续缩放效果
      this.run();
    },
  },
  mounted() {
    this.$store.commit('SET_LODAING', false);
    setTimeout(() => {
      // 单条轨迹
      if (this.$route.name === 'TrackQueryDemo') {
        // demo页
        this.lineArr = this.lineArrDefault;
        [this.center] = this.lineArr;
        this.initMap();
      }
      if (this.license) {
        this.getlineArr();
      }
    }, 1000);
  },
};
</script>

<style lang="scss" scoped>
.trackquery {
  height: 100%;
  position: relative;
}
#container {
  height: 100%;
  width: 100%;
}
.input-card {
  position: absolute;
  right: 0;
  bottom: 0;
  background: #fff;
  padding: 0 1rem;
  .input-item {
    margin-bottom: 1.2rem;
    .btn {
      cursor: pointer;
      margin-right: 1.2rem;
      width: 9rem;
    }
    .btn:last-child {
      margin-right: 0;
    }
  }
}
</style>
