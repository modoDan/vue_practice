/* eslint-disable */
let tiles_dir = '';
if (window.location.href.includes('156')) {
  // 内网发布版
  tiles_dir = `${window.location.origin}/download/offlinemap/tiles`;
} else {
  // 外网发布版或开发环境，放在106服务器上
  tiles_dir = 'http://www.axtech.net.cn:56266/download/offlinemap/tiles';
}
const bmapcfg = {
  imgext: '.png', // 瓦片图的后缀  根据需要修改，一般是 .png .jpg
  tiles_dir, // 普通瓦片图的地址，为空默认在tiles/ 目录
};

const scripts = document.getElementsByTagName('script');
const JS__FILE__ = scripts[scripts.length - 1].getAttribute('src'); // 获得当前js文件路径
bmapcfg.home = JS__FILE__.substr(0, JS__FILE__.lastIndexOf('/') + 1); // 地图API主目录
(function () {
  window.BMap_loadScriptTime = (new Date()).getTime();
  // 加载地图API主文件
  document.write(`<script type="text/javascript" src="${bmapcfg.home}bmap_offline_api_v3.0_min.js"></script>`);
  document.write(`<script type="text/javascript" src="${bmapcfg.home}/library/offline_convertor.js"></script>`);
  document.write(`<script type="text/javascript" src="${bmapcfg.home}/library/LuShu_min.js"></script>`);
}());
